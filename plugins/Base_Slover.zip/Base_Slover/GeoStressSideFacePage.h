#pragma once

#include <BasePage.h>
#include <PickManager.h>

namespace Ui
{
class GeoStressSideFacePage;
}

class GeoStressSideFacePage : public BasePage
{
    Q_OBJECT
  public:
    struct FaceAttr
    {
        QString idir;
        QString height;
        QString gama;
        QString pgrout;
        QString ii;
    };

    explicit GeoStressSideFacePage(QWidget* parent = nullptr);
    ~GeoStressSideFacePage() override;

    void beforeLoad() override;
    void beforeUnload() override;

    QJsonObject saveJson() override;
    void loadJson(const QJsonObject& obj) override;

    QString faceFile() const;
    FaceAttr attr() const;
    bool exportDatFile() const;
    void setFaceIndex(int index);

  private slots:
    void onClearClicked();
    void onBatchAddClicked();
    void onGroupHovered(int row);

  private:
    PickMode currentPickMode() const;
    void refreshGroupCombo();

  private:
    Ui::GeoStressSideFacePage* ui = nullptr;
    int m_faceIndex = 1;
};
