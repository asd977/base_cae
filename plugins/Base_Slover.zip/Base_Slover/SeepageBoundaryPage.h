﻿#pragma once

#include <BasePage.h>

#include <QJsonObject>
#include <QString>
#include <QVector>

namespace Ui
{
class SeepageBoundaryPage;
}

class SeepageBoundaryPage : public BasePage
{
    Q_OBJECT
  public:
    explicit SeepageBoundaryPage(const QString& pageType, const QString& boundaryTitle,
                                 const QString& exportFileName, QWidget* parent = nullptr,
                                 bool removeFileWhenEmpty = false);
    ~SeepageBoundaryPage() override;

    void beforeLoad() override;
    void beforeUnload() override;

    bool exportDatFile();
    int selectionCount();

    QJsonObject saveJson() override;
    void loadJson(const QJsonObject& obj) override;

  signals:
    void selectionCountChanged(int count);

  private slots:
    void onClearClicked();
    void onDimChanged(int index);
    void onGroupChanged(int index);

  private:
    QVector<int> selectedNodeIds();
    void setupBatchGroupCombo();
    void refreshGroupCombo();
    void updateSelectionSummary();

  private:
    Ui::SeepageBoundaryPage* ui = nullptr;
    QString m_boundaryTitle;
    QString m_exportFileName;
    bool m_removeFileWhenEmpty = false;
};
