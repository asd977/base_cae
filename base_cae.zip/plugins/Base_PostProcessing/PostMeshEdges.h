#pragma once

#include <services/VisualWidgetService.h>
#include <QHash>
#include <QPointer>
#include <QObject>
#include <vtkActor.h>
#include <vtkCallbackCommand.h>
#include <vtkCommand.h>
#include <vtkDataSetMapper.h>
#include <vtkProperty.h>
#include <vtkWeakPointer.h>
#include <memory>

// VTK 9.2 has no independent EdgeOpacity. A native wireframe actor shares the
// surface input connection; only that actor blends when edge opacity is < 1.
namespace PostMeshEdges
{
inline QString actorId(const QString& sourceId){return sourceId+QStringLiteral(".mesh-edges");}

struct Binding
{
    VisualWidgetService* service{};
    QPointer<QObject> serviceObject;
    bool guardedService{false};
    QString id;
    vtkWeakPointer<vtkActor> source,edge;
    vtkWeakPointer<vtkMapper> mapper;
    vtkWeakPointer<vtkProperty> property;
    vtkSmartPointer<vtkCallbackCommand> callback;
    unsigned long sourceTag{},mapperTag{},propertyTag{};
    double opacity{1},width{1};
    bool syncing{false};

    Binding(VisualWidgetService* value,const QString& sourceId,vtkActor* actor,vtkActor* lines)
        :service(value),serviceObject(dynamic_cast<QObject*>(value)),guardedService(!serviceObject.isNull()),
         id(actorId(sourceId)),source(actor),edge(lines)
    {
        callback=vtkSmartPointer<vtkCallbackCommand>::New();callback->SetClientData(this);
        callback->SetCallback([](vtkObject*,unsigned long,void* data,void*){static_cast<Binding*>(data)->sync();});
        sourceTag=source->AddObserver(vtkCommand::ModifiedEvent,callback);
    }
    ~Binding()
    {
        if(source && sourceTag)source->RemoveObserver(sourceTag);
        if(mapper && mapperTag)mapper->RemoveObserver(mapperTag);
        if(property && propertyTag)property->RemoveObserver(propertyTag);
    }
    void sync()
    {
        if(syncing || !source || !edge || (guardedService && !serviceObject))return;
        syncing=true;
        auto* currentMapper=source->GetMapper();auto* currentProperty=source->GetProperty();
        if(mapper!=currentMapper) {
            if(mapper && mapperTag)mapper->RemoveObserver(mapperTag);
            mapper=currentMapper;mapperTag=mapper?mapper->AddObserver(vtkCommand::ModifiedEvent,callback):0;
        }
        if(property!=currentProperty) {
            if(property && propertyTag)property->RemoveObserver(propertyTag);
            property=currentProperty;propertyTag=property?property->AddObserver(vtkCommand::ModifiedEvent,callback):0;
        }
        auto* edgeMapper=vtkDataSetMapper::SafeDownCast(edge->GetMapper());
        auto* input=mapper && mapper->GetNumberOfInputPorts()>0 && mapper->GetNumberOfInputConnections(0)>0
            ?mapper->GetInputConnection(0,0):nullptr;
        if(edgeMapper) {
            auto* previous=edgeMapper->GetNumberOfInputConnections(0)>0?edgeMapper->GetInputConnection(0,0):nullptr;
            if(previous!=input)edgeMapper->SetInputConnection(input);
            auto* clipping=mapper?mapper->GetClippingPlanes():nullptr;
            if(edgeMapper->GetClippingPlanes()!=clipping)edgeMapper->SetClippingPlanes(clipping);
            edgeMapper->ScalarVisibilityOff();
        }
        edge->SetUserMatrix(source->GetMatrix());
        edge->GetProperty()->SetLineWidth(width);
        edge->GetProperty()->SetOpacity(opacity*(property?property->GetOpacity():1.0));
        service->setVisible(id,input && source->GetVisibility() && edge->GetProperty()->GetOpacity()>0,false);
        syncing=false;
    }
};

using Bindings=QHash<QString,std::shared_ptr<Binding>>;
inline QHash<VisualWidgetService*,Bindings>& bindings()
{
    static QHash<VisualWidgetService*,Bindings> value;return value;
}

inline void remove(VisualWidgetService* service,const QString& sourceId)
{
    if(!service)return;
    auto owner=bindings().find(service);
    if(owner!=bindings().end()) {
        owner->remove(sourceId);
        if(owner->isEmpty())bindings().erase(owner);
    }
    if(service->getProp(actorId(sourceId)))service->removeProp(actorId(sourceId),false);
}

inline void update(VisualWidgetService* service,const QString& id,vtkActor* actor,
                   bool enabled,double opacity,double width)
{
    if(!service || !actor)return;
    if(!enabled) {remove(service,id);return;}
    auto old=bindings().value(service).value(id);
    if(old && (old->source!=actor || !old->edge || service->getProp(actorId(id))!=old->edge.GetPointer())) {
        remove(service,id);old.reset();
    }
    if(!old) {
        auto mapper=vtkSmartPointer<vtkDataSetMapper>::New();mapper->ScalarVisibilityOff();
        auto edge=vtkSmartPointer<vtkActor>::New();edge->SetMapper(mapper);
        edge->PickableOff();edge->UseBoundsOff();
        edge->GetProperty()->SetRepresentationToWireframe();
        edge->GetProperty()->SetColor(0,0,0);edge->GetProperty()->LightingOff();
        service->addProp(actorId(id),edge,QStringLiteral("post"),QStringLiteral("单元边线"),false,false);
        old=std::make_shared<Binding>(service,id,actor,edge);
        bindings()[service].insert(id,old);
    }
    old->opacity=opacity;old->width=width;old->sync();
}

inline void clear(VisualWidgetService* service)
{
    const auto ids=bindings().value(service).keys();
    for(const auto& id:ids)remove(service,id);
}
}
