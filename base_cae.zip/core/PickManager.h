﻿#ifndef PICKMANAGER_H
#define PICKMANAGER_H

#include <core_global.h>

#include <QHash>
#include <QStringList>
#include <QObject>
#include <QSet>
#include <QString>
#include <QTimer>
#include <QVector>

// VTK
#include <vtkActor.h>
#include <vtkCallbackCommand.h>
#include <vtkCellArray.h>
#include <vtkCellPicker.h>
#include <vtkDataArray.h>
#include <vtkDataSet.h>
#include <vtkDataSetMapper.h>
#include <vtkHardwareSelector.h>
#include <vtkIntArray.h>
#include <vtkPolyDataMapper2D.h>
#include <vtkPoints.h>
#include <vtkPolyData.h>
#include <vtkPolyDataMapper.h>
#include <vtkProp.h>
#include <vtkActor2D.h>
#include <vtkSmartPointer.h>
#include <vtkUnstructuredGrid.h>
#include <vtkVertexGlyphFilter.h>
#include <vtkWeakPointer.h>

#include <services/MeshModuleControllerService.h>

#include "services/VisualWidgetService.h"

enum class PickMode
{
    Node,
    Edge,
    Face,
    Domain
};
enum class GridKind
{
    Solid,
    Line
};

class CORE_EXPORT PickManager : public QObject
{
    Q_OBJECT
  public:
    static PickManager& instance();

    void activate(const QString& domain, const QString& uuid, PickMode mode);
    void deactivate(const QString& domain, const QString& uuid, PickMode mode);
    void resetProjectState();

    QVector<vtkIdType> getIdList(const QString& domain, const QString& uuid, PickMode mode) const;
    QVector<vtkIdType> getIdList(const QString& domain, const QString& uuid, PickMode mode,
                                 GridKind kind) const;
    QVector<vtkIdType> getSelectedPointIds(const QString& domain, const QString& uuid,
                                           GridKind kind) const;

    // 节点选择策略：默认同一 domain 内节点互斥；位移约束可显式允许多个约束共享节点。
    void setNodeSelectionAllowsOverlap(const QString& domain, bool allow);

    // 位移约束等需要展示“共享节点/最终自由度”时使用。这里按 node_id 跨 Solid/Line 汇总，
    // 不改变各 uuid 自己保存的选区。
    QVector<int> selectedNodeIds(const QString& domain, const QString& uuid) const;
    QVector<int> sharedNodeIds(const QString& domain, const QString& uuid) const;
    QSet<int> conflictingSharedNodeIds(const QString& domain, const QString& uuid) const;
    QVector<vtkIdType> sharedSelectedPointIds(const QString& domain, const QString& uuid,
                                              GridKind kind) const;
    QStringList selectedNodeUuids(const QString& domain, int nodeId) const;
    QSet<int> conflictingNodeIds(const QString& domain) const;

    // 可选的节点约束元数据。PickManager 只负责汇总显示，不负责求解器写出。
    void setNodeConstraintFlags(const QString& domain, const QString& uuid, int ux, int uy, int uz);
    void clearNodeConstraintFlags(const QString& domain, const QString& uuid);
    QVector<int> nodeConstraintFlags(const QString& domain, const QString& uuid) const;
    QVector<int> effectiveNodeConstraintFlags(const QString& domain, int nodeId,
                                              bool* hasConflict = nullptr) const;
    QSet<DomainKey> appliedDomains(const QString& domain, const QString& uuid);
    DomainKey selectedDomain(const QString& domain, const QString& uuid) const;
    DomainKey previewDomain(const QString& domain, const QString& uuid) const;
    DomainKey preDeleteDomain(const QString& domain, const QString& uuid) const;

    QHash<int, QVector<int>> getEdgeNodesByKe(const QString& domain, const QString& uuid,
                                              GridKind kind) const;
    QHash<int, QVector<int>> getFaceNodesByKe(const QString& domain, const QString& uuid,
                                              GridKind kind) const;

    void updateStructure();

    static void OnLeftButtonPress(vtkObject* caller, unsigned long, void* clientData, void*);
    static void OnLeftButtonRelease(vtkObject* caller, unsigned long, void* clientData, void*);
    static void OnMouseMove(vtkObject* caller, unsigned long, void* clientData, void*);

    // ---- face key ----
    vtkIdType packFaceKey(vtkIdType cellId, int faceLocalId) const
    {
        return (cellId << 4) | (vtkIdType(faceLocalId) & 0xF);
    }
    vtkIdType unpackFaceCellId(vtkIdType faceKey) const
    {
        return (faceKey >> 4);
    }
    int unpackFaceLocalId(vtkIdType faceKey) const
    {
        return int(faceKey & 0xF);
    }

    // ---- edge key ----
    vtkIdType packEdgeKey(vtkIdType cellId, int edgeLocalId) const
    {
        return (cellId << 4) | (vtkIdType(edgeLocalId) & 0xF);
    }
    vtkIdType unpackEdgeCellId(vtkIdType edgeKey) const
    {
        return (edgeKey >> 4);
    }
    int unpackEdgeLocalId(vtkIdType edgeKey) const
    {
        return int(edgeKey & 0xF);
    }

    vtkUnstructuredGrid* solidGrid() const
    {
        return m_gridSolid;
    }
    vtkUnstructuredGrid* lineGrid() const
    {
        return m_gridLine;
    }

    void clearSelection(const QString& domain, const QString& uuid, PickMode mode);
    void setSelectedPointIds(const QString& domain, const QString& uuid, GridKind kind,
                             const QVector<vtkIdType>& pointIds, bool replace = true);

    void setSelectedEdgeKeys(const QString& domain, const QString& uuid, GridKind kind,
                             const QVector<vtkIdType>& edgeKeys, bool replace = true);

    void setSelectedFaceKeys(const QString& domain, const QString& uuid, GridKind kind,
                             const QVector<vtkIdType>& faceKeys, bool replace = true);

    // 从当前“可见网格表面”中，以 seedFaceKey 为起点扩展同一连续共面区域。
    // 主要给需要“点一个小网格面 -> 选整面”的页面使用；筛选后暴露出的内部面也按当前可见表面参与。
    QVector<vtkIdType> connectedVisibleFacePatch(vtkIdType seedFaceKey,
                                                 double angleToleranceDeg = 5.0) const;

    void setPreviewPointIds(const QString& domain, const QString& uuid, GridKind kind,
                           const QVector<vtkIdType>& pointIds);
    void setPreviewEdgeKeys(const QString& domain, const QString& uuid, GridKind kind,
                           const QVector<vtkIdType>& edgeKeys);
    void setPreviewFaceKeys(const QString& domain, const QString& uuid, GridKind kind,
                           const QVector<vtkIdType>& faceKeys);
    void clearPreviewSelection(const QString& domain, const QString& uuid, PickMode mode);
    void setBoxSelectEnabled(const QString& domain, const QString& uuid, bool enabled);
    void setClickPickEnabled(const QString& domain, const QString& uuid, bool enabled);
    // A page can request the exact domain category used by its view picks.
    // No preference keeps the existing automatic category precedence.
    void setPreferredDomainCategory(const QString& domain, const QString& uuid,
                                    const QString& category);
    void setAppliedDomains(const QString& domain, const QString& uuid,
                           const QSet<DomainKey>& keys);
    void setSelectedDomain(const QString& domain, const QString& uuid, const DomainKey& key);
    void setPreviewDomain(const QString& domain, const QString& uuid, const DomainKey& key);
    void setPreDeleteDomain(const QString& domain, const QString& uuid, const DomainKey& key);
    void clearDomainSelection(const QString& domain, const QString& uuid = QString());

  signals:
    void domainSelected(const QString& domain, const QString& uuid, const DomainKey& key);
    void selectionChanged(const QString& domain, const QString& uuid, PickMode mode, GridKind kind);

  private:
    explicit PickManager(QObject* parent = nullptr);
    ~PickManager() override = default;

    void clearNodeSelection_NoRefresh(const QString& domain, const QString& uuid, GridKind kind);
    bool nodeSelectionAllowsOverlap(const QString& domain) const;
    int nodeIdForPoint(GridKind kind, vtkIdType pointId) const;

    // picking
    void setupPicking();
    void teardownPicking();
    bool pickAt(int x, int y);
    bool hardwareBoxSelect(int x0, int y0, int x1, int y1, bool deselect = false);
    void updateDragRect(int x0, int y0, int x1, int y1, bool visible);
    bool isBoxSelectEnabledForActive() const;
    bool isClickPickEnabledForActive() const;

    // ---- node ----
    void toggleSelectNode(GridKind kind, vtkIdType pid);
    void rebuildPointsForActive();

    // ---- edge ----
    void toggleSelectEdge(GridKind kind, vtkIdType edgeKey);
    void rebuildEdgePolyForActive();
    void rebuildEdgeCanonicalCache();
    vtkIdType canonicalizeEdgeKey(GridKind kind, vtkIdType edgeKey) const;
    bool computePickedEdge(vtkUnstructuredGrid* grid, vtkIdType cellId, const double pickPos[3],
                           int& outEdgeLocalId, QVector<vtkIdType>& outEdgePids) const;
    bool computePickedEdgeFromBoundary(vtkDataSet* pickedDs, vtkIdType pickedCellId,
                                       const double pickPos[3], vtkIdType& outOrigCellId,
                                       int& outOrigEdgeLocalId) const;

    // ---- face ----
    void toggleSelectFace(GridKind kind, vtkIdType faceKey);
    void rebuildFaceColorForActive();
    void restoreFaceColoring();
    void rebuildBoundaryFaceCellIndex();
    bool computePickedFace(vtkUnstructuredGrid* grid, vtkIdType cellId, const double pickPos[3],
                           int& outFaceLocalId, QVector<vtkIdType>& outFacePids) const;
    bool computePickedFaceFromBoundary(vtkDataSet* pickedDs, vtkIdType pickedCellId,
                                       vtkIdType& outOrigCellId, int& outOrigFaceLocalId) const;

    void updateActorVisibility();
    void updateSelectionContextOpacity();
    void restoreSelectionContextOpacity();
    void applyDomainContextStyle();
    void restoreDomainContextStyle();
    void clearDomainFocusOverlay();
    // 将材料域高亮状态写入一套统一的 cell 颜色数组并刷新显示。
    void rebuildDomainHighlightActors();
    QSet<vtkIdType> cellsOfDomain(const DomainKey& key) const;
    QString domainOwner(const QString& domain, const DomainKey& key) const;

    // line node overlay
    void rebuildLineNodeOverlayAll();

    // commit exclusive on deactivate
    void commitNodeExclusive(const QString& domain, const QString& uuid);
    void commitEdgeExclusive(const QString& domain, const QString& uuid);
    void commitFaceExclusive(const QString& domain, const QString& uuid);

    // batch modify helpers (NO rebuild / NO render)
    void setNodeSelected_NoRefresh(GridKind kind, vtkIdType pid, bool selected);
    void setEdgeSelected_NoRefresh(GridKind kind, vtkIdType edgeKey, bool selected);
    void setFaceSelected_NoRefresh(GridKind kind, vtkIdType faceKey, bool selected);

    // ====== coalesced rebuild/render ======
    enum DirtyBits : int
    {
        DirtyNone = 0,
        DirtyNode = 1,
        DirtyEdge = 2,
        DirtyFace = 4
    };
    void markDirty(int bits);
    void flushRebuild();

  private:
    // ============ active ============
    QString m_currentDomain;
    QString m_currentUUid;
    PickMode m_pickMode = PickMode::Node;

    VisualWidgetService* m_visual = nullptr;

    // ============ observers / pickers ============
    vtkSmartPointer<vtkCallbackCommand> m_cbLeftPress;
    vtkSmartPointer<vtkCallbackCommand> m_cbLeftRelease;
    vtkSmartPointer<vtkCallbackCommand> m_cbMouseMove;

    vtkSmartPointer<vtkCellPicker> m_cellPicker;
    vtkSmartPointer<vtkHardwareSelector> m_hwSelector;
    unsigned long m_leftPressTag = 0;
    unsigned long m_leftReleaseTag = 0;
    unsigned long m_mouseMoveTag = 0;

    bool m_leftDown = false;
    bool m_dragMoved = false;
    bool m_dragUseBox = false;
    bool m_dragBoxDeselect = false;
    bool m_styleDisabledByBoxSelect = false;
    int m_dragStart[2] = {0, 0};
    int m_dragEnd[2] = {0, 0};
    QHash<QString, QHash<QString, bool>> m_boxSelectEnabledByDomainUuid;
    QHash<QString, QHash<QString, bool>> m_clickPickEnabledByDomainUuid;
    QHash<QString, QHash<QString, QString>> m_preferredDomainCategoryByDomainUuid;

    vtkSmartPointer<vtkPoints> m_dragRectPts;
    vtkSmartPointer<vtkCellArray> m_dragRectLines;
    vtkSmartPointer<vtkPolyData> m_dragRectPoly;
    vtkSmartPointer<vtkPolyDataMapper2D> m_dragRectMapper;
    vtkSmartPointer<vtkActor2D> m_dragRectActor;

    // coalesce
    int m_dirtyBits = DirtyNone;
    bool m_rebuildScheduled = false;

    // ============ mesh cache ============
    vtkUnstructuredGrid* m_gridSolid = nullptr;
    vtkUnstructuredGrid* m_gridLine = nullptr;
    QHash<quint64, vtkIdType> m_solidCanonicalEdgeByPointPair;
    QHash<quint64, vtkIdType> m_lineCanonicalEdgeByPointPair;

    vtkIntArray* m_nodeIdArrSolid = nullptr;
    vtkIntArray* m_elemIdArrSolid = nullptr;
    vtkIntArray* m_nodeIdArrLine = nullptr;
    vtkIntArray* m_elemIdArrLine = nullptr;

    vtkProp* m_solidProp = nullptr;
    vtkProp* m_lineProp = nullptr;
    vtkDataSet* m_solidPickDataSet = nullptr;
    vtkDataSet* m_linePickDataSet = nullptr;
    vtkWeakPointer<vtkProp> m_contextOpacitySolidProp;
    vtkWeakPointer<vtkProp> m_contextOpacityLineProp;
    double m_savedContextOpacitySolid = 1.0;
    double m_savedContextOpacityLine = 1.0;
    bool m_contextOpacitySolidActive = false;
    bool m_contextOpacityLineActive = false;

    vtkSmartPointer<vtkUnstructuredGrid> m_domainFocusGrid;
    vtkSmartPointer<vtkDataSetMapper> m_domainFocusMapper;
    vtkSmartPointer<vtkActor> m_domainFocusActor;
    vtkSmartPointer<vtkUnstructuredGrid> m_domainLineFocusGrid;
    vtkSmartPointer<vtkDataSetMapper> m_domainLineFocusMapper;
    vtkSmartPointer<vtkActor> m_domainLineFocusActor;
    vtkDataSet* m_domainFocusSolidSource = nullptr;
    vtkDataSet* m_domainFocusLineSource = nullptr;
    QVector<vtkIdType> m_domainFocusSolidCellIds;
    QVector<vtkIdType> m_domainFocusLineCellIds;
    vtkWeakPointer<vtkActor> m_domainContextSolidActor;
    vtkWeakPointer<vtkActor> m_domainContextLineActor;
    double m_savedDomainSolidOpacity = 1.0;
    double m_savedDomainLineOpacity = 1.0;
    double m_savedDomainSolidColor[3] = {0.78, 0.78, 0.78};
    double m_savedDomainLineColor[3] = {0.78, 0.78, 0.78};
    int m_savedDomainSolidEdgeVisibility = 0;
    int m_savedDomainLineEdgeVisibility = 0;
    int m_savedDomainSolidScalarVisibility = 0;
    int m_savedDomainLineScalarVisibility = 0;
    bool m_domainContextStyleActive = false;

    // ============ line node hints ============
    vtkSmartPointer<vtkPoints> m_lineNodePts;
    vtkSmartPointer<vtkPolyData> m_lineNodePoly;
    vtkSmartPointer<vtkVertexGlyphFilter> m_lineNodeGlyph;
    vtkSmartPointer<vtkPolyDataMapper> m_lineNodeMapper;
    vtkSmartPointer<vtkActor> m_lineNodeActor;
    bool m_showLineNodes = true;

    // ============ node overlay ============
    vtkSmartPointer<vtkPoints> m_selPts;
    vtkSmartPointer<vtkPolyData> m_selPoly;
    vtkSmartPointer<vtkVertexGlyphFilter> m_selGlyph;
    vtkSmartPointer<vtkPolyDataMapper> m_selMapper;
    vtkSmartPointer<vtkActor> m_selActor;

    // preview overlays
    vtkSmartPointer<vtkPoints> m_previewSelPts;
    vtkSmartPointer<vtkPolyData> m_previewSelPoly;
    vtkSmartPointer<vtkVertexGlyphFilter> m_previewSelGlyph;
    vtkSmartPointer<vtkPolyDataMapper> m_previewSelMapper;
    vtkSmartPointer<vtkActor> m_previewSelActor;

    QSet<QString> m_overlapNodeSelectionDomains;
    QHash<QString, QHash<QString, QVector<int>>> m_nodeConstraintFlagsByDomainUuid;

    QHash<QString, QHash<vtkIdType, QString>> m_ownerPointSolidByDomain;
    QHash<QString, QHash<QString, QSet<vtkIdType>>> m_pointsSolidByDomainUuid;
    QHash<QString, QHash<vtkIdType, QString>> m_ownerPointLineByDomain;
    QHash<QString, QHash<QString, QSet<vtkIdType>>> m_pointsLineByDomainUuid;

    QHash<QString, QHash<vtkIdType, QString>> m_prevOwnerPointSolidByDomain;
    QHash<QString, QHash<vtkIdType, QString>> m_prevOwnerPointLineByDomain;

    // ============ edge overlay ============
    vtkSmartPointer<vtkPoints> m_edgePts;
    vtkSmartPointer<vtkCellArray> m_edgeLines;
    vtkSmartPointer<vtkPolyData> m_edgePoly;
    vtkSmartPointer<vtkPolyDataMapper> m_edgeMapper;
    vtkSmartPointer<vtkActor> m_edgeActor;

    vtkSmartPointer<vtkPoints> m_previewEdgePts;
    vtkSmartPointer<vtkCellArray> m_previewEdgeLines;
    vtkSmartPointer<vtkPolyData> m_previewEdgePoly;
    vtkSmartPointer<vtkPolyDataMapper> m_previewEdgeMapper;
    vtkSmartPointer<vtkActor> m_previewEdgeActor;

    QHash<QString, QHash<vtkIdType, QString>> m_ownerEdgeSolidByDomain;
    QHash<QString, QHash<QString, QSet<vtkIdType>>> m_edgesSolidByDomainUuid;
    QHash<QString, QHash<vtkIdType, QString>> m_ownerEdgeLineByDomain;
    QHash<QString, QHash<QString, QSet<vtkIdType>>> m_edgesLineByDomainUuid;

    QHash<QString, QHash<vtkIdType, QString>> m_prevOwnerEdgeSolidByDomain;
    QHash<QString, QHash<vtkIdType, QString>> m_prevOwnerEdgeLineByDomain;

    // ============ face coloring cache ============
    QHash<vtkIdType, QVector<vtkIdType>> m_solidBoundaryCellsByFaceKey;
    vtkSmartPointer<vtkDataArray> m_savedSolidCellScalars;
    bool m_faceColoringActive = false;

    QHash<QString, QHash<QString, QSet<vtkIdType>>> m_previewPointsSolidByDomainUuid;
    QHash<QString, QHash<QString, QSet<vtkIdType>>> m_previewPointsLineByDomainUuid;
    QHash<QString, QHash<QString, QSet<vtkIdType>>> m_previewEdgesSolidByDomainUuid;
    QHash<QString, QHash<QString, QSet<vtkIdType>>> m_previewEdgesLineByDomainUuid;
    QHash<QString, QHash<QString, QSet<vtkIdType>>> m_previewFacesSolidByDomainUuid;
    QHash<QString, QHash<QString, QSet<vtkIdType>>> m_previewFacesLineByDomainUuid;

    QHash<QString, QHash<vtkIdType, QString>> m_ownerFaceSolidByDomain;
    QHash<QString, QHash<QString, QSet<vtkIdType>>> m_facesSolidByDomainUuid;
    QHash<QString, QHash<vtkIdType, QString>> m_ownerFaceLineByDomain;
    QHash<QString, QHash<QString, QSet<vtkIdType>>> m_facesLineByDomainUuid;

    QHash<QString, QHash<vtkIdType, QString>> m_prevOwnerFaceSolidByDomain;
    QHash<QString, QHash<vtkIdType, QString>> m_prevOwnerFaceLineByDomain;

    // ============ domain highlight overlay ============
    QHash<QString, QHash<QString, QSet<DomainKey>>> m_domainsByDomainUuid;
    QHash<QString, QHash<DomainKey, QString>> m_ownerDomainByDomain;
    QHash<QString, QHash<DomainKey, QString>> m_prevOwnerDomainByDomain;
    QHash<QString, QHash<QString, DomainKey>> m_selectedDomainByDomainUuid;
    QHash<QString, QHash<QString, DomainKey>> m_previewDomainByDomainUuid;
    QHash<QString, QHash<QString, DomainKey>> m_preDeleteDomainByDomainUuid;
    vtkSmartPointer<vtkDataArray> m_savedDomainCellScalarsSolid;
    vtkSmartPointer<vtkDataArray> m_savedDomainCellScalarsLine;
    bool m_domainColoringActive = false;
    bool m_savedDomainScalarVisibilitySolid = false;
    int m_savedDomainScalarModeSolid = 0;
    int m_savedDomainColorModeSolid = 0;
    bool m_savedDomainScalarVisibilityLine = false;
    int m_savedDomainScalarModeLine = 0;
    int m_savedDomainColorModeLine = 0;

  signals:
    void nodePicked(const QString& domain, const QString& activeUuid, GridKind kind, vtkIdType pid,
                    int nodeId, double x, double y, double z, const QString& prevUuid);
    void facePicked(const QString& domain, const QString& activeUuid, GridKind kind,
                    vtkIdType faceKey, bool selected);
};

#endif // PICKMANAGER_H
