﻿#include "PickManager.h"

#include <PublicVariables.h>
#include <ServiceRegistry.h>
#include <services/MeshModuleControllerService.h>
#include <services/VisualWidgetService.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <limits>
#include <utility>


// VTK
#include <vtkCell.h>
#include <vtkCellData.h>
#include <vtkCommand.h>
#include <vtkIdList.h>
#include <vtkLine.h>
#include <vtkMapper.h>
#include <vtkDataSetMapper.h>
#include <vtkCoordinate.h>
#include <vtkNew.h>
#include <vtkFieldData.h>
#include <vtkMath.h>
#include <vtkPlane.h>
#include <vtkPointData.h>
#include <vtkPolygon.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkInteractorStyle.h>
#include <vtkInteractorObserver.h>
#include <vtkInformation.h>
#include <vtkProperty2D.h>
#include <vtkRenderer.h>
#include <vtkSelection.h>
#include <vtkSelectionNode.h>
#include <vtkUnsignedCharArray.h>
#include <vtkUnstructuredGrid.h>
#include <vtkExtractCells.h>
#include <vtkIdTypeArray.h>
#include <vtkPolyData.h>
#include <vtkPolyDataMapper.h>
#include <vtkCellArray.h>
#include <vtkPoints.h>

#include <QHash>

namespace
{
vtkDataSet* dataSetFromProp(vtkProp* prop)
{
    auto* actor = vtkActor::SafeDownCast(prop);
    if (!actor)
        return nullptr;

    auto* mapper = actor->GetMapper();
    if (!mapper)
        return nullptr;

    return vtkDataSet::SafeDownCast(mapper->GetInput());
}

vtkDataArray* findArray(vtkFieldData* fd, const char* a, const char* b = nullptr)
{
    if (!fd)
        return nullptr;
    if (a)
    {
        if (auto* arr = fd->GetArray(a))
            return arr;
    }
    if (b)
        return fd->GetArray(b);
    return nullptr;
}


// Node 框选专用：从当前“显示 surface”中剔除重复的内部材料/分层界面，
// 再压缩点表，只保留真正参与外表面的节点。
//
// 背景：当前 mesh.imported.surface 为了显示 MATYPE/LAYER 分界面，会把内部界面两侧
// 都写入同一个 vtkPolyData。vtkHardwareSelector 在 POINT 模式下会对这些界面顶点编码，
// 因而可能把肉眼被外表面遮挡的内部节点也选出来。旧版 vtkDataSetSurfaceFilter 没有这个问题，
// 是因为它的输出只包含外壳且点表也是紧凑的。
//
// 这里按“一个显示小面的原始点集合”做分组：
//   - 只出现 1 次：当前显示集合的真实外表面 / 筛选后暴露面 -> 保留；
//   - 出现 2 次及以上：内部材料/分层共面界面 -> 不参与 Node 框选。
// 最后重新建立紧凑点表，并用 vtkOriginalPointIds 直接映射回完整体网格点 ID。
static vtkSmartPointer<vtkPolyData> buildNodeBoxPickSurface(vtkDataSet* source)
{
    auto out = vtkSmartPointer<vtkPolyData>::New();
    if (!source || source->GetNumberOfPoints() <= 0 || source->GetNumberOfCells() <= 0)
        return out;

    vtkDataArray* sourceOriginalPointIds =
        findArray(source->GetPointData(), "vtkOriginalPointIds", "orig_point_id");

    struct FaceRecord
    {
        QVector<vtkIdType> localPointIds;
        QByteArray key;
    };

    QVector<FaceRecord> faces;
    faces.reserve(static_cast<int>(source->GetNumberOfCells()));
    QHash<QByteArray, int> keyCounts;
    keyCounts.reserve(static_cast<int>(source->GetNumberOfCells() * 1.3));

    for (vtkIdType cid = 0; cid < source->GetNumberOfCells(); ++cid)
    {
        vtkCell* cell = source->GetCell(cid);
        if (!cell || cell->GetCellDimension() < 2)
            continue;

        vtkIdList* ids = cell->GetPointIds();
        if (!ids || ids->GetNumberOfIds() < 3)
            continue;

        FaceRecord rec;
        rec.localPointIds.reserve(static_cast<int>(ids->GetNumberOfIds()));
        QVector<vtkIdType> canonicalIds;
        canonicalIds.reserve(static_cast<int>(ids->GetNumberOfIds()));

        for (vtkIdType i = 0; i < ids->GetNumberOfIds(); ++i)
        {
            const vtkIdType localPid = ids->GetId(i);
            if (localPid < 0 || localPid >= source->GetNumberOfPoints())
                continue;

            rec.localPointIds.push_back(localPid);
            vtkIdType originalPid = localPid;
            if (sourceOriginalPointIds && localPid < sourceOriginalPointIds->GetNumberOfTuples())
                originalPid = static_cast<vtkIdType>(sourceOriginalPointIds->GetTuple1(localPid));
            canonicalIds.push_back(originalPid);
        }

        if (rec.localPointIds.size() < 3)
            continue;

        std::sort(canonicalIds.begin(), canonicalIds.end());
        canonicalIds.erase(std::unique(canonicalIds.begin(), canonicalIds.end()), canonicalIds.end());
        if (canonicalIds.size() < 3)
            continue;

        rec.key.resize(static_cast<int>(canonicalIds.size() * sizeof(vtkIdType)));
        std::memcpy(rec.key.data(), canonicalIds.constData(),
                    static_cast<size_t>(rec.key.size()));
        keyCounts[rec.key] = keyCounts.value(rec.key, 0) + 1;
        faces.push_back(std::move(rec));
    }

    if (faces.isEmpty())
        return out;

    auto points = vtkSmartPointer<vtkPoints>::New();
    auto polys = vtkSmartPointer<vtkCellArray>::New();
    auto originalPointIds = vtkSmartPointer<vtkIdTypeArray>::New();
    originalPointIds->SetName("vtkOriginalPointIds");
    originalPointIds->SetNumberOfComponents(1);

    QHash<vtkIdType, vtkIdType> sourceToPickPid;
    sourceToPickPid.reserve(static_cast<int>(source->GetNumberOfPoints() / 2 + 1));

    auto mapPoint = [&](vtkIdType sourcePid) -> vtkIdType
    {
        auto it = sourceToPickPid.constFind(sourcePid);
        if (it != sourceToPickPid.constEnd())
            return it.value();

        double p[3];
        source->GetPoint(sourcePid, p);
        const vtkIdType pickPid = points->InsertNextPoint(p);

        vtkIdType originalPid = sourcePid;
        if (sourceOriginalPointIds && sourcePid < sourceOriginalPointIds->GetNumberOfTuples())
            originalPid = static_cast<vtkIdType>(sourceOriginalPointIds->GetTuple1(sourcePid));
        originalPointIds->InsertNextValue(originalPid);
        sourceToPickPid.insert(sourcePid, pickPid);
        return pickPid;
    };

    for (const FaceRecord& rec : std::as_const(faces))
    {
        // 重复面就是同一内部界面的两侧；Node 框选只允许真正外表面。
        if (keyCounts.value(rec.key, 0) != 1)
            continue;

        polys->InsertNextCell(static_cast<vtkIdType>(rec.localPointIds.size()));
        for (vtkIdType sourcePid : rec.localPointIds)
            polys->InsertCellPoint(mapPoint(sourcePid));
    }

    out->SetPoints(points);
    out->SetPolys(polys);
    out->GetPointData()->AddArray(originalPointIds);
    out->Modified();
    return out;
}

static bool domainKeyIsValidForDisplay(const DomainKey& key)
{
    return !key.category.trimmed().isEmpty() && key.dim >= 0 && key.id != 0;
}

struct LocalCellIndexCache
{
    vtkMTimeType mtime = 0;
    QHash<vtkIdType, QVector<vtkIdType>> localIdsBySourceCell;
};

struct RgbColor
{
    unsigned char r = 199;
    unsigned char g = 199;
    unsigned char b = 199;
    unsigned char a = 255;
};

// 统一拾取/高亮颜色。kPickNormalColor 的 199/255≈0.78，必须和 MeshModuleController 的默认网格灰色一致，避免预选时普通区域闪动。
static const RgbColor kPickNormalColor   = {199, 199, 199, 255};
static const RgbColor kPickPreviewColor  = {255, 153, 0, 255};
static const RgbColor kPickSelectedColor  = {64, 170, 64, 255};
constexpr double kDomainContextOpacity = 0.20;
static const RgbColor kDomainAppliedColor   = {103, 156, 193, 255};
static const RgbColor kDomainSelectedColor  = {40, 121, 175, 255};
static const RgbColor kDomainPreviewColor   = {235, 151, 45, 255};
static const RgbColor kDomainPreDeleteColor = {200, 75, 65, 255};

constexpr double kPickPreviewR = 1.0;
constexpr double kPickPreviewG = 153.0 / 255.0;
constexpr double kPickPreviewB = 0.0;
constexpr double kPickSelectedR = 220.0 / 255.0;
constexpr double kPickSelectedG = 50.0 / 255.0;
constexpr double kPickSelectedB = 50.0 / 255.0;

struct ScalarHighlightState
{
    vtkWeakPointer<vtkDataSet> ds;
    vtkWeakPointer<vtkProp> prop;
    vtkSmartPointer<vtkDataArray> savedScalars;
    vtkSmartPointer<vtkUnsignedCharArray> colors;
    QSet<vtkIdType> previousLocalIds;
    bool active = false;
    int savedScalarVisibility = 0;
    int savedScalarMode = 0;
    int savedColorMode = 0;
};

static QHash<vtkDataSet*, LocalCellIndexCache> s_localCellIndexCaches;
static QHash<QString, ScalarHighlightState> s_scalarHighlightStates;

static vtkDataArray* originalCellIdArray(vtkDataSet* ds)
{
    return (ds && ds->GetCellData()) ? findArray(ds->GetCellData(), "vtkOriginalCellIds", "orig_cell_id") : nullptr;
}

static void rebuildLocalCellIndex(vtkDataSet* ds, LocalCellIndexCache& cache)
{
    cache.localIdsBySourceCell.clear();
    if (!ds)
    {
        cache.mtime = 0;
        return;
    }

    vtkDataArray* origArr = originalCellIdArray(ds);
    const vtkIdType n = ds->GetNumberOfCells();
    for (vtkIdType cid = 0; cid < n; ++cid)
    {
        vtkIdType key = cid;
        if (origArr && cid < origArr->GetNumberOfTuples())
            key = static_cast<vtkIdType>(origArr->GetTuple1(cid));
        cache.localIdsBySourceCell[key].push_back(cid);
    }
    cache.mtime = ds->GetMTime();
}

static void putSourceCellsToLocalColorMap(vtkDataSet* ds,
                                          const QSet<vtkIdType>& sourceCells,
                                          const RgbColor& color,
                                          QHash<vtkIdType, RgbColor>& out)
{
    if (!ds || sourceCells.isEmpty())
        return;

    LocalCellIndexCache& cache = s_localCellIndexCaches[ds];
    if (cache.mtime != ds->GetMTime() || cache.localIdsBySourceCell.isEmpty())
        rebuildLocalCellIndex(ds, cache);

    for (vtkIdType sourceCid : sourceCells)
    {
        auto it = cache.localIdsBySourceCell.constFind(sourceCid);
        if (it == cache.localIdsBySourceCell.constEnd())
            continue;

        const QVector<vtkIdType>& localIds = it.value();
        for (vtkIdType localCid : localIds)
            out.insert(localCid, color);
    }
}

static void putLocalCellsToColorMap(vtkDataSet* ds,
                                    const QVector<vtkIdType>& localCells,
                                    const RgbColor& color,
                                    QHash<vtkIdType, RgbColor>& out)
{
    if (!ds || localCells.isEmpty())
        return;

    const vtkIdType n = ds->GetNumberOfCells();
    for (vtkIdType cid : localCells)
    {
        if (cid >= 0 && cid < n)
            out.insert(cid, color);
    }
}

static bool isScalarArrayName(vtkDataArray* arr, const char* name)
{
    return arr && arr->GetName() && QString::fromUtf8(arr->GetName()) == QString::fromUtf8(name);
}

static void baseColorAt(const ScalarHighlightState& state,
                        vtkIdType cid,
                        const RgbColor& fallback,
                        unsigned char out[4])
{
    out[0] = fallback.r;
    out[1] = fallback.g;
    out[2] = fallback.b;
    out[3] = fallback.a;

    auto* saved = vtkUnsignedCharArray::SafeDownCast(state.savedScalars);
    if (!saved || saved->GetNumberOfComponents() < 3 || cid < 0 || cid >= saved->GetNumberOfTuples())
        return;

    unsigned char tmp[4] = {fallback.r, fallback.g, fallback.b, fallback.a};
    saved->GetTypedTuple(cid, tmp);
    out[0] = tmp[0];
    out[1] = tmp[1];
    out[2] = tmp[2];
}

static void restoreScalarHighlight(const QString& stateKey)
{
    auto it = s_scalarHighlightStates.find(stateKey);
    if (it == s_scalarHighlightStates.end() || !it->active)
        return;

    vtkDataSet* ds = it->ds.GetPointer();
    if (ds && ds->GetCellData())
    {
        ds->GetCellData()->SetScalars(it->savedScalars);
        ds->Modified();
    }

    auto* actor = vtkActor::SafeDownCast(it->prop.GetPointer());
    auto* mapper = actor ? actor->GetMapper() : nullptr;
    if (mapper)
    {
        mapper->SetScalarVisibility(it->savedScalarVisibility);
        mapper->SetScalarMode(it->savedScalarMode);
        mapper->SetColorMode(it->savedColorMode);
    }

    it->ds = nullptr;
    it->prop = nullptr;
    it->savedScalars = nullptr;
    it->colors = nullptr;
    it->previousLocalIds.clear();
    it->active = false;
}

static bool ensureScalarHighlight(const QString& stateKey,
                                  const char* arrayName,
                                  vtkDataSet* ds,
                                  vtkProp* prop,
                                  const RgbColor& fallback)
{
    if (!ds || !prop || !ds->GetCellData())
        return false;

    auto* actor = vtkActor::SafeDownCast(prop);
    auto* mapper = actor ? actor->GetMapper() : nullptr;
    if (!mapper)
        return false;

    ScalarHighlightState& state = s_scalarHighlightStates[stateKey];
    if (state.active && state.ds.GetPointer() != ds)
        restoreScalarHighlight(stateKey);

    if (state.active && state.colors && state.colors->GetNumberOfTuples() == ds->GetNumberOfCells())
        return true;

    if (state.active)
        restoreScalarHighlight(stateKey);

    state.ds = ds;
    state.prop = prop;
    state.savedScalars = ds->GetCellData()->GetScalars();
    state.savedScalarVisibility = mapper->GetScalarVisibility();
    state.savedScalarMode = mapper->GetScalarMode();
    state.savedColorMode = mapper->GetColorMode();
    state.colors = vtkSmartPointer<vtkUnsignedCharArray>::New();
    state.colors->SetName(arrayName);
    state.colors->SetNumberOfComponents(4);
    state.colors->SetNumberOfTuples(ds->GetNumberOfCells());
    state.previousLocalIds.clear();
    state.active = true;

    unsigned char base[4];
    for (vtkIdType cid = 0; cid < ds->GetNumberOfCells(); ++cid)
    {
        baseColorAt(state, cid, fallback, base);
        state.colors->SetTypedTuple(cid, base);
    }

    ds->GetCellData()->SetScalars(state.colors);
    mapper->SetScalarModeToUseCellData();
    mapper->SetColorModeToDirectScalars();
    mapper->ScalarVisibilityOn();
    ds->Modified();
    return true;
}

static void updateScalarHighlight(const QString& stateKey,
                                  const char* arrayName,
                                  vtkDataSet* ds,
                                  vtkProp* prop,
                                  const QHash<vtkIdType, RgbColor>& targetColors,
                                  const RgbColor& fallback)
{
    if (!ds || !prop || targetColors.isEmpty())
    {
        restoreScalarHighlight(stateKey);
        return;
    }

    if (!ensureScalarHighlight(stateKey, arrayName, ds, prop, fallback))
        return;

    ScalarHighlightState& state = s_scalarHighlightStates[stateKey];

    unsigned char base[4];
    for (vtkIdType cid : state.previousLocalIds)
    {
        if (targetColors.contains(cid) || cid < 0 || cid >= ds->GetNumberOfCells())
            continue;
        baseColorAt(state, cid, fallback, base);
        state.colors->SetTypedTuple(cid, base);
    }

    QSet<vtkIdType> nextLocalIds;
    nextLocalIds.reserve(targetColors.size());
    for (auto it = targetColors.constBegin(); it != targetColors.constEnd(); ++it)
    {
        const vtkIdType cid = it.key();
        if (cid < 0 || cid >= ds->GetNumberOfCells())
            continue;

        const RgbColor c = it.value();
        const unsigned char tuple[4] = {c.r, c.g, c.b, c.a};
        state.colors->SetTypedTuple(cid, tuple);
        nextLocalIds.insert(cid);
    }

    state.previousLocalIds = nextLocalIds;

    ds->GetCellData()->SetScalars(state.colors);
    state.colors->Modified();
    ds->Modified();

    auto* actor = vtkActor::SafeDownCast(prop);
    auto* mapper = actor ? actor->GetMapper() : nullptr;
    if (mapper)
    {
        mapper->SetScalarModeToUseCellData();
        mapper->SetColorModeToDirectScalars();
        mapper->ScalarVisibilityOn();
    }
}

static void restoreAllColorHighlights()
{
    restoreScalarHighlight(QStringLiteral("pick.domain.solid.scalar"));
    restoreScalarHighlight(QStringLiteral("pick.domain.line.scalar"));
    restoreScalarHighlight(QStringLiteral("pick.face.solid.scalar"));
}

} // namespace

static inline double dist2PointToSegment(const double x[3], const double a[3], const double b[3])
{
    double t = 0.0, closest[3];
    vtkLine::DistanceToLine(x, a, b, t, closest);
    return vtkMath::Distance2BetweenPoints(x, closest);
}

static inline quint64 makeEdgePairKey(vtkIdType a, vtkIdType b)
{
    const quint32 lo = quint32(std::min(a, b));
    const quint32 hi = quint32(std::max(a, b));
    return (quint64(hi) << 32) | quint64(lo);
}

PickManager& PickManager::instance()
{
    static PickManager s;
    return s;
}

PickManager::PickManager(QObject* parent) : QObject(parent)
{
    m_visual = ServiceRegistry::instance().getService<VisualWidgetService>();

           // callbacks
    m_cbLeftPress = vtkSmartPointer<vtkCallbackCommand>::New();
    m_cbLeftPress->SetClientData(this);
    m_cbLeftPress->SetCallback(&PickManager::OnLeftButtonPress);

    m_cbLeftRelease = vtkSmartPointer<vtkCallbackCommand>::New();
    m_cbLeftRelease->SetClientData(this);
    m_cbLeftRelease->SetCallback(&PickManager::OnLeftButtonRelease);

    m_cbMouseMove = vtkSmartPointer<vtkCallbackCommand>::New();
    m_cbMouseMove->SetClientData(this);
    m_cbMouseMove->SetCallback(&PickManager::OnMouseMove);

    m_cellPicker = vtkSmartPointer<vtkCellPicker>::New();
    m_cellPicker->SetTolerance(0.01);
    m_hwSelector = vtkSmartPointer<vtkHardwareSelector>::New();

    if (!m_visual)
        return;

    // 域选择使用独立前景层。背景网格只提供空间参照，避免状态色铺满整个模型。
    m_domainFocusGrid = vtkSmartPointer<vtkUnstructuredGrid>::New();
    m_domainFocusMapper = vtkSmartPointer<vtkDataSetMapper>::New();
    m_domainFocusMapper->SetInputData(m_domainFocusGrid);
    m_domainFocusMapper->SetScalarModeToUseCellData();
    m_domainFocusMapper->SetColorModeToDirectScalars();
    m_domainFocusMapper->ScalarVisibilityOn();
    m_domainFocusMapper->SetResolveCoincidentTopologyToPolygonOffset();
    m_domainFocusMapper->SetRelativeCoincidentTopologyPolygonOffsetParameters(-1.0, -1.0);

    m_domainFocusActor = vtkSmartPointer<vtkActor>::New();
    m_domainFocusActor->SetMapper(m_domainFocusMapper);
    m_domainFocusActor->GetProperty()->SetRepresentationToSurface();
    m_domainFocusActor->GetProperty()->EdgeVisibilityOn();
    m_domainFocusActor->GetProperty()->SetEdgeColor(0.12, 0.15, 0.18);
    m_domainFocusActor->GetProperty()->SetLineWidth(1.0);
    m_domainFocusActor->GetProperty()->LightingOn();
    m_domainFocusActor->GetProperty()->SetAmbient(0.0);
    m_domainFocusActor->GetProperty()->SetDiffuse(1.0);
    m_domainFocusActor->GetProperty()->SetSpecular(0.05);
    m_domainFocusActor->PickableOff();
    m_domainFocusActor->SetVisibility(false);

    m_visual->removeProp("pick.domain.focus", false);
    m_visual->addProp("pick.domain.focus", m_domainFocusActor,
                      QStringLiteral("当前网格域"), QStringLiteral("当前选择的网格域"), true, true);

    m_domainLineFocusGrid = vtkSmartPointer<vtkUnstructuredGrid>::New();
    m_domainLineFocusMapper = vtkSmartPointer<vtkDataSetMapper>::New();
    m_domainLineFocusMapper->SetInputData(m_domainLineFocusGrid);
    m_domainLineFocusMapper->SetScalarModeToUseCellData();
    m_domainLineFocusMapper->SetColorModeToDirectScalars();
    m_domainLineFocusMapper->ScalarVisibilityOn();

    m_domainLineFocusActor = vtkSmartPointer<vtkActor>::New();
    m_domainLineFocusActor->SetMapper(m_domainLineFocusMapper);
    m_domainLineFocusActor->GetProperty()->SetLineWidth(3.0);
    m_domainLineFocusActor->GetProperty()->LightingOn();
    m_domainLineFocusActor->PickableOff();
    m_domainLineFocusActor->SetVisibility(false);

    m_visual->removeProp("pick.domain.line.focus", false);
    m_visual->addProp("pick.domain.line.focus", m_domainLineFocusActor,
                      QStringLiteral("当前线单元域"),
                      QStringLiteral("当前选择的线单元域"), true, true);

           // ================== Node overlay ==================
    m_selPts = vtkSmartPointer<vtkPoints>::New();
    m_selPoly = vtkSmartPointer<vtkPolyData>::New();
    m_selPoly->SetPoints(m_selPts);

    m_selGlyph = vtkSmartPointer<vtkVertexGlyphFilter>::New();
    m_selGlyph->SetInputData(m_selPoly);

    m_selMapper = vtkSmartPointer<vtkPolyDataMapper>::New();
    m_selMapper->SetInputConnection(m_selGlyph->GetOutputPort());

    m_selActor = vtkSmartPointer<vtkActor>::New();
    m_selActor->SetMapper(m_selMapper);
    m_selActor->GetProperty()->SetPointSize(8);
    m_selActor->GetProperty()->SetColor(kPickSelectedR, kPickSelectedG, kPickSelectedB);
    m_selActor->GetProperty()->SetOpacity(1.0);
    m_selActor->GetProperty()->SetRenderPointsAsSpheres(true);
    m_selActor->PickableOff();

    m_visual->removeProp("pick.node", false);
    m_visual->addProp("pick.node", m_selActor, QString("{node} 选中点"), QString("拾取选中点集合"),
                      true, true);

    m_previewSelPts = vtkSmartPointer<vtkPoints>::New();
    m_previewSelPoly = vtkSmartPointer<vtkPolyData>::New();
    m_previewSelPoly->SetPoints(m_previewSelPts);
    m_previewSelGlyph = vtkSmartPointer<vtkVertexGlyphFilter>::New();
    m_previewSelGlyph->SetInputData(m_previewSelPoly);
    m_previewSelMapper = vtkSmartPointer<vtkPolyDataMapper>::New();
    m_previewSelMapper->SetInputConnection(m_previewSelGlyph->GetOutputPort());
    m_previewSelActor = vtkSmartPointer<vtkActor>::New();
    m_previewSelActor->SetMapper(m_previewSelMapper);
    m_previewSelActor->GetProperty()->SetPointSize(10);
    m_previewSelActor->GetProperty()->SetColor(kPickPreviewR, kPickPreviewG, kPickPreviewB);
    m_previewSelActor->GetProperty()->SetRenderPointsAsSpheres(true);
    m_previewSelActor->PickableOff();
    m_previewSelActor->SetVisibility(false);
    m_visual->removeProp("pick.node.preview", false);
    m_visual->addProp("pick.node.preview", m_previewSelActor, QString("{node} 预选点"),
                      QString("拾取预选点集合"), true, true);

           // ================== drag rectangle overlay ==================
    m_dragRectPts = vtkSmartPointer<vtkPoints>::New();
    m_dragRectLines = vtkSmartPointer<vtkCellArray>::New();
    m_dragRectPoly = vtkSmartPointer<vtkPolyData>::New();
    m_dragRectPoly->SetPoints(m_dragRectPts);
    m_dragRectPoly->SetLines(m_dragRectLines);
    m_dragRectMapper = vtkSmartPointer<vtkPolyDataMapper2D>::New();
    m_dragRectMapper->SetInputData(m_dragRectPoly);
    if (auto* tcoord = m_dragRectMapper->GetTransformCoordinate())
        tcoord->SetCoordinateSystemToDisplay();
    m_dragRectActor = vtkSmartPointer<vtkActor2D>::New();
    m_dragRectActor->SetMapper(m_dragRectMapper);
    m_dragRectActor->GetProperty()->SetColor(0.1, 0.8, 1.0);
    m_dragRectActor->GetProperty()->SetLineWidth(2.0);
    m_dragRectActor->SetVisibility(false);
    m_visual->removeProp("pick.drag.rect", false);
    m_visual->addProp("pick.drag.rect", m_dragRectActor, QString("{pick} 框选框"),
                      QString("拾取框选框"), true, true);

           // ================== Edge overlay (polyline) ==================
    m_edgePts = vtkSmartPointer<vtkPoints>::New();
    m_edgeLines = vtkSmartPointer<vtkCellArray>::New();
    m_edgePoly = vtkSmartPointer<vtkPolyData>::New();
    m_edgePoly->SetPoints(m_edgePts);
    m_edgePoly->SetLines(m_edgeLines);

    m_edgeMapper = vtkSmartPointer<vtkPolyDataMapper>::New();
    m_edgeMapper->SetResolveCoincidentTopologyToPolygonOffset();
    m_edgeMapper->SetRelativeCoincidentTopologyLineOffsetParameters(-1.0, -10.0);
    m_edgeMapper->SetInputData(m_edgePoly);

    m_edgeActor = vtkSmartPointer<vtkActor>::New();
    m_edgeActor->SetMapper(m_edgeMapper);
    m_edgeActor->GetProperty()->SetColor(kPickSelectedR, kPickSelectedG, kPickSelectedB);
    m_edgeActor->GetProperty()->SetLineWidth(3.0);
    m_edgeActor->GetProperty()->SetRepresentationToWireframe();
    m_edgeActor->PickableOff();
    m_edgeActor->SetVisibility(false);

    m_visual->removeProp("pick.edge", false);
    m_visual->addProp("pick.edge", m_edgeActor, QString("{edge} 选中边"),
                      QString("拾取选中边集合（edgeKey）"), true, true);

    m_previewEdgePts = vtkSmartPointer<vtkPoints>::New();
    m_previewEdgeLines = vtkSmartPointer<vtkCellArray>::New();
    m_previewEdgePoly = vtkSmartPointer<vtkPolyData>::New();
    m_previewEdgePoly->SetPoints(m_previewEdgePts);
    m_previewEdgePoly->SetLines(m_previewEdgeLines);
    m_previewEdgeMapper = vtkSmartPointer<vtkPolyDataMapper>::New();
    m_previewEdgeMapper->SetResolveCoincidentTopologyToPolygonOffset();
    m_previewEdgeMapper->SetRelativeCoincidentTopologyLineOffsetParameters(-1.0, -10.0);
    m_previewEdgeMapper->SetInputData(m_previewEdgePoly);
    m_previewEdgeActor = vtkSmartPointer<vtkActor>::New();
    m_previewEdgeActor->SetMapper(m_previewEdgeMapper);
    m_previewEdgeActor->GetProperty()->SetColor(kPickPreviewR, kPickPreviewG, kPickPreviewB);
    m_previewEdgeActor->GetProperty()->SetLineWidth(4.0);
    m_previewEdgeActor->GetProperty()->SetRepresentationToWireframe();
    m_previewEdgeActor->PickableOff();
    m_previewEdgeActor->SetVisibility(false);
    m_visual->removeProp("pick.edge.preview", false);
    m_visual->addProp("pick.edge.preview", m_previewEdgeActor, QString("{edge} 预选边"),
                      QString("拾取预选边集合"), true, true);

           // --- 交互控制 (高亮 actor 不参与 pick) ---
    m_selActor->PickableOff();
    m_edgeActor->PickableOff();

           // ================== Line node hints ==================
    m_lineNodePts = vtkSmartPointer<vtkPoints>::New();
    m_lineNodePoly = vtkSmartPointer<vtkPolyData>::New();
    m_lineNodePoly->SetPoints(m_lineNodePts);

    m_lineNodeGlyph = vtkSmartPointer<vtkVertexGlyphFilter>::New();
    m_lineNodeGlyph->SetInputData(m_lineNodePoly);

    m_lineNodeMapper = vtkSmartPointer<vtkPolyDataMapper>::New();
    m_lineNodeMapper->SetInputConnection(m_lineNodeGlyph->GetOutputPort());
    m_lineNodeMapper->ScalarVisibilityOff();

    m_lineNodeActor = vtkSmartPointer<vtkActor>::New();
    m_lineNodeActor->SetMapper(m_lineNodeMapper);
    m_lineNodeActor->GetProperty()->SetPointSize(5);
    m_lineNodeActor->GetProperty()->SetColor(0.0, 0.0, 0.0);
    m_lineNodeActor->GetProperty()->SetOpacity(1.0);
    m_lineNodeActor->GetProperty()->SetRenderPointsAsSpheres(true);
    m_lineNodeActor->PickableOff();
    m_lineNodeActor->SetVisibility(false);

    m_visual->removeProp("pick.line.nodes", false);
    m_visual->addProp("pick.line.nodes", m_lineNodeActor, QString("{line} 节点提示"),
                      QString("线网格节点提示"), true, true);

    m_visual->render();
}

void PickManager::clearNodeSelection_NoRefresh(const QString& domain, const QString& uuid,
                                               GridKind kind)
{
    if (nodeSelectionAllowsOverlap(domain))
    {
        auto& uuid2set = (kind == GridKind::Solid) ? m_pointsSolidByDomainUuid[domain]
                                                   : m_pointsLineByDomainUuid[domain];
        uuid2set[uuid].clear();
        return;
    }

    // owners: pid -> ownerUuid
    // uuid2set: uuid -> set<pid>
    // prevOwners: pid -> previousOwnerUuid （用于“抢占后可回退”）
    auto& owners = (kind == GridKind::Solid) ? m_ownerPointSolidByDomain[domain]
                                             : m_ownerPointLineByDomain[domain];

    auto& uuid2set = (kind == GridKind::Solid) ? m_pointsSolidByDomainUuid[domain]
                                               : m_pointsLineByDomainUuid[domain];

    auto& prevOwners = (kind == GridKind::Solid) ? m_prevOwnerPointSolidByDomain[domain]
                                                 : m_prevOwnerPointLineByDomain[domain];

    QSet<vtkIdType>& mySet = uuid2set[uuid];
    if (mySet.isEmpty())
        return;

    const auto keys = mySet.values(); // copy
    for (vtkIdType pid : keys)
    {
        mySet.remove(pid);

               // 如果当前 owner 就是我，先移除 owner
        if (owners.value(pid) == uuid)
            owners.remove(pid);

               // 尝试恢复之前 owner（如果存在）
        const QString oldUid = prevOwners.take(pid);
        if (!oldUid.isEmpty())
        {
            owners[pid] = oldUid;
            uuid2set[oldUid].insert(pid);
        }
    }
}

void PickManager::updateStructure()
{
    restoreDomainContextStyle();
    clearDomainFocusOverlay();
    restoreSelectionContextOpacity();
    restoreFaceColoring();

    auto* meshSvc = ServiceRegistry::instance().getService<MeshModuleControllerService>();
    if (!meshSvc)
        return;

    m_gridSolid = meshSvc->getVtkUnstructuredGridSolid();
    m_gridLine = meshSvc->getVtkUnstructuredGridLine();

    m_nodeIdArrSolid =
        (m_gridSolid) ? vtkIntArray::SafeDownCast(m_gridSolid->GetPointData()->GetArray("node_id"))
                      : nullptr;
    m_elemIdArrSolid =
        (m_gridSolid) ? vtkIntArray::SafeDownCast(m_gridSolid->GetCellData()->GetArray("elem_id"))
                      : nullptr;

    m_nodeIdArrLine =
        (m_gridLine) ? vtkIntArray::SafeDownCast(m_gridLine->GetPointData()->GetArray("node_id"))
                     : nullptr;
    m_elemIdArrLine =
        (m_gridLine) ? vtkIntArray::SafeDownCast(m_gridLine->GetCellData()->GetArray("elem_id"))
                     : nullptr;

           // 优先采用当前常用网格 prop；若没有导入网格则回退到全局网格 prop
    m_solidProp = m_visual ? m_visual->getProp("mesh.imported.surface") : nullptr;
    if (!m_solidProp && m_visual)
        m_solidProp = m_visual->getProp("mesh.global.surf");
    m_lineProp = m_visual ? m_visual->getProp("mesh.imported.line") : nullptr;
    m_solidPickDataSet = dataSetFromProp(m_solidProp);
    m_linePickDataSet = dataSetFromProp(m_lineProp);

    // 只允许拾取当前网格 actor。SMESH 网格导入后场景中可能同时保留几何、
    // 旧网格或辅助 actor；不限制 PickList 时 vtkCellPicker 可能先命中其他 prop，
    // 随后因 prop 不属于当前网格而被 pickAt() 丢弃，表现为“开启点选没有效果”。
    if (m_cellPicker)
    {
        m_cellPicker->InitializePickList();
        bool hasPickableGrid = false;
        if (m_solidProp)
        {
            m_cellPicker->AddPickList(m_solidProp);
            hasPickableGrid = true;
        }
        if (m_lineProp)
        {
            m_cellPicker->AddPickList(m_lineProp);
            hasPickableGrid = true;
        }

        if (hasPickableGrid)
            m_cellPicker->PickFromListOn();
        else
            m_cellPicker->PickFromListOff();
    }

    s_localCellIndexCaches.clear();
    restoreAllColorHighlights();

           // 导入/刷新网格时只同步数据引用，不提前构建面/边拾取索引。
           // 面索引只在 Face 模式需要，边规范化缓存只在 Edge 模式需要；
           // 大 IIIN.DAT 如果在这里全部预建，会明显拖慢导入。
    m_solidBoundaryCellsByFaceKey.clear();
    m_solidCanonicalEdgeByPointPair.clear();
    m_lineCanonicalEdgeByPointPair.clear();

    rebuildDomainHighlightActors();

    if (m_gridLine)
        rebuildLineNodeOverlayAll();

    // 显示筛选会替换 mesh.imported.surface 的 mapper 输入。此时页面可能仍停留在
    // Face/Edge/Node 模式，不能要求用户“切一次边再切回面”才能重新拾取。
    // 这里在结构刷新完成后，按当前激活模式同步重建对应索引/高亮。
    const bool hasActivePickContext = !m_currentDomain.isEmpty() && !m_currentUUid.isEmpty();
    if (hasActivePickContext)
    {
        if (m_pickMode == PickMode::Node)
        {
            markDirty(DirtyNode);
        }
        else if (m_pickMode == PickMode::Edge)
        {
            rebuildEdgeCanonicalCache();
            markDirty(DirtyEdge);
        }
        else if (m_pickMode == PickMode::Face)
        {
            rebuildBoundaryFaceCellIndex();
            markDirty(DirtyFace);
        }
        else if (m_pickMode == PickMode::Domain)
        {
            rebuildDomainHighlightActors();
        }

        // 某些页面/显示切换会拆掉交互观察器；结构更新时顺手保证当前拾取链仍有效。
        if (!m_leftPressTag || !m_leftReleaseTag || !m_mouseMoveTag)
            setupPicking();
    }
}

QSet<DomainKey> PickManager::appliedDomains(const QString& domain, const QString& uuid)
{
    return m_domainsByDomainUuid.value(domain).value(uuid);
}

DomainKey PickManager::selectedDomain(const QString& domain, const QString& uuid) const
{
    return m_selectedDomainByDomainUuid.value(domain).value(uuid, DomainKey{});
}

DomainKey PickManager::previewDomain(const QString& domain, const QString& uuid) const
{
    return m_previewDomainByDomainUuid.value(domain).value(uuid, DomainKey{});
}

DomainKey PickManager::preDeleteDomain(const QString& domain, const QString& uuid) const
{
    return m_preDeleteDomainByDomainUuid.value(domain).value(uuid, DomainKey{});
}

QString PickManager::domainOwner(const QString& domain, const DomainKey& key) const
{
    return m_ownerDomainByDomain.value(domain).value(key);
}

QSet<vtkIdType> PickManager::cellsOfDomain(const DomainKey& key) const
{
    auto* meshSvc = ServiceRegistry::instance().getService<MeshModuleControllerService>();
    if (!meshSvc || !domainKeyIsValidForDisplay(key))
        return {};

    QSet<vtkIdType> out;

           // 统一原则：域选择只认 MeshModuleController/domainCells，也就是 MeshTagSet.cellIds。
           // PickManager 不再扫描 MATYPE/LAYER CellData 做兜底，否则又会形成第二套域规则。
    const QSet<MeshIdType> src = meshSvc->domainCells(key);
    for (MeshIdType cid : src)
        out.insert(static_cast<vtkIdType>(cid));

    return out;
}

void PickManager::setAppliedDomains(const QString& domain, const QString& uuid,
                                    const QSet<DomainKey>& keys)
{
    auto& uuid2set = m_domainsByDomainUuid[domain];
    auto& owners = m_ownerDomainByDomain[domain];
    auto& prevOwners = m_prevOwnerDomainByDomain[domain];

    const QSet<DomainKey> oldSet = uuid2set.value(uuid);
    if (oldSet == keys)
        return;
    const QSet<DomainKey> removed = oldSet - keys;
    for (const DomainKey& key : removed)
    {
        if (owners.value(key) == uuid)
            owners.remove(key);

        const QString prev = prevOwners.take(key);
        if (!prev.isEmpty())
        {
            owners[key] = prev;
            uuid2set[prev].insert(key);
        }
    }

    for (const DomainKey& key : keys)
    {
        const QString oldUid = owners.value(key);
        if (!oldUid.isEmpty() && oldUid != uuid)
        {
            prevOwners[key] = oldUid;
            uuid2set[oldUid].remove(key);
        }
        owners[key] = uuid;
    }
    uuid2set[uuid] = keys;

    const DomainKey sel = m_selectedDomainByDomainUuid[domain].value(uuid, DomainKey{});
    if (domainKeyIsValidForDisplay(sel) && !keys.contains(sel))
        m_selectedDomainByDomainUuid[domain][uuid] = DomainKey{};

    const DomainKey pre = m_previewDomainByDomainUuid[domain].value(uuid, DomainKey{});
    if (domainKeyIsValidForDisplay(pre) && !keys.contains(pre))
        m_previewDomainByDomainUuid[domain][uuid] = DomainKey{};

    const DomainKey del = m_preDeleteDomainByDomainUuid[domain].value(uuid, DomainKey{});
    if (domainKeyIsValidForDisplay(del) && !keys.contains(del))
        m_preDeleteDomainByDomainUuid[domain][uuid] = DomainKey{};

    rebuildDomainHighlightActors();
}

void PickManager::setSelectedDomain(const QString& domain, const QString& uuid, const DomainKey& key)
{
    if (m_selectedDomainByDomainUuid.value(domain).value(uuid, DomainKey{}) == key)
        return;
    m_selectedDomainByDomainUuid[domain][uuid] = key;
    emit domainSelected(domain, uuid, key);
    rebuildDomainHighlightActors();
}

void PickManager::setPreviewDomain(const QString& domain, const QString& uuid, const DomainKey& key)
{
    if (m_previewDomainByDomainUuid.value(domain).value(uuid, DomainKey{}) == key)
        return;

    m_previewDomainByDomainUuid[domain][uuid] = key;

    if (domain == m_currentDomain && uuid == m_currentUUid && m_pickMode == PickMode::Domain)
        rebuildDomainHighlightActors();
}

void PickManager::setPreDeleteDomain(const QString& domain, const QString& uuid, const DomainKey& key)
{
    if (m_preDeleteDomainByDomainUuid.value(domain).value(uuid, DomainKey{}) == key)
        return;
    m_preDeleteDomainByDomainUuid[domain][uuid] = key;
    rebuildDomainHighlightActors();
}

void PickManager::clearDomainSelection(const QString& domain, const QString& uuid)
{
    if (uuid.isEmpty())
    {
        m_domainsByDomainUuid.remove(domain);
        m_ownerDomainByDomain.remove(domain);
        m_prevOwnerDomainByDomain.remove(domain);
        m_selectedDomainByDomainUuid.remove(domain);
        m_previewDomainByDomainUuid.remove(domain);
        m_preDeleteDomainByDomainUuid.remove(domain);
        rebuildDomainHighlightActors();
        return;
    }

    auto& uuid2set = m_domainsByDomainUuid[domain];
    auto& owners = m_ownerDomainByDomain[domain];
    auto& prevOwners = m_prevOwnerDomainByDomain[domain];

    const QSet<DomainKey> mySet = uuid2set.value(uuid);
    for (const DomainKey& key : mySet)
    {
        if (owners.value(key) == uuid)
            owners.remove(key);

        const QString prev = prevOwners.take(key);
        if (!prev.isEmpty())
        {
            owners[key] = prev;
            uuid2set[prev].insert(key);
        }
    }

    uuid2set.remove(uuid);
    m_selectedDomainByDomainUuid[domain].remove(uuid);
    m_previewDomainByDomainUuid[domain].remove(uuid);
    m_preDeleteDomainByDomainUuid[domain].remove(uuid);
    rebuildDomainHighlightActors();
}

void PickManager::activate(const QString& domain, const QString& uuid, PickMode mode)
{
    if (mode != PickMode::Face)
        restoreFaceColoring();
    if (mode != PickMode::Domain)
    {
        restoreDomainContextStyle();
        clearDomainFocusOverlay();
    }

    m_currentDomain = domain;
    m_currentUUid = uuid;
    m_pickMode = mode;

    updateActorVisibility();
    updateSelectionContextOpacity();

           // line node hints 仅 node 模式显示
    if (m_lineNodeActor)
    {
        const bool hasLine = (m_gridLine && m_gridLine->GetNumberOfPoints() > 0);
        const bool hasActivePickContext = !m_currentDomain.isEmpty() && !m_currentUUid.isEmpty();
        const bool show =
            m_showLineNodes && hasLine && hasActivePickContext && (m_pickMode == PickMode::Node);
        m_lineNodeActor->SetVisibility(show);
    }

           // 只在真正进入对应拾取模式时构建重索引，避免导入阶段卡顿。
    if (mode == PickMode::Node)
        markDirty(DirtyNode);
    if (mode == PickMode::Edge)
    {
        rebuildEdgeCanonicalCache();
        markDirty(DirtyEdge);
    }
    if (mode == PickMode::Face)
    {
        rebuildBoundaryFaceCellIndex();
        markDirty(DirtyFace);
    }
    if (mode == PickMode::Domain)
        rebuildDomainHighlightActors();

    if (mode == PickMode::Domain)
        teardownPicking();
    else
        setupPicking();
}

void PickManager::deactivate(const QString& domain, const QString& uuid, PickMode mode)
{
    if (domain != m_currentDomain || uuid != m_currentUUid)
        return;

           // if (mode == PickMode::Domain)
           //     clearDomainSelection(domain, uuid);

    if (mode == PickMode::Node)
        commitNodeExclusive(domain, uuid);
    if (mode == PickMode::Edge)
        commitEdgeExclusive(domain, uuid);
    if (mode == PickMode::Face)
        commitFaceExclusive(domain, uuid);

    teardownPicking();
    restoreSelectionContextOpacity();
    restoreDomainContextStyle();
    clearDomainFocusOverlay();

    if (m_styleDisabledByBoxSelect && m_visual)
    {
        if (auto* iren = m_visual->interactor())
        {
            if (auto* style = iren->GetInteractorStyle())
                style->SetEnabled(1);
        }
        m_styleDisabledByBoxSelect = false;
    }

    m_currentDomain.clear();
    m_currentUUid.clear();
    m_pickMode = PickMode::Node;
    restoreFaceColoring();

    if (m_selActor)
        m_selActor->SetVisibility(false);
    if (m_edgeActor)
        m_edgeActor->SetVisibility(false);
    if (m_lineNodeActor)
        m_lineNodeActor->SetVisibility(false);
    if (m_previewSelActor)
        m_previewSelActor->SetVisibility(false);
    if (m_previewEdgeActor)
        m_previewEdgeActor->SetVisibility(false);
    restoreAllColorHighlights();

    clearPreviewSelection(domain, uuid, PickMode::Node);
    clearPreviewSelection(domain, uuid, PickMode::Edge);
    clearPreviewSelection(domain, uuid, PickMode::Face);

           // 释放 overlay 内容（避免长时间占内存）
    if (m_selPts)
    {
        m_selPts->Reset();
        m_selPts->Modified();
    }
    if (m_selPoly)
        m_selPoly->Modified();

    if (m_edgePts)
    {
        m_edgePts->Reset();
        m_edgePts->Modified();
    }
    if (m_edgeLines)
    {
        m_edgeLines->Reset();
        m_edgeLines->Modified();
    }
    if (m_edgePoly)
        m_edgePoly->Modified();

    if (m_visual)
        m_visual->render();
}

void PickManager::resetProjectState()
{
    restoreDomainContextStyle();
    clearDomainFocusOverlay();
    restoreSelectionContextOpacity();
    restoreFaceColoring();
    restoreAllColorHighlights();
    teardownPicking();

    if (m_styleDisabledByBoxSelect && m_visual)
    {
        if (auto* interactor = m_visual->interactor())
        {
            if (auto* style = interactor->GetInteractorStyle())
                style->SetEnabled(1);
        }
    }

    m_currentDomain.clear();
    m_currentUUid.clear();
    m_pickMode = PickMode::Node;
    m_styleDisabledByBoxSelect = false;
    m_leftDown = false;
    m_dragMoved = false;
    m_dragUseBox = false;
    m_dragBoxDeselect = false;
    m_dirtyBits = DirtyNone;
    m_rebuildScheduled = false;

    m_boxSelectEnabledByDomainUuid.clear();
    m_clickPickEnabledByDomainUuid.clear();
    m_preferredDomainCategoryByDomainUuid.clear();
    m_nodeConstraintFlagsByDomainUuid.clear();
    m_ownerPointSolidByDomain.clear();
    m_pointsSolidByDomainUuid.clear();
    m_ownerPointLineByDomain.clear();
    m_pointsLineByDomainUuid.clear();
    m_prevOwnerPointSolidByDomain.clear();
    m_prevOwnerPointLineByDomain.clear();
    m_ownerEdgeSolidByDomain.clear();
    m_edgesSolidByDomainUuid.clear();
    m_ownerEdgeLineByDomain.clear();
    m_edgesLineByDomainUuid.clear();
    m_prevOwnerEdgeSolidByDomain.clear();
    m_prevOwnerEdgeLineByDomain.clear();
    m_ownerFaceSolidByDomain.clear();
    m_facesSolidByDomainUuid.clear();
    m_ownerFaceLineByDomain.clear();
    m_facesLineByDomainUuid.clear();
    m_prevOwnerFaceSolidByDomain.clear();
    m_prevOwnerFaceLineByDomain.clear();
    m_previewPointsSolidByDomainUuid.clear();
    m_previewPointsLineByDomainUuid.clear();
    m_previewEdgesSolidByDomainUuid.clear();
    m_previewEdgesLineByDomainUuid.clear();
    m_previewFacesSolidByDomainUuid.clear();
    m_previewFacesLineByDomainUuid.clear();
    m_domainsByDomainUuid.clear();
    m_ownerDomainByDomain.clear();
    m_prevOwnerDomainByDomain.clear();
    m_selectedDomainByDomainUuid.clear();
    m_previewDomainByDomainUuid.clear();
    m_preDeleteDomainByDomainUuid.clear();

    m_gridSolid = nullptr;
    m_gridLine = nullptr;
    m_nodeIdArrSolid = nullptr;
    m_elemIdArrSolid = nullptr;
    m_nodeIdArrLine = nullptr;
    m_elemIdArrLine = nullptr;
    m_solidProp = nullptr;
    m_lineProp = nullptr;
    m_solidPickDataSet = nullptr;
    m_linePickDataSet = nullptr;
    if (m_cellPicker)
    {
        m_cellPicker->InitializePickList();
        m_cellPicker->PickFromListOff();
    }
    m_solidBoundaryCellsByFaceKey.clear();
    m_solidCanonicalEdgeByPointPair.clear();
    m_lineCanonicalEdgeByPointPair.clear();
    m_savedSolidCellScalars = nullptr;
    m_faceColoringActive = false;
    m_savedDomainCellScalarsSolid = nullptr;
    m_savedDomainCellScalarsLine = nullptr;
    m_domainColoringActive = false;
    s_localCellIndexCaches.clear();
    s_scalarHighlightStates.clear();

    const auto resetPoints = [](vtkPoints* points)
    {
        if (points)
        {
            points->Reset();
            points->Modified();
        }
    };
    const auto resetLines = [](vtkCellArray* lines)
    {
        if (lines)
        {
            lines->Reset();
            lines->Modified();
        }
    };
    resetPoints(m_selPts);
    resetPoints(m_previewSelPts);
    resetPoints(m_edgePts);
    resetPoints(m_previewEdgePts);
    resetPoints(m_lineNodePts);
    resetPoints(m_dragRectPts);
    resetLines(m_edgeLines);
    resetLines(m_previewEdgeLines);
    resetLines(m_dragRectLines);

    const QList<vtkActor*> actors = {m_selActor, m_previewSelActor, m_edgeActor,
                                     m_previewEdgeActor, m_lineNodeActor};
    for (vtkActor* actor : actors)
    {
        if (actor)
            actor->SetVisibility(false);
    }
    if (m_dragRectActor)
        m_dragRectActor->SetVisibility(false);

    if (m_visual)
        m_visual->render();
}

void PickManager::updateActorVisibility()
{
    if (!m_selActor || !m_edgeActor)
        return;
    m_selActor->SetVisibility(m_pickMode == PickMode::Node);
    m_edgeActor->SetVisibility(m_pickMode == PickMode::Edge);
    if (m_previewSelActor)
        m_previewSelActor->SetVisibility(m_pickMode == PickMode::Node);
    if (m_previewEdgeActor)
        m_previewEdgeActor->SetVisibility(m_pickMode == PickMode::Edge);
}

void PickManager::restoreSelectionContextOpacity()
{
    const auto restore = [](vtkWeakPointer<vtkProp>& prop, double& savedOpacity, bool& active)
    {
        if (active)
        {
            if (auto* actor = vtkActor::SafeDownCast(prop.GetPointer()))
                actor->GetProperty()->SetOpacity(savedOpacity);
        }
        prop = nullptr;
        savedOpacity = 1.0;
        active = false;
    };

    restore(m_contextOpacitySolidProp, m_savedContextOpacitySolid,
            m_contextOpacitySolidActive);
    restore(m_contextOpacityLineProp, m_savedContextOpacityLine,
            m_contextOpacityLineActive);
}

void PickManager::updateSelectionContextOpacity()
{
    // 点、边、面选择用于约束和荷载等设置，只突出选中对象，不弱化其余网格。
    // 需要查看内部区域的透明显示由 Domain 模式单独控制。
    restoreSelectionContextOpacity();
}

void PickManager::applyDomainContextStyle()
{
    auto* solidActor = vtkActor::SafeDownCast(m_solidProp);
    auto* lineActor = vtkActor::SafeDownCast(m_lineProp);

    if (m_domainContextStyleActive &&
        (m_domainContextSolidActor.GetPointer() != solidActor ||
         m_domainContextLineActor.GetPointer() != lineActor))
    {
        restoreDomainContextStyle();
    }

    if (!m_domainContextStyleActive)
    {
        m_domainContextSolidActor = solidActor;
        m_domainContextLineActor = lineActor;

        if (solidActor)
        {
            vtkProperty* property = solidActor->GetProperty();
            m_savedDomainSolidOpacity = property->GetOpacity();
            property->GetColor(m_savedDomainSolidColor);
            m_savedDomainSolidEdgeVisibility = property->GetEdgeVisibility();
            if (auto* mapper = solidActor->GetMapper())
                m_savedDomainSolidScalarVisibility = mapper->GetScalarVisibility();
        }
        if (lineActor)
        {
            vtkProperty* property = lineActor->GetProperty();
            m_savedDomainLineOpacity = property->GetOpacity();
            property->GetColor(m_savedDomainLineColor);
            m_savedDomainLineEdgeVisibility = property->GetEdgeVisibility();
            if (auto* mapper = lineActor->GetMapper())
                m_savedDomainLineScalarVisibility = mapper->GetScalarVisibility();
        }
        m_domainContextStyleActive = true;
    }

    if (solidActor)
    {
        vtkProperty* property = solidActor->GetProperty();
        property->SetOpacity(m_savedDomainSolidOpacity * kDomainContextOpacity);
        property->SetColor(0.72, 0.75, 0.78);
        property->EdgeVisibilityOff();
        if (auto* mapper = solidActor->GetMapper())
            mapper->ScalarVisibilityOff();
    }
    if (lineActor)
    {
        vtkProperty* property = lineActor->GetProperty();
        property->SetOpacity(m_savedDomainLineOpacity * kDomainContextOpacity);
        property->SetColor(0.58, 0.62, 0.66);
        property->EdgeVisibilityOff();
        if (auto* mapper = lineActor->GetMapper())
            mapper->ScalarVisibilityOff();
    }
}

void PickManager::restoreDomainContextStyle()
{
    if (!m_domainContextStyleActive)
        return;

    if (auto* actor = m_domainContextSolidActor.GetPointer())
    {
        vtkProperty* property = actor->GetProperty();
        property->SetOpacity(m_savedDomainSolidOpacity);
        property->SetColor(m_savedDomainSolidColor);
        property->SetEdgeVisibility(m_savedDomainSolidEdgeVisibility);
        if (auto* mapper = actor->GetMapper())
            mapper->SetScalarVisibility(m_savedDomainSolidScalarVisibility);
    }
    if (auto* actor = m_domainContextLineActor.GetPointer())
    {
        vtkProperty* property = actor->GetProperty();
        property->SetOpacity(m_savedDomainLineOpacity);
        property->SetColor(m_savedDomainLineColor);
        property->SetEdgeVisibility(m_savedDomainLineEdgeVisibility);
        if (auto* mapper = actor->GetMapper())
            mapper->SetScalarVisibility(m_savedDomainLineScalarVisibility);
    }

    m_domainContextSolidActor = nullptr;
    m_domainContextLineActor = nullptr;
    m_domainContextStyleActive = false;
}

void PickManager::clearDomainFocusOverlay()
{
    if (m_domainFocusGrid)
    {
        m_domainFocusGrid->Initialize();
        m_domainFocusGrid->Modified();
    }
    if (m_domainFocusActor)
        m_domainFocusActor->SetVisibility(false);
    if (m_domainLineFocusGrid)
    {
        m_domainLineFocusGrid->Initialize();
        m_domainLineFocusGrid->Modified();
    }
    if (m_domainLineFocusActor)
        m_domainLineFocusActor->SetVisibility(false);
    m_domainFocusSolidSource = nullptr;
    m_domainFocusLineSource = nullptr;
    m_domainFocusSolidCellIds.clear();
    m_domainFocusLineCellIds.clear();
    m_domainColoringActive = false;
}

void PickManager::setupPicking()
{
    if (!m_visual)
        return;
    auto iren = m_visual->interactor();
    if (!iren)
        return;

    teardownPicking();

           // 全装，逻辑在回调里分流：不按Shift拖拽=相机；Shift拖拽=框选
    m_leftPressTag = iren->AddObserver(vtkCommand::LeftButtonPressEvent, m_cbLeftPress, 1.0);
    m_leftReleaseTag = iren->AddObserver(vtkCommand::LeftButtonReleaseEvent, m_cbLeftRelease, 1.0);
    m_mouseMoveTag = iren->AddObserver(vtkCommand::MouseMoveEvent, m_cbMouseMove, 1.0);
}

void PickManager::teardownPicking()
{
    if (!m_visual)
        return;
    auto iren = m_visual->interactor();
    if (!iren)
        return;

    if (m_leftPressTag)
    {
        iren->RemoveObserver(m_leftPressTag);
        m_leftPressTag = 0;
    }
    if (m_leftReleaseTag)
    {
        iren->RemoveObserver(m_leftReleaseTag);
        m_leftReleaseTag = 0;
    }
    if (m_mouseMoveTag)
    {
        iren->RemoveObserver(m_mouseMoveTag);
        m_mouseMoveTag = 0;
    }

}

void PickManager::OnLeftButtonPress(vtkObject* caller, unsigned long, void* clientData, void*)
{
    auto* self = static_cast<PickManager*>(clientData);
    auto iren = vtkRenderWindowInteractor::SafeDownCast(caller);
    if (!self || !iren)
        return;

    int xy[2];
    iren->GetEventPosition(xy);

    self->m_leftDown = true;
    self->m_dragMoved = false;
    self->m_dragStart[0] = xy[0];
    self->m_dragStart[1] = xy[1];
    self->m_dragEnd[0] = xy[0];
    self->m_dragEnd[1] = xy[1];

    const bool shiftBox = iren->GetShiftKey() != 0;
    const bool ctrlBox = iren->GetControlKey() != 0;
    self->m_dragUseBox =
        ((self->m_pickMode == PickMode::Node || self->m_pickMode == PickMode::Edge ||
          self->m_pickMode == PickMode::Face) &&
         self->isBoxSelectEnabledForActive() && (shiftBox || ctrlBox));
    self->m_dragBoxDeselect = ctrlBox;
    if (!self->m_dragUseBox)
    {
        if (!self->isClickPickEnabledForActive())
            return;
        self->pickAt(xy[0], xy[1]);
        return;
    }

    self->m_cbLeftPress->AbortFlagOn();

    if (auto* style = iren->GetInteractorStyle())
    {
        style->SetEnabled(0);
        self->m_styleDisabledByBoxSelect = true;
    }

    self->updateDragRect(xy[0], xy[1], xy[0], xy[1], false);
}

void PickManager::OnMouseMove(vtkObject* caller, unsigned long, void* clientData, void*)
{
    auto* self = static_cast<PickManager*>(clientData);
    auto iren = vtkRenderWindowInteractor::SafeDownCast(caller);
    if (!self || !iren || !self->m_leftDown)
        return;

    int xy[2];
    iren->GetEventPosition(xy);
    self->m_dragEnd[0] = xy[0];
    self->m_dragEnd[1] = xy[1];

    const int dx = std::abs(self->m_dragEnd[0] - self->m_dragStart[0]);
    const int dy = std::abs(self->m_dragEnd[1] - self->m_dragStart[1]);
    self->m_dragMoved = self->m_dragMoved || (dx >= 3 || dy >= 3);

    if (self->m_dragUseBox && self->m_dragMoved)
    {
        self->m_cbMouseMove->AbortFlagOn();
        self->updateDragRect(self->m_dragStart[0], self->m_dragStart[1], self->m_dragEnd[0],
                             self->m_dragEnd[1], true);
    }
}

void PickManager::OnLeftButtonRelease(vtkObject* caller, unsigned long, void* clientData, void*)
{
    auto* self = static_cast<PickManager*>(clientData);
    auto iren = vtkRenderWindowInteractor::SafeDownCast(caller);
    if (!self || !iren)
        return;

    int xy[2];
    iren->GetEventPosition(xy);
    self->m_dragEnd[0] = xy[0];
    self->m_dragEnd[1] = xy[1];

    const bool useBox = self->m_dragUseBox;
    const bool dragged = self->m_dragMoved || (std::abs(self->m_dragEnd[0]-self->m_dragStart[0])>=3) ||
                         (std::abs(self->m_dragEnd[1]-self->m_dragStart[1])>=3);

    if (useBox && dragged)
    {
        self->m_cbLeftRelease->AbortFlagOn();
        self->hardwareBoxSelect(self->m_dragStart[0], self->m_dragStart[1], self->m_dragEnd[0],
                                self->m_dragEnd[1], self->m_dragBoxDeselect);
    }
    else if (!useBox)
        ;
    else
    {
        if (self->isClickPickEnabledForActive())
            self->pickAt(xy[0], xy[1]);
    }

    if (self->m_styleDisabledByBoxSelect)
    {
        if (auto* style = iren->GetInteractorStyle())
            style->SetEnabled(1);
        self->m_styleDisabledByBoxSelect = false;
    }

    self->m_leftDown = false;
    self->m_dragMoved = false;
    self->m_dragUseBox = false;
    self->m_dragBoxDeselect = false;
    self->updateDragRect(0,0,0,0,false);
}

bool PickManager::pickAt(int x, int y)
{
    if (!m_visual || !m_cellPicker)
        return false;
    auto ren = m_visual->renderer();
    if (!ren)
        return false;

    if (!m_cellPicker->Pick(x, y, 0.0, ren))
        return false;

    vtkIdType cellId = m_cellPicker->GetCellId();
    if (cellId < 0)
        return false;

    vtkProp* pickedProp = m_cellPicker->GetViewProp();
    auto isLineProp = [&](vtkProp* p) -> bool
    {
        if (!p)
            return false;
        return p == m_lineProp;
    };
    auto isSolidProp = [&](vtkProp* p) -> bool
    {
        if (!p)
            return false;
        return p == m_solidProp;
    };

    const bool isLine = isLineProp(pickedProp);
    const bool isSolid = isSolidProp(pickedProp);

    GridKind kind;
    if (isLine)
        kind = GridKind::Line;
    else if (isSolid)
        kind = GridKind::Solid;
    else
        return false;

    vtkDataSet* ds = m_cellPicker->GetDataSet();
    vtkCell* cell = ds ? ds->GetCell(cellId) : nullptr;
    if (!cell)
        return false;

    double pickPos[3];
    m_cellPicker->GetPickPosition(pickPos);

    if (m_pickMode == PickMode::Domain)
    {
        int pickedDomainDim = (kind == GridKind::Line) ? 1 : 3;

        vtkIdType origCellId = cellId;
        vtkDataArray* origCellArr = findArray(ds->GetCellData(), "vtkOriginalCellIds", "orig_cell_id");
        if (origCellArr && cellId >= 0 && cellId < origCellArr->GetNumberOfTuples())
            origCellId = static_cast<vtkIdType>(origCellArr->GetTuple1(cellId));

        DomainKey pickedKey;
        if (auto* meshSvc = ServiceRegistry::instance().getService<MeshModuleControllerService>())
        {
            QVector<DomainKey> candidates;
            const QVector<DomainKey> domains = meshSvc->availableDomains(QString());
            // Solid actor also displays 2D meshes. Do not hard-code dimension 3.
            if (kind == GridKind::Solid)
            {
                const int actualDim = meshSvc->mshPickMapSolid().meshDim;
                if (actualDim == 2 || actualDim == 3)
                    pickedDomainDim = actualDim;
            }
            for (const DomainKey& key : domains)
            {
                if (key.dim != pickedDomainDim || key.id == 0)
                    continue;
                const QSet<MeshIdType> cells = meshSvc->domainCells(key);
                if (cells.contains(static_cast<MeshIdType>(origCellId)))
                    candidates.push_back(key);
            }

            // Materials, excavation and other pages do not use the same category.
            // A preferred category prevents clicking a cave LAYER from selecting MATYPE.
            const QString preferred = m_preferredDomainCategoryByDomainUuid
                .value(m_currentDomain).value(m_currentUUid);
            if (!preferred.isEmpty())
            {
                for (const DomainKey& key : candidates)
                {
                    if (key.category.compare(preferred, Qt::CaseInsensitive) == 0 &&
                        domainKeyIsValidForDisplay(key))
                    {
                        pickedKey = key;
                        break;
                    }
                }
                if (!domainKeyIsValidForDisplay(pickedKey))
                    return false; // Never silently select a different business category.
            }

                   // 负数目前主要出现在 LAYER 中；先识别负数 LAYER，避免被同一单元上的 MATYPE 抢先选走。
            for (const DomainKey& key : candidates)
            {
                if (!preferred.isEmpty()) break;
                if (key.category.compare(QStringLiteral("LAYER"), Qt::CaseInsensitive) == 0 && key.id < 0)
                {
                    pickedKey = key;
                    break;
                }
            }

            if (!domainKeyIsValidForDisplay(pickedKey))
            {
                for (const DomainKey& key : candidates)
                {
                    if (key.category.compare(QStringLiteral("MATYPE"), Qt::CaseInsensitive) == 0)
                    {
                        pickedKey = key;
                        break;
                    }
                }
            }

            if (!domainKeyIsValidForDisplay(pickedKey))
            {
                for (const DomainKey& key : candidates)
                {
                    if (domainKeyIsValidForDisplay(key))
                    {
                        pickedKey = key;
                        break;
                    }
                }
            }
        }

        if (!domainKeyIsValidForDisplay(pickedKey))
            return false;

        setSelectedDomain(m_currentDomain, m_currentUUid, pickedKey);
        return true;
    }

    if (m_pickMode == PickMode::Edge)
    {
        int edgeLocalId = 15;
        QVector<vtkIdType> edgePids;
        if (kind == GridKind::Solid)
        {
            if (auto* ug = vtkUnstructuredGrid::SafeDownCast(ds))
            {
                vtkCell* pickedCell = ug->GetCell(cellId);
                if (pickedCell && pickedCell->GetCellDimension() <= 2)
                {
                    if (!computePickedEdge(ug, cellId, pickPos, edgeLocalId, edgePids))
                        return false;
                    toggleSelectEdge(kind, packEdgeKey(cellId, edgeLocalId));
                    return true;
                }
            }
            vtkIdType origCellId = -1;
            int origEdgeLocalId = 15;
            if (!computePickedEdgeFromBoundary(ds, cellId, pickPos, origCellId, origEdgeLocalId))
                return false;
            toggleSelectEdge(kind, packEdgeKey(origCellId, origEdgeLocalId));
        }
        else
        {
            auto* grid = vtkUnstructuredGrid::SafeDownCast(ds);
            if (!grid || !computePickedEdge(grid, cellId, pickPos, edgeLocalId, edgePids))
                return false;
            toggleSelectEdge(kind, packEdgeKey(cellId, edgeLocalId));
        }
        return true;
    }

    if (m_pickMode == PickMode::Face)
    {
        // 面拾取只针对 Solid；lineGrid 不参与面拾取。
        if (kind != GridKind::Solid)
            return false;

        int faceLocalId = 15;
        QVector<vtkIdType> facePids;
        if (auto* ug = vtkUnstructuredGrid::SafeDownCast(ds))
        {
            vtkCell* pickedCell = ug->GetCell(cellId);
            if (pickedCell && pickedCell->GetCellDimension() == 2)
            {
                if (!computePickedFace(ug, cellId, pickPos, faceLocalId, facePids))
                    return false;
                toggleSelectFace(kind, packFaceKey(cellId, faceLocalId));
                return true;
            }
        }

        vtkIdType origCellId = -1;
        int origFaceLocalId = 15;
        if (!computePickedFaceFromBoundary(ds, cellId, origCellId, origFaceLocalId))
            return false;
        // computePickedFaceFromBoundary 已经返回与 MeshTagSet.faceKeys 一致的 localId。
        // 2D 面单元统一使用 localId=15，不能再改成 0，否则点选/框选生成的 faceKey
        // 会和下拉框中的 MeshTagSet.faceKeys 不一致，表现为高亮乱跳。
        toggleSelectFace(kind, packFaceKey(origCellId, origFaceLocalId));
        return true;
    }

           // Node：在 cell 顶点里找最近 pid
    vtkIdList* ids = cell->GetPointIds();
    if (!ids || ids->GetNumberOfIds() <= 0)
        return false;

    vtkIdType bestPid = -1;
    double bestD2 = std::numeric_limits<double>::max();

    vtkDataArray* origPointArr = nullptr;
    if (kind == GridKind::Solid)
        origPointArr = findArray(ds->GetPointData(), "vtkOriginalPointIds", "orig_point_id");

    for (vtkIdType i = 0; i < ids->GetNumberOfIds(); ++i)
    {
        vtkIdType pid = ids->GetId(i);
        double p[3];
        ds->GetPoint(pid, p);
        double d2 = vtkMath::Distance2BetweenPoints(p, pickPos);
        if (d2 < bestD2)
        {
            bestD2 = d2;
            bestPid = (origPointArr ? vtkIdType(origPointArr->GetTuple1(pid)) : pid);
        }
    }
    if (bestPid < 0)
        return false;

    toggleSelectNode(kind, bestPid);
    return true;
}

// ===================== coalesced rebuild/render =====================
void PickManager::markDirty(int bits)
{
    m_dirtyBits |= bits;
    if (m_rebuildScheduled)
        return;

    m_rebuildScheduled = true;
    flushRebuild();
}

void PickManager::flushRebuild()
{
    m_rebuildScheduled = false;

    if (!m_visual)
    {
        m_dirtyBits = DirtyNone;
        return;
    }

    updateActorVisibility();

    if (m_dirtyBits & DirtyNode)
        rebuildPointsForActive();
    if (m_dirtyBits & DirtyEdge)
        rebuildEdgePolyForActive();
    if (m_dirtyBits & DirtyFace)
    {
        rebuildFaceColorForActive();
    }

    if (!(m_dirtyBits & DirtyFace) && m_pickMode != PickMode::Face)
        restoreFaceColoring();

    updateSelectionContextOpacity();
    m_dirtyBits = DirtyNone;
    m_visual->render();
}

// ===================== Node =====================
void PickManager::toggleSelectNode(GridKind kind, vtkIdType pid)
{
    if (m_currentDomain.isEmpty() || m_currentUUid.isEmpty())
        return;

    const QString dom = m_currentDomain;
    const QString uid = m_currentUUid;

    auto& uuid2set =
        (kind == GridKind::Solid) ? m_pointsSolidByDomainUuid[dom] : m_pointsLineByDomainUuid[dom];
    QSet<vtkIdType>& mySet = uuid2set[uid];
    QString prevUuid;

    if (nodeSelectionAllowsOverlap(dom))
    {
        // 位移约束等允许共享节点的 domain：每个约束保留自己的选区，
        // 不再把节点从旧约束中“抢走”。prevUuid 仅作为兼容信号，返回一个已有共享来源。
        if (mySet.contains(pid))
        {
            mySet.remove(pid);
        }
        else
        {
            const int nid = nodeIdForPoint(kind, pid);
            if (nid >= 0)
            {
                const QStringList sources = selectedNodeUuids(dom, nid);
                for (const QString& sourceUuid : sources)
                {
                    if (sourceUuid != uid)
                    {
                        prevUuid = sourceUuid;
                        break;
                    }
                }
            }
            mySet.insert(pid);
        }
    }
    else
    {
        auto& owners =
            (kind == GridKind::Solid) ? m_ownerPointSolidByDomain[dom] : m_ownerPointLineByDomain[dom];
        auto& prevOwners = (kind == GridKind::Solid) ? m_prevOwnerPointSolidByDomain[dom]
                                                     : m_prevOwnerPointLineByDomain[dom];

        if (mySet.contains(pid))
        {
            mySet.remove(pid);
            if (owners.value(pid) == uid)
                owners.remove(pid);

            const QString oldUid = prevOwners.take(pid);
            if (!oldUid.isEmpty())
            {
                owners[pid] = oldUid;
                uuid2set[oldUid].insert(pid);
            }
        }
        else
        {
            const QString oldUid = owners.value(pid);
            if (!oldUid.isEmpty() && oldUid != uid)
            {
                prevUuid = oldUid;
                prevOwners[pid] = oldUid;
                uuid2set[oldUid].remove(pid);
            }
            owners[pid] = uid;
            mySet.insert(pid);
        }
    }

    // 发信号（单点选）
    vtkUnstructuredGrid* grid = (kind == GridKind::Solid) ? m_gridSolid : m_gridLine;
    vtkIntArray* nodeIdArr = (kind == GridKind::Solid) ? m_nodeIdArrSolid : m_nodeIdArrLine;
    if (!nodeIdArr && grid)
        nodeIdArr = vtkIntArray::SafeDownCast(grid->GetPointData()->GetArray("node_id"));

    if (grid && nodeIdArr)
    {
        const vtkIdType nPts = grid->GetNumberOfPoints();
        if (pid >= 0 && pid < nPts)
        {
            double p[3];
            grid->GetPoint(pid, p);
            const int nodeId = nodeIdArr->GetValue(int(pid));
            emit nodePicked(dom, uid, kind, pid, nodeId, p[0], p[1], p[2], prevUuid);
        }
    }

    emit selectionChanged(dom, uid, PickMode::Node, kind);
    markDirty(DirtyNode);
}

void PickManager::rebuildPointsForActive()
{
    if (!m_selPts)
        return;

    m_selPts->Reset();

           // 预估点数，减少内部扩容
    vtkIdType approx = 0;
    if (m_gridSolid)
        approx += m_pointsSolidByDomainUuid.value(m_currentDomain).value(m_currentUUid).size();
    if (m_gridLine)
        approx += m_pointsLineByDomainUuid.value(m_currentDomain).value(m_currentUUid).size();
    if (approx > 0)
        m_selPts->Allocate(approx);

    if (m_gridSolid)
    {
        const auto setS = m_pointsSolidByDomainUuid.value(m_currentDomain).value(m_currentUUid);
        for (vtkIdType pid : setS)
        {
            if (pid < 0 || pid >= m_gridSolid->GetNumberOfPoints())
                continue;
            double p[3];
            m_gridSolid->GetPoint(pid, p);
            m_selPts->InsertNextPoint(p);
        }
    }

    if (m_gridLine)
    {
        const auto setL = m_pointsLineByDomainUuid.value(m_currentDomain).value(m_currentUUid);
        for (vtkIdType pid : setL)
        {
            if (pid < 0 || pid >= m_gridLine->GetNumberOfPoints())
                continue;
            double p[3];
            m_gridLine->GetPoint(pid, p);
            m_selPts->InsertNextPoint(p);
        }
    }

    m_selPts->Modified();
    if (m_selPoly)
        m_selPoly->Modified();
}

// ===================== Edge =====================
bool PickManager::computePickedEdge(vtkUnstructuredGrid* grid, vtkIdType cellId,
                                    const double pickPos[3], int& outEdgeLocalId,
                                    QVector<vtkIdType>& outEdgePids) const
{
    outEdgePids.clear();
    if (!grid)
        return false;

    vtkCell* cell = grid->GetCell(cellId);
    if (!cell)
        return false;

    const int dim = cell->GetCellDimension();

           // 1D：整条线就是 edge
    if (dim == 1)
    {
        vtkIdList* ids = cell->GetPointIds();
        if (!ids || ids->GetNumberOfIds() < 2)
            return false;

        outEdgeLocalId = 15; // sentinel
        outEdgePids.reserve(ids->GetNumberOfIds());
        for (vtkIdType i = 0; i < ids->GetNumberOfIds(); ++i)
            outEdgePids.push_back(ids->GetId(i));
        return true;
    }

    const int nEdges = cell->GetNumberOfEdges();
    if (nEdges <= 0)
        return false;

    int bestEi = -1;
    double bestD2 = std::numeric_limits<double>::max();
    QVector<vtkIdType> bestPids;

    for (int ei = 0; ei < nEdges; ++ei)
    {
        vtkCell* e = cell->GetEdge(ei);
        if (!e)
            continue;

        vtkIdList* eids = e->GetPointIds();
        if (!eids || eids->GetNumberOfIds() < 2)
            continue;

        const int n = int(eids->GetNumberOfIds());
        QVector<vtkIdType> epids;
        epids.reserve(n);
        for (int k = 0; k < n; ++k)
            epids.push_back(eids->GetId(k));

        double minSegD2 = std::numeric_limits<double>::max();
        for (int k = 0; k < n - 1; ++k)
        {
            double pa[3], pb[3];
            grid->GetPoint(epids[k], pa);
            grid->GetPoint(epids[k + 1], pb);

            const double d2 = dist2PointToSegment(pickPos, pa, pb);
            if (d2 < minSegD2)
                minSegD2 = d2;
        }

        if (minSegD2 < bestD2)
        {
            bestD2 = minSegD2;
            bestEi = ei;
            bestPids = epids;
        }
    }

    if (bestEi < 0)
        return false;
    outEdgeLocalId = bestEi;
    outEdgePids = bestPids;
    return true;
}

void PickManager::rebuildEdgeCanonicalCache()
{
    m_solidCanonicalEdgeByPointPair.clear();
    m_lineCanonicalEdgeByPointPair.clear();

    auto buildOne = [this](vtkUnstructuredGrid* grid, QHash<quint64, vtkIdType>& outMap)
    {
        if (!grid)
            return;
        for (vtkIdType cid = 0; cid < grid->GetNumberOfCells(); ++cid)
        {
            vtkCell* cell = grid->GetCell(cid);
            if (!cell)
                continue;

            const int dim = cell->GetCellDimension();
            if (dim == 1)
            {
                auto* ids = cell->GetPointIds();
                if (!ids || ids->GetNumberOfIds() < 2)
                    continue;
                const vtkIdType edgeKey = packEdgeKey(cid, 15);
                const quint64 pairKey = makeEdgePairKey(ids->GetId(0), ids->GetId(ids->GetNumberOfIds() - 1));
                auto it = outMap.find(pairKey);
                if (it == outMap.end() || edgeKey < it.value())
                    outMap[pairKey] = edgeKey;
                continue;
            }

            const int nEdges = cell->GetNumberOfEdges();
            for (int ei = 0; ei < nEdges; ++ei)
            {
                vtkCell* e = cell->GetEdge(ei);
                if (!e)
                    continue;
                auto* ids = e->GetPointIds();
                if (!ids || ids->GetNumberOfIds() < 2)
                    continue;
                const vtkIdType edgeKey = packEdgeKey(cid, ei);
                const quint64 pairKey = makeEdgePairKey(ids->GetId(0), ids->GetId(ids->GetNumberOfIds() - 1));
                auto it = outMap.find(pairKey);
                if (it == outMap.end() || edgeKey < it.value())
                    outMap[pairKey] = edgeKey;
            }
        }
    };

    buildOne(m_gridSolid, m_solidCanonicalEdgeByPointPair);
    buildOne(m_gridLine, m_lineCanonicalEdgeByPointPair);
}

vtkIdType PickManager::canonicalizeEdgeKey(GridKind kind, vtkIdType edgeKey) const
{
    vtkUnstructuredGrid* grid = (kind == GridKind::Solid) ? m_gridSolid : m_gridLine;
    const auto& canonicalMap =
        (kind == GridKind::Solid) ? m_solidCanonicalEdgeByPointPair : m_lineCanonicalEdgeByPointPair;
    if (!grid || canonicalMap.isEmpty())
        return edgeKey;

    const vtkIdType cid = unpackEdgeCellId(edgeKey);
    const int ei = unpackEdgeLocalId(edgeKey);
    if (cid < 0 || cid >= grid->GetNumberOfCells())
        return edgeKey;

    vtkCell* cell = grid->GetCell(cid);
    if (!cell)
        return edgeKey;

    vtkIdType a = -1;
    vtkIdType b = -1;
    if (cell->GetCellDimension() == 1 || ei == 15)
    {
        auto* ids = cell->GetPointIds();
        if (!ids || ids->GetNumberOfIds() < 2)
            return edgeKey;
        a = ids->GetId(0);
        b = ids->GetId(ids->GetNumberOfIds() - 1);
    }
    else
    {
        if (ei < 0 || ei >= cell->GetNumberOfEdges())
            return edgeKey;
        vtkCell* e = cell->GetEdge(ei);
        if (!e)
            return edgeKey;
        auto* ids = e->GetPointIds();
        if (!ids || ids->GetNumberOfIds() < 2)
            return edgeKey;
        a = ids->GetId(0);
        b = ids->GetId(ids->GetNumberOfIds() - 1);
    }

    const quint64 pairKey = makeEdgePairKey(a, b);
    return canonicalMap.value(pairKey, edgeKey);
}

bool PickManager::computePickedEdgeFromBoundary(vtkDataSet* pickedDs, vtkIdType pickedCellId,
                                                const double pickPos[3],
                                                vtkIdType& outOrigCellId,
                                                int& outOrigEdgeLocalId) const
{
    outOrigCellId = -1;
    outOrigEdgeLocalId = 15;
    if (!pickedDs || !m_gridSolid)
        return false;

    auto* origCellArr = findArray(pickedDs->GetCellData(), "vtkOriginalCellIds", "orig_cell_id");
    auto* origPointArr =
        findArray(pickedDs->GetPointData(), "vtkOriginalPointIds", "orig_point_id");
    if (!origCellArr || !origPointArr)
        return false;

    vtkCell* pickedCell = pickedDs->GetCell(pickedCellId);
    if (!pickedCell)
        return false;

    outOrigCellId = vtkIdType(origCellArr->GetTuple1(pickedCellId));
    if (outOrigCellId < 0 || outOrigCellId >= m_gridSolid->GetNumberOfCells())
        return false;
    vtkCell* origCell = m_gridSolid->GetCell(outOrigCellId);
    if (!origCell)
        return false;

    vtkIdList* pids = pickedCell->GetPointIds();
    if (!pids || pids->GetNumberOfIds() < 2)
        return false;

    vtkIdType a = -1;
    vtkIdType b = -1;
    double best = std::numeric_limits<double>::max();
    const vtkIdType nIds = pids->GetNumberOfIds();
    const bool closedLoop = (pickedCell->GetCellDimension() > 1);
    const vtkIdType nSegs = closedLoop ? nIds : (nIds - 1);
    for (vtkIdType i = 0; i < nSegs; ++i)
    {
        vtkIdType pa = pids->GetId(i);
        vtkIdType pb = pids->GetId((i + 1) % nIds);
        double p0[3], p1[3];
        pickedDs->GetPoint(pa, p0);
        pickedDs->GetPoint(pb, p1);
        const double d2 = dist2PointToSegment(pickPos, p0, p1);
        if (d2 < best)
        {
            best = d2;
            a = vtkIdType(origPointArr->GetTuple1(pa));
            b = vtkIdType(origPointArr->GetTuple1(pb));
        }
    }
    if (a < 0 || b < 0)
        return false;

           // 先按统一后的 MeshTagSet.edgeKeys 反查。
           // 下拉框批量选择用的就是这组 edgeKeys；手工点选也必须产出同一种 key，
           // 否则会出现“下拉框正确、点选/框选乱窜”的不一致。
    if (auto* meshSvc = ServiceRegistry::instance().getService<MeshModuleControllerService>())
    {
        const QVector<MeshTagSet> sets = meshSvc->boundaryTagSets(1);
        for (const MeshTagSet& set : sets)
        {
            for (MeshIdType rawKey : set.edgeKeys)
            {
                const vtkIdType edgeKey = static_cast<vtkIdType>(rawKey);
                const vtkIdType cid = unpackEdgeCellId(edgeKey);
                const int ei = unpackEdgeLocalId(edgeKey);
                if (cid != outOrigCellId)
                    continue;

                if (origCell->GetCellDimension() == 1 || ei == 15)
                {
                    vtkIdList* eids = origCell->GetPointIds();
                    if (!eids || eids->GetNumberOfIds() < 2)
                        continue;
                    bool hasA = false;
                    bool hasB = false;
                    for (vtkIdType k = 0; k < eids->GetNumberOfIds(); ++k)
                    {
                        const vtkIdType pid = eids->GetId(k);
                        hasA = hasA || (pid == a);
                        hasB = hasB || (pid == b);
                    }
                    if (hasA && hasB)
                    {
                        outOrigEdgeLocalId = 15;
                        return true;
                    }
                    continue;
                }

                if (ei < 0 || ei >= origCell->GetNumberOfEdges())
                    continue;
                vtkCell* e = origCell->GetEdge(ei);
                if (!e)
                    continue;
                vtkIdList* eids = e->GetPointIds();
                if (!eids || eids->GetNumberOfIds() < 2)
                    continue;
                bool hasA = false;
                bool hasB = false;
                for (vtkIdType k = 0; k < eids->GetNumberOfIds(); ++k)
                {
                    const vtkIdType pid = eids->GetId(k);
                    hasA = hasA || (pid == a);
                    hasB = hasB || (pid == b);
                }
                if (hasA && hasB)
                {
                    outOrigEdgeLocalId = ei;
                    return true;
                }
            }
        }
    }

    const int nEdges = origCell->GetNumberOfEdges();
    int bestEdge = -1;
    double bestEdgeD2 = std::numeric_limits<double>::max();
    for (int ei = 0; ei < nEdges; ++ei)
    {
        vtkCell* e = origCell->GetEdge(ei);
        if (!e)
            continue;
        vtkIdList* eids = e->GetPointIds();
        if (!eids || eids->GetNumberOfIds() < 2)
            continue;
        bool hasA = false;
        bool hasB = false;
        for (vtkIdType k = 0; k < eids->GetNumberOfIds(); ++k)
        {
            const vtkIdType epid = eids->GetId(k);
            if (epid == a)
                hasA = true;
            if (epid == b)
                hasB = true;
        }
        if (hasA && hasB)
        {
            double edgeBestD2 = std::numeric_limits<double>::max();
            for (vtkIdType k = 0; k + 1 < eids->GetNumberOfIds(); ++k)
            {
                const vtkIdType p0id = eids->GetId(k);
                const vtkIdType p1id = eids->GetId(k + 1);
                if (p0id < 0 || p1id < 0)
                    continue;
                double p0[3], p1[3];
                m_gridSolid->GetPoint(p0id, p0);
                m_gridSolid->GetPoint(p1id, p1);
                edgeBestD2 = std::min(edgeBestD2, dist2PointToSegment(pickPos, p0, p1));
            }

            if (edgeBestD2 < bestEdgeD2)
            {
                bestEdgeD2 = edgeBestD2;
                bestEdge = ei;
            }
        }
    }
    if (bestEdge < 0)
    {
        // 回退：当边界点映射到同一原始点（或高阶细分导致 a/b 不稳定）时，
        // 直接按几何距离在原单元所有边中选最近边，提升“可选中性”。
        for (int ei = 0; ei < nEdges; ++ei)
        {
            vtkCell* e = origCell->GetEdge(ei);
            if (!e)
                continue;
            vtkIdList* eids = e->GetPointIds();
            if (!eids || eids->GetNumberOfIds() < 2)
                continue;

            double edgeBestD2 = std::numeric_limits<double>::max();
            for (vtkIdType k = 0; k + 1 < eids->GetNumberOfIds(); ++k)
            {
                const vtkIdType p0id = eids->GetId(k);
                const vtkIdType p1id = eids->GetId(k + 1);
                if (p0id < 0 || p1id < 0)
                    continue;
                double p0[3], p1[3];
                m_gridSolid->GetPoint(p0id, p0);
                m_gridSolid->GetPoint(p1id, p1);
                edgeBestD2 = std::min(edgeBestD2, dist2PointToSegment(pickPos, p0, p1));
            }

            if (edgeBestD2 < bestEdgeD2)
            {
                bestEdgeD2 = edgeBestD2;
                bestEdge = ei;
            }
        }
    }
    if (bestEdge < 0)
        return false;
    outOrigEdgeLocalId = bestEdge;
    return true;
}

void PickManager::toggleSelectEdge(GridKind kind, vtkIdType edgeKey)
{
    if (m_currentDomain.isEmpty() || m_currentUUid.isEmpty())
        return;

    const QString dom = m_currentDomain;
    const QString uid = m_currentUUid;

    edgeKey = canonicalizeEdgeKey(kind, edgeKey);
    auto& owners =
        (kind == GridKind::Solid) ? m_ownerEdgeSolidByDomain[dom] : m_ownerEdgeLineByDomain[dom];
    auto& uuid2set =
        (kind == GridKind::Solid) ? m_edgesSolidByDomainUuid[dom] : m_edgesLineByDomainUuid[dom];
    auto& prevOwners = (kind == GridKind::Solid) ? m_prevOwnerEdgeSolidByDomain[dom]
                                                 : m_prevOwnerEdgeLineByDomain[dom];

    QSet<vtkIdType>& mySet = uuid2set[uid];

    if (mySet.contains(edgeKey))
    {
        mySet.remove(edgeKey);
        if (owners.value(edgeKey) == uid)
            owners.remove(edgeKey);

        const QString oldUid = prevOwners.take(edgeKey);
        if (!oldUid.isEmpty())
        {
            owners[edgeKey] = oldUid;
            uuid2set[oldUid].insert(edgeKey);
        }
    }
    else
    {
        const QString oldUid = owners.value(edgeKey);
        if (!oldUid.isEmpty() && oldUid != uid)
        {
            prevOwners[edgeKey] = oldUid;
            uuid2set[oldUid].remove(edgeKey);
        }
        owners[edgeKey] = uid;
        mySet.insert(edgeKey);
    }

    emit selectionChanged(dom, uid, PickMode::Edge, kind);
    markDirty(DirtyEdge);
}

void PickManager::rebuildEdgePolyForActive()
{
    if (!m_edgePts || !m_edgeLines || !m_edgePoly)
        return;

    m_edgePts->Reset();
    m_edgeLines->Reset();

    const auto setS = m_edgesSolidByDomainUuid.value(m_currentDomain).value(m_currentUUid);
    const auto setL = m_edgesLineByDomainUuid.value(m_currentDomain).value(m_currentUUid);

           // 预估：每条边至少2点
    vtkIdType approxPts = vtkIdType(setS.size() + setL.size()) * 2;
    if (approxPts > 0)
        m_edgePts->Allocate(approxPts);

    auto buildOne = [&](vtkUnstructuredGrid* grid, const QSet<vtkIdType>& set)
    {
        if (!grid)
            return;

        for (vtkIdType edgeKey : set)
        {
            vtkIdType cellId = unpackEdgeCellId(edgeKey);
            int edgeLocalId = unpackEdgeLocalId(edgeKey);
            if (cellId < 0 || cellId >= grid->GetNumberOfCells())
                continue;

            vtkCell* cell = grid->GetCell(cellId);
            if (!cell)
                continue;

            QVector<vtkIdType> epids;

            if (cell->GetCellDimension() == 1 || edgeLocalId == 15)
            {
                vtkIdList* ids = cell->GetPointIds();
                if (!ids || ids->GetNumberOfIds() < 2)
                    continue;
                for (vtkIdType i = 0; i < ids->GetNumberOfIds(); ++i)
                    epids.push_back(ids->GetId(i));
            }
            else
            {
                if (edgeLocalId < 0 || edgeLocalId >= cell->GetNumberOfEdges())
                    continue;
                vtkCell* e = cell->GetEdge(edgeLocalId);
                if (!e)
                    continue;
                vtkIdList* ids = e->GetPointIds();
                if (!ids || ids->GetNumberOfIds() < 2)
                    continue;
                for (vtkIdType i = 0; i < ids->GetNumberOfIds(); ++i)
                    epids.push_back(ids->GetId(i));
            }

            const vtkIdType n = epids.size();
            m_edgeLines->InsertNextCell(n);
            for (vtkIdType k = 0; k < n; ++k)
            {
                double p[3];
                grid->GetPoint(epids[int(k)], p);
                vtkIdType lpid = m_edgePts->InsertNextPoint(p);
                m_edgeLines->InsertCellPoint(lpid);
            }
        }
    };

    buildOne(m_gridSolid, setS);
    buildOne(m_gridLine, setL);

    m_edgePts->Modified();
    m_edgeLines->Modified();
    m_edgePoly->Modified();
}

// ===================== Face =====================
bool PickManager::computePickedFace(vtkUnstructuredGrid* grid, vtkIdType cellId,
                                    const double pickPos[3], int& outFaceLocalId,
                                    QVector<vtkIdType>& outFacePids) const
{
    outFacePids.clear();
    if (!grid)
        return false;

    vtkCell* cell = grid->GetCell(cellId);
    if (!cell)
        return false;

    const int dim = cell->GetCellDimension();

           // 2D：整片就是 face
    if (dim == 2)
    {
        vtkIdList* ids = cell->GetPointIds();
        if (!ids || ids->GetNumberOfIds() < 3)
            return false;
        outFaceLocalId = 15;
        for (vtkIdType i = 0; i < ids->GetNumberOfIds(); ++i)
            outFacePids.push_back(ids->GetId(i));
        return true;
    }

    if (dim != 3)
        return false;

    const int nFaces = cell->GetNumberOfFaces();
    if (nFaces <= 0)
        return false;

    int bestFace = -1;
    double bestScore = std::numeric_limits<double>::max();
    QVector<vtkIdType> bestPids;

    for (int fi = 0; fi < nFaces; ++fi)
    {
        vtkCell* face = cell->GetFace(fi);
        if (!face)
            continue;

        vtkIdList* fids = face->GetPointIds();
        if (!fids || fids->GetNumberOfIds() < 3)
            continue;

        const int npts = int(fids->GetNumberOfIds());
        QVector<double> pts(npts * 3);

        double bounds[6] = {
                            +std::numeric_limits<double>::max(), -std::numeric_limits<double>::max(),
                            +std::numeric_limits<double>::max(), -std::numeric_limits<double>::max(),
                            +std::numeric_limits<double>::max(), -std::numeric_limits<double>::max()};

        for (int i = 0; i < npts; ++i)
        {
            double p[3];
            grid->GetPoint(fids->GetId(i), p);
            pts[i * 3 + 0] = p[0];
            pts[i * 3 + 1] = p[1];
            pts[i * 3 + 2] = p[2];

            bounds[0] = std::min(bounds[0], p[0]);
            bounds[1] = std::max(bounds[1], p[0]);
            bounds[2] = std::min(bounds[2], p[1]);
            bounds[3] = std::max(bounds[3], p[1]);
            bounds[4] = std::min(bounds[4], p[2]);
            bounds[5] = std::max(bounds[5], p[2]);
        }

        double n[3] = {0, 0, 0};
        vtkPolygon::ComputeNormal(npts, pts.data(), n);
        if (vtkMath::Norm(n) < 1e-12)
            continue;

        double p0[3] = {pts[0], pts[1], pts[2]};

        const double dist =
            std::abs(vtkPlane::DistanceToPlane(const_cast<double*>(pickPos), n, p0));
        const int inside =
            vtkPolygon::PointInPolygon(const_cast<double*>(pickPos), npts, pts.data(), bounds, n);
        const double score = inside ? dist : (dist + 1e3);

        if (score < bestScore)
        {
            bestScore = score;
            bestFace = fi;
            bestPids.clear();
            for (int i = 0; i < npts; ++i)
                bestPids.push_back(fids->GetId(i));
        }
    }

    if (bestFace < 0 || bestPids.isEmpty())
        return false;
    outFaceLocalId = bestFace;
    outFacePids = bestPids;
    return true;
}

bool PickManager::computePickedFaceFromBoundary(vtkDataSet* pickedDs, vtkIdType pickedCellId,
                                                vtkIdType& outOrigCellId,
                                                int& outOrigFaceLocalId) const
{
    outOrigCellId = -1;
    outOrigFaceLocalId = 15;
    if (!pickedDs || !m_gridSolid)
        return false;

           // 最快路径：MeshModuleController 构造 surface 时直接写入 faceKey。
           // PickManager 不再根据点集反推 faceKey，避免大网格下预选/框选时重复计算。
    if (auto* faceKeyArr = findArray(pickedDs->GetCellData(), "vtkOriginalFaceKeys", "orig_face_key"))
    {
        if (pickedCellId >= 0 && pickedCellId < faceKeyArr->GetNumberOfTuples())
        {
            const vtkIdType faceKey = static_cast<vtkIdType>(faceKeyArr->GetTuple1(pickedCellId));
            outOrigCellId = static_cast<vtkIdType>(faceKey >> 4);
            outOrigFaceLocalId = static_cast<int>(faceKey & 0xF);
            return outOrigCellId >= 0 && outOrigCellId < m_gridSolid->GetNumberOfCells();
        }
    }

    auto* origCellArr = findArray(pickedDs->GetCellData(), "vtkOriginalCellIds", "orig_cell_id");
    if (!origCellArr || pickedCellId < 0 || pickedCellId >= origCellArr->GetNumberOfTuples())
        return false;

    vtkCell* pickedCell = pickedDs->GetCell(pickedCellId);
    if (!pickedCell)
        return false;

    outOrigCellId = vtkIdType(origCellArr->GetTuple1(pickedCellId));
    if (outOrigCellId < 0 || outOrigCellId >= m_gridSolid->GetNumberOfCells())
        return false;
    vtkCell* origCell = m_gridSolid->GetCell(outOrigCellId);
    if (!origCell)
        return false;

           // 自建内部域 surface 会直接写入原始面 local id；优先使用它。
           // 这样不依赖 vtkOriginalPointIds 反推，也能正确高亮内部交界面。
    if (auto* origFaceArr = findArray(pickedDs->GetCellData(), "vtkOriginalFaceIds", "orig_face_id"))
    {
        if (pickedCellId >= 0 && pickedCellId < origFaceArr->GetNumberOfTuples())
        {
            const int fid = static_cast<int>(origFaceArr->GetTuple1(pickedCellId));
            if (origCell->GetCellDimension() == 2)
            {
                outOrigFaceLocalId = 15;
                return true;
            }
            if (fid >= 0 && fid < origCell->GetNumberOfFaces())
            {
                outOrigFaceLocalId = fid;
                return true;
            }
        }
    }

    auto* origPointArr =
        findArray(pickedDs->GetPointData(), "vtkOriginalPointIds", "orig_point_id");
    if (!origPointArr)
        return false;

    QSet<vtkIdType> pickedOrigPids;
    vtkIdList* ids = pickedCell->GetPointIds();
    if (!ids || ids->GetNumberOfIds() < 3)
        return false;
    for (vtkIdType i = 0; i < ids->GetNumberOfIds(); ++i)
    {
        const vtkIdType opid = vtkIdType(origPointArr->GetTuple1(ids->GetId(i)));
        if (opid >= 0)
            pickedOrigPids.insert(opid);
    }
    if (pickedOrigPids.size() < 3)
        return false;

           // 先按统一后的 MeshTagSet.faceKeys 反查。
           // 批量下拉框、预览高亮和手工点选必须使用同一套 faceKey。
           // 这里优先在 tagSets 里找当前原始 cell 对应的 faceKey，避免仅靠 vtkOriginalPointIds
           // 的子集判断时，高阶单元/细分面把 local face 判断到相邻面上。
    if (auto* meshSvc = ServiceRegistry::instance().getService<MeshModuleControllerService>())
    {
        int bestLocalId = -1;
        int bestScore = -1;

        const QVector<MeshTagSet> sets = meshSvc->boundaryTagSets(2);
        for (const MeshTagSet& set : sets)
        {
            for (MeshIdType rawKey : set.faceKeys)
            {
                const vtkIdType faceKey = static_cast<vtkIdType>(rawKey);
                const vtkIdType cid = unpackFaceCellId(faceKey);
                int fid = unpackFaceLocalId(faceKey);
                if (cid != outOrigCellId)
                    continue;

                QSet<vtkIdType> facePids;
                if (origCell->GetCellDimension() == 2 || fid == 15)
                {
                    vtkIdList* cids = origCell->GetPointIds();
                    if (!cids || cids->GetNumberOfIds() < 3)
                        continue;
                    fid = 15;
                    for (vtkIdType i = 0; i < cids->GetNumberOfIds(); ++i)
                        facePids.insert(cids->GetId(i));
                }
                else
                {
                    if (fid < 0 || fid >= origCell->GetNumberOfFaces())
                        continue;
                    vtkCell* f = origCell->GetFace(fid);
                    if (!f)
                        continue;
                    vtkIdList* fids = f->GetPointIds();
                    if (!fids || fids->GetNumberOfIds() < 3)
                        continue;
                    for (vtkIdType i = 0; i < fids->GetNumberOfIds(); ++i)
                        facePids.insert(fids->GetId(i));
                }

                bool subset = true;
                int hitCount = 0;
                for (vtkIdType pid : pickedOrigPids)
                {
                    if (!facePids.contains(pid))
                    {
                        subset = false;
                        break;
                    }
                    ++hitCount;
                }
                if (!subset)
                    continue;

                const bool exact = (facePids.size() == pickedOrigPids.size());
                const int score = (exact ? 100000 : 0) + hitCount;
                if (score > bestScore)
                {
                    bestScore = score;
                    bestLocalId = fid;
                }
            }
        }

        if (bestLocalId >= 0)
        {
            outOrigFaceLocalId = bestLocalId;
            return true;
        }
    }

           // 2D 原单元没有 faces：整片即一个“face”(localId=15)
    if (origCell->GetCellDimension() == 2)
    {
        vtkIdList* cids = origCell->GetPointIds();
        if (!cids || cids->GetNumberOfIds() < 3)
            return false;
        QSet<vtkIdType> cellPids;
        for (vtkIdType i = 0; i < cids->GetNumberOfIds(); ++i)
            cellPids.insert(cids->GetId(i));
        for (vtkIdType pid : pickedOrigPids)
        {
            if (!cellPids.contains(pid))
                return false;
        }
        // 高阶单元经 surface filter 后，picked cell 可能是细分后的子面（点数与原面不同）。
        // 这里采用“picked 点集是原面点集子集”判定，而非点数完全一致。
        outOrigFaceLocalId = 15;
        return true;
    }

    const int nFaces = origCell->GetNumberOfFaces();
    int bestFace = -1;
    int bestHit = -1;
    for (int fi = 0; fi < nFaces; ++fi)
    {
        vtkCell* face = origCell->GetFace(fi);
        if (!face)
            continue;
        vtkIdList* fids = face->GetPointIds();
        if (!fids || fids->GetNumberOfIds() < 3)
            continue;

        QSet<vtkIdType> facePids;
        for (vtkIdType i = 0; i < fids->GetNumberOfIds(); ++i)
            facePids.insert(fids->GetId(i));

        bool subset = true;
        int hitCount = 0;
        for (vtkIdType pid : pickedOrigPids)
        {
            if (!facePids.contains(pid))
            {
                subset = false;
                break;
            }
            ++hitCount;
        }
        if (subset && hitCount > bestHit)
        {
            bestHit = hitCount;
            bestFace = fi;
        }
    }
    if (bestFace < 0)
        return false;
    outOrigFaceLocalId = bestFace;
    return true;
}

void PickManager::toggleSelectFace(GridKind kind, vtkIdType faceKey)
{
    if (m_currentDomain.isEmpty() || m_currentUUid.isEmpty())
        return;

    const QString dom = m_currentDomain;
    const QString uid = m_currentUUid;

    auto& owners =
        (kind == GridKind::Solid) ? m_ownerFaceSolidByDomain[dom] : m_ownerFaceLineByDomain[dom];
    auto& uuid2set =
        (kind == GridKind::Solid) ? m_facesSolidByDomainUuid[dom] : m_facesLineByDomainUuid[dom];
    auto& prevOwners = (kind == GridKind::Solid) ? m_prevOwnerFaceSolidByDomain[dom]
                                                 : m_prevOwnerFaceLineByDomain[dom];

    QSet<vtkIdType>& mySet = uuid2set[uid];

    if (mySet.contains(faceKey))
    {
        mySet.remove(faceKey);
        if (owners.value(faceKey) == uid)
            owners.remove(faceKey);

        const QString oldUid = prevOwners.take(faceKey);
        if (!oldUid.isEmpty())
        {
            owners[faceKey] = oldUid;
            uuid2set[oldUid].insert(faceKey);
        }
    }
    else
    {
        const QString oldUid = owners.value(faceKey);
        if (!oldUid.isEmpty() && oldUid != uid)
        {
            prevOwners[faceKey] = oldUid;
            uuid2set[oldUid].remove(faceKey);
        }
        owners[faceKey] = uid;
        mySet.insert(faceKey);
    }

    const bool selectedNow = mySet.contains(faceKey);
    emit selectionChanged(dom, uid, PickMode::Face, kind);
    emit facePicked(dom, uid, kind, faceKey, selectedNow);

    markDirty(DirtyFace);
}

void PickManager::rebuildBoundaryFaceCellIndex()
{
    m_solidBoundaryCellsByFaceKey.clear();

    auto buildOne = [&](vtkDataSet* pickedDs, vtkUnstructuredGrid* sourceGrid,
                        QHash<vtkIdType, QVector<vtkIdType>>& out)
    {
        if (!pickedDs || !sourceGrid)
            return;
        if (auto* faceKeyArr = findArray(pickedDs->GetCellData(), "vtkOriginalFaceKeys", "orig_face_key"))
        {
            const vtkIdType n = qMin(pickedDs->GetNumberOfCells(), faceKeyArr->GetNumberOfTuples());
            for (vtkIdType cid = 0; cid < n; ++cid)
            {
                const vtkIdType faceKey = static_cast<vtkIdType>(faceKeyArr->GetTuple1(cid));
                out[faceKey].push_back(cid);
            }
            return;
        }

        const vtkIdType nCells = pickedDs->GetNumberOfCells();
        for (vtkIdType cid = 0; cid < nCells; ++cid)
        {
            vtkIdType srcCellId = -1;
            int srcFaceLocalId = 15;
            if (!computePickedFaceFromBoundary(pickedDs, cid, srcCellId, srcFaceLocalId))
                continue;
            // srcFaceLocalId 必须保持 computePickedFaceFromBoundary 的结果：
            // 3D 体单元为真实 local face id，2D 面单元为 15。
            // 这里不能把 2D 面单元改成 0，否则和 MeshTagSet.faceKeys 不一致。
            out[packFaceKey(srcCellId, srcFaceLocalId)].push_back(cid);
        }
    };

    buildOne(m_solidPickDataSet, m_gridSolid, m_solidBoundaryCellsByFaceKey);
}

QVector<vtkIdType> PickManager::connectedVisibleFacePatch(vtkIdType seedFaceKey,
                                                           double angleToleranceDeg) const
{
    QVector<vtkIdType> result;
    if (!m_gridSolid || m_solidBoundaryCellsByFaceKey.isEmpty()
        || !m_solidBoundaryCellsByFaceKey.contains(seedFaceKey))
    {
        if (seedFaceKey >= 0)
            result.push_back(seedFaceKey);
        return result;
    }

    struct VisibleFaceInfo
    {
        vtkIdType key = -1;
        double normal[3] = {0.0, 0.0, 0.0};
        double centroid[3] = {0.0, 0.0, 0.0};
        QVector<quint64> edges;
    };

    auto normalize = [](double v[3]) -> bool
    {
        const double n = vtkMath::Norm(v);
        if (n <= 1.0e-15)
            return false;
        v[0] /= n;
        v[1] /= n;
        v[2] /= n;
        return true;
    };

    auto faceCellForKey = [this](vtkIdType faceKey) -> vtkCell*
    {
        const vtkIdType cellId = unpackFaceCellId(faceKey);
        const int localFaceId = unpackFaceLocalId(faceKey);
        if (cellId < 0 || cellId >= m_gridSolid->GetNumberOfCells())
            return nullptr;
        vtkCell* cell = m_gridSolid->GetCell(cellId);
        if (!cell)
            return nullptr;
        if (cell->GetCellDimension() == 2 || localFaceId == 15)
            return cell;
        if (localFaceId < 0 || localFaceId >= cell->GetNumberOfFaces())
            return nullptr;
        return cell->GetFace(localFaceId);
    };

    QHash<vtkIdType, VisibleFaceInfo> infos;
    infos.reserve(m_solidBoundaryCellsByFaceKey.size());
    QHash<quint64, QVector<vtkIdType>> edgeOwners;

    const QList<vtkIdType> visibleKeys = m_solidBoundaryCellsByFaceKey.keys();
    for (vtkIdType faceKey : visibleKeys)
    {
        vtkCell* face = faceCellForKey(faceKey);
        vtkIdList* ids = face ? face->GetPointIds() : nullptr;
        if (!ids || ids->GetNumberOfIds() < 3)
            continue;

        VisibleFaceInfo info;
        info.key = faceKey;

        // Newell 法计算多边形法向，同时求中心。使用完整体网格点 ID，
        // 因而筛选后暴露出的内部面也能和相邻可见面稳定建立共享边关系。
        const vtkIdType npts = ids->GetNumberOfIds();
        QVector<std::array<double, 3>> pts;
        pts.reserve(int(npts));
        for (vtkIdType i = 0; i < npts; ++i)
        {
            double p[3] = {0.0, 0.0, 0.0};
            m_gridSolid->GetPoint(ids->GetId(i), p);
            pts.push_back({p[0], p[1], p[2]});
            info.centroid[0] += p[0];
            info.centroid[1] += p[1];
            info.centroid[2] += p[2];
        }
        const double inv = 1.0 / double(npts);
        info.centroid[0] *= inv;
        info.centroid[1] *= inv;
        info.centroid[2] *= inv;
        for (int i = 0; i < pts.size(); ++i)
        {
            const auto& a = pts[i];
            const auto& b = pts[(i + 1) % pts.size()];
            info.normal[0] += (a[1] - b[1]) * (a[2] + b[2]);
            info.normal[1] += (a[2] - b[2]) * (a[0] + b[0]);
            info.normal[2] += (a[0] - b[0]) * (a[1] + b[1]);
        }
        if (!normalize(info.normal))
            continue;

        const int edgeCount = face->GetNumberOfEdges();
        if (edgeCount > 0)
        {
            info.edges.reserve(edgeCount);
            for (int ei = 0; ei < edgeCount; ++ei)
            {
                vtkCell* edge = face->GetEdge(ei);
                vtkIdList* eids = edge ? edge->GetPointIds() : nullptr;
                if (!eids || eids->GetNumberOfIds() < 2)
                    continue;
                const quint64 edgeKey =
                    makeEdgePairKey(eids->GetId(0), eids->GetId(eids->GetNumberOfIds() - 1));
                info.edges.push_back(edgeKey);
                edgeOwners[edgeKey].push_back(faceKey);
            }
        }
        else
        {
            info.edges.reserve(int(npts));
            for (vtkIdType i = 0; i < npts; ++i)
            {
                const quint64 edgeKey =
                    makeEdgePairKey(ids->GetId(i), ids->GetId((i + 1) % npts));
                info.edges.push_back(edgeKey);
                edgeOwners[edgeKey].push_back(faceKey);
            }
        }
        infos.insert(faceKey, info);
    }

    if (!infos.contains(seedFaceKey))
        return {seedFaceKey};

    const VisibleFaceInfo seed = infos.value(seedFaceKey);
    double bounds[6] = {0, 0, 0, 0, 0, 0};
    m_gridSolid->GetBounds(bounds);
    const double span = std::max({bounds[1] - bounds[0], bounds[3] - bounds[2],
                                  bounds[5] - bounds[4]});
    const double planeTol = std::max(1.0e-9, span * 1.0e-7);
    const double clampedAngle = std::max(0.1, std::min(45.0, angleToleranceDeg));
    const double cosTol = std::cos(vtkMath::RadiansFromDegrees(clampedAngle));

    QSet<vtkIdType> visited;
    QVector<vtkIdType> queue{seedFaceKey};
    while (!queue.isEmpty())
    {
        const vtkIdType key = queue.takeLast();
        if (visited.contains(key) || !infos.contains(key))
            continue;
        const VisibleFaceInfo& info = infos[key];

        if (std::abs(vtkMath::Dot(seed.normal, info.normal)) < cosTol)
            continue;
        const double dc[3] = {info.centroid[0] - seed.centroid[0],
                              info.centroid[1] - seed.centroid[1],
                              info.centroid[2] - seed.centroid[2]};
        if (std::abs(vtkMath::Dot(seed.normal, dc)) > planeTol)
            continue;

        visited.insert(key);
        for (quint64 edgeKey : info.edges)
        {
            const QVector<vtkIdType> neighbours = edgeOwners.value(edgeKey);
            for (vtkIdType next : neighbours)
                if (!visited.contains(next))
                    queue.push_back(next);
        }
    }

    result.reserve(visited.size());
    for (vtkIdType key : visited)
        result.push_back(key);
    std::sort(result.begin(), result.end());
    if (result.isEmpty())
        result.push_back(seedFaceKey);
    return result;
}

void PickManager::rebuildFaceColorForActive()
{
    if (!m_visual || m_currentDomain.isEmpty() || m_currentUUid.isEmpty())
        return;

    if (!m_solidPickDataSet || m_solidPickDataSet->GetNumberOfCells() <= 0)
        return;

    const auto selectedSolid = m_facesSolidByDomainUuid.value(m_currentDomain).value(m_currentUUid);
    const auto previewSolid = m_previewFacesSolidByDomainUuid.value(m_currentDomain).value(m_currentUUid);

    if (selectedSolid.isEmpty() && previewSolid.isEmpty())
    {
        restoreFaceColoring();
        return;
    }

    const RgbColor normal = kPickNormalColor;
    const RgbColor previewColor = kPickPreviewColor;
    const RgbColor selectedColor = kPickSelectedColor;

    QHash<vtkIdType, RgbColor> targetColors;

    auto appendFaceKeys = [&](const QSet<vtkIdType>& faceKeys, const RgbColor& color)
    {
        QVector<vtkIdType> localCells;
        for (vtkIdType fk : faceKeys)
        {
            const QVector<vtkIdType> cids = m_solidBoundaryCellsByFaceKey.value(fk);
            for (vtkIdType cid : cids)
                localCells.push_back(cid);
        }
        putLocalCellsToColorMap(m_solidPickDataSet, localCells, color, targetColors);
    };

           // 选中优先级高于预选。
    appendFaceKeys(previewSolid, previewColor);
    appendFaceKeys(selectedSolid, selectedColor);

    updateScalarHighlight(QStringLiteral("pick.face.solid.scalar"),
                          "pick_face_colors",
                          m_solidPickDataSet,
                          m_solidProp,
                          targetColors,
                          normal);

    m_faceColoringActive = true;

    if (m_visual)
        m_visual->render();
}

void PickManager::restoreFaceColoring()
{
    if (!m_faceColoringActive)
        return;

    restoreScalarHighlight(QStringLiteral("pick.face.solid.scalar"));
    m_faceColoringActive = false;
    rebuildDomainHighlightActors();
}

void PickManager::rebuildDomainHighlightActors()
{
    if (!m_visual)
        return;

    const auto clearDisplay = [this]()
    {
        restoreScalarHighlight(QStringLiteral("pick.domain.solid.scalar"));
        restoreScalarHighlight(QStringLiteral("pick.domain.line.scalar"));
        restoreDomainContextStyle();
        clearDomainFocusOverlay();
        m_domainColoringActive = false;
    };

    if (m_pickMode != PickMode::Domain)
    {
        if (m_domainColoringActive)
        {
            clearDisplay();
            m_visual->render();
        }
        return;
    }

    const QSet<DomainKey> applied = m_domainsByDomainUuid.value(m_currentDomain).value(m_currentUUid);
    const DomainKey selected =
        m_selectedDomainByDomainUuid.value(m_currentDomain).value(m_currentUUid, DomainKey{});
    const DomainKey preview =
        m_previewDomainByDomainUuid.value(m_currentDomain).value(m_currentUUid, DomainKey{});
    const DomainKey preDelete =
        m_preDeleteDomainByDomainUuid.value(m_currentDomain).value(m_currentUUid, DomainKey{});

    const bool hasAny = !applied.isEmpty() || domainKeyIsValidForDisplay(selected) ||
                        domainKeyIsValidForDisplay(preview) || domainKeyIsValidForDisplay(preDelete);
    if (!hasAny)
    {
        if (m_domainColoringActive)
        {
            clearDisplay();
            m_visual->render();
        }
        return;
    }

    const auto isMaterialDomain = [](const DomainKey& key)
    {
        return domainKeyIsValidForDisplay(key) &&
               key.category.compare(QStringLiteral("MATYPE"), Qt::CaseInsensitive) == 0;
    };
    const bool isMaterialSelection =
        std::any_of(applied.cbegin(), applied.cend(), isMaterialDomain) ||
        isMaterialDomain(selected) || isMaterialDomain(preview) || isMaterialDomain(preDelete);
    // CaveExcavationBody 的实际 pick domain 为 "CaveExcavationBody/<uuid>"。
    // 不能使用完全相等判断，否则开挖体分组选择时不会进入材料选择同款的
    // 半透明上下文显示，内部开挖体会被外层模型遮挡。
    const bool isCaveExcavationBodySelection =
        m_currentDomain.compare(QStringLiteral("CaveExcavationBody"), Qt::CaseInsensitive) == 0 ||
        m_currentDomain.startsWith(QStringLiteral("CaveExcavationBody/"), Qt::CaseInsensitive);
    const bool useTransparentContext =
        isCaveExcavationBodySelection || isMaterialSelection;

    QSet<vtkIdType> appliedSolidCells;
    QSet<vtkIdType> appliedLineCells;
    QSet<vtkIdType> previewSolidCells;
    QSet<vtkIdType> previewLineCells;
    QSet<vtkIdType> selectedSolidCells;
    QSet<vtkIdType> selectedLineCells;
    QSet<vtkIdType> preDeleteSolidCells;
    QSet<vtkIdType> preDeleteLineCells;

    auto addCellsByDim = [this](const DomainKey& key,
                                QSet<vtkIdType>& solidCells,
                                QSet<vtkIdType>& lineCells)
    {
        if (!domainKeyIsValidForDisplay(key))
            return;

        // 材料是跨实体/杆单元的统一属性，需要同步显示不同维度；施工层和
        // Physical 分组按 DomainKey.dim 精确显示，避免选择开挖体时带上杆单元。
        const bool spansDimensions =
            key.category.compare(QStringLiteral("MATYPE"), Qt::CaseInsensitive) == 0;

        if (key.dim == 1)
        {
            lineCells.unite(cellsOfDomain(key));
            if (spansDimensions)
            {
                solidCells.unite(cellsOfDomain(DomainKey{key.category, 2, key.id}));
                solidCells.unite(cellsOfDomain(DomainKey{key.category, 3, key.id}));
            }
        }
        else
        {
            solidCells.unite(cellsOfDomain(key));
            if (spansDimensions)
                lineCells.unite(cellsOfDomain(DomainKey{key.category, 1, key.id}));
        }
    };

    for (const DomainKey& key : applied)
        addCellsByDim(key, appliedSolidCells, appliedLineCells);

    addCellsByDim(preview, previewSolidCells, previewLineCells);
    addCellsByDim(selected, selectedSolidCells, selectedLineCells);
    addCellsByDim(preDelete, preDeleteSolidCells, preDeleteLineCells);

    QHash<vtkIdType, RgbColor> solidFocusColors;
    QHash<vtkIdType, RgbColor> lineFocusColors;
    const auto appendCells = [this, &solidFocusColors, &lineFocusColors](
                                 const QSet<vtkIdType>& solidCells,
                                 const QSet<vtkIdType>& lineCells,
                                 const RgbColor& color)
    {
        putSourceCellsToLocalColorMap(m_solidPickDataSet, solidCells, color, solidFocusColors);
        putSourceCellsToLocalColorMap(m_linePickDataSet, lineCells, color, lineFocusColors);
    };

    // 已施加域始终可见；当前项、悬停项和待移除项按顺序覆盖基础色。
    appendCells(appliedSolidCells, appliedLineCells, kDomainAppliedColor);

    if (domainKeyIsValidForDisplay(selected))
    {
        const bool selectedIsApplied = std::any_of(
            applied.cbegin(), applied.cend(),
            [&selected](const DomainKey& key)
            {
                return key.category.compare(selected.category, Qt::CaseInsensitive) == 0 &&
                       key.id == selected.id;
            });
        appendCells(selectedSolidCells, selectedLineCells,
                    selectedIsApplied ? kDomainSelectedColor : kDomainPreviewColor);
    }

    if (domainKeyIsValidForDisplay(preview))
        appendCells(previewSolidCells, previewLineCells, kDomainPreviewColor);

    if (domainKeyIsValidForDisplay(preDelete))
        appendCells(preDeleteSolidCells, preDeleteLineCells, kDomainPreDeleteColor);

    if (solidFocusColors.isEmpty() && lineFocusColors.isEmpty())
    {
        clearDisplay();
        m_visual->render();
        return;
    }

    const auto updateFocusGrid = [](vtkDataSet* sourceGrid,
                                    vtkUnstructuredGrid* focusGrid,
                                    const QHash<vtkIdType, RgbColor>& focusColors,
                                    const char* colorArrayName,
                                    vtkDataSet*& cachedSource,
                                    QVector<vtkIdType>& cachedCellIds) -> bool
    {
        if (!sourceGrid || !focusGrid || focusColors.isEmpty())
        {
            if (focusGrid)
            {
                focusGrid->Initialize();
                focusGrid->Modified();
            }
            cachedSource = nullptr;
            cachedCellIds.clear();
            return false;
        }

        QVector<vtkIdType> validCellIds;
        validCellIds.reserve(focusColors.size());
        for (auto it = focusColors.cbegin(); it != focusColors.cend(); ++it)
        {
            const vtkIdType cid = it.key();
            if (cid < 0 || cid >= sourceGrid->GetNumberOfCells())
                continue;
            validCellIds.push_back(cid);
        }
        std::sort(validCellIds.begin(), validCellIds.end());

        if (validCellIds.isEmpty())
        {
            focusGrid->Initialize();
            focusGrid->Modified();
            cachedSource = nullptr;
            cachedCellIds.clear();
            return false;
        }

        const bool canReuseExtraction =
            cachedSource == sourceGrid && cachedCellIds == validCellIds &&
            focusGrid->GetNumberOfCells() == validCellIds.size();
        if (!canReuseExtraction)
        {
            vtkNew<vtkIdList> ids;
            ids->SetNumberOfIds(validCellIds.size());
            for (qsizetype i = 0; i < validCellIds.size(); ++i)
                ids->SetId(i, validCellIds.at(i));

            vtkNew<vtkExtractCells> extractCells;
            extractCells->SetInputData(sourceGrid);
            extractCells->SetCellList(ids);
            extractCells->AssumeSortedAndUniqueIdsOn();
            extractCells->Update();

            focusGrid->ShallowCopy(extractCells->GetOutput());
            if (focusGrid->GetNumberOfCells() != validCellIds.size())
            {
                focusGrid->Initialize();
                focusGrid->Modified();
                cachedSource = nullptr;
                cachedCellIds.clear();
                return false;
            }

            cachedSource = sourceGrid;
            cachedCellIds = validCellIds;
        }

        auto* colors = vtkUnsignedCharArray::SafeDownCast(
            focusGrid->GetCellData()->GetArray(colorArrayName));
        if (!colors || colors->GetNumberOfComponents() != 3 ||
            colors->GetNumberOfTuples() != validCellIds.size())
        {
            auto newColors = vtkSmartPointer<vtkUnsignedCharArray>::New();
            newColors->SetName(colorArrayName);
            newColors->SetNumberOfComponents(3);
            newColors->SetNumberOfTuples(validCellIds.size());
            focusGrid->GetCellData()->SetScalars(newColors);
            colors = newColors;
        }

        for (qsizetype i = 0; i < validCellIds.size(); ++i)
        {
            const RgbColor color = focusColors.value(validCellIds.at(i), kDomainAppliedColor);
            const unsigned char tuple[3] = {color.r, color.g, color.b};
            colors->SetTypedTuple(i, tuple);
        }

        colors->Modified();
        if (!canReuseExtraction)
            focusGrid->Modified();
        return focusGrid->GetNumberOfCells() > 0;
    };

    const bool hasSolidFocus = updateFocusGrid(m_solidPickDataSet, m_domainFocusGrid,
                                               solidFocusColors,
                                               "pick_domain_focus_solid_colors",
                                               m_domainFocusSolidSource,
                                               m_domainFocusSolidCellIds);
    const bool hasLineFocus = updateFocusGrid(m_linePickDataSet, m_domainLineFocusGrid,
                                              lineFocusColors,
                                              "pick_domain_focus_line_colors",
                                              m_domainFocusLineSource,
                                              m_domainFocusLineCellIds);
    if (!hasSolidFocus && !hasLineFocus)
    {
        clearDisplay();
        m_visual->render();
        return;
    }

    m_domainFocusActor->SetVisibility(hasSolidFocus);
    m_domainLineFocusActor->SetVisibility(hasLineFocus);
    if (useTransparentContext)
        applyDomainContextStyle();
    else
        restoreDomainContextStyle();

    m_domainColoringActive = true;
    m_visual->render();
}

// ===================== clearSelection =====================
void PickManager::clearSelection(const QString& domain, const QString& uuid, PickMode mode)
{
    if (mode == PickMode::Domain)
    {
        clearDomainSelection(domain, uuid);
        return;
    }

    auto clearOneKind = [&](GridKind kind)
    {
        if (mode == PickMode::Node)
        {
            if (nodeSelectionAllowsOverlap(domain))
            {
                auto& uuid2set = (kind == GridKind::Solid) ? m_pointsSolidByDomainUuid[domain]
                                                           : m_pointsLineByDomainUuid[domain];
                uuid2set[uuid].clear();
                return;
            }

            auto& owners = (kind == GridKind::Solid) ? m_ownerPointSolidByDomain[domain]
                                                     : m_ownerPointLineByDomain[domain];
            auto& uuid2set = (kind == GridKind::Solid) ? m_pointsSolidByDomainUuid[domain]
                                                       : m_pointsLineByDomainUuid[domain];
            auto& prevOwners = (kind == GridKind::Solid) ? m_prevOwnerPointSolidByDomain[domain]
                                                         : m_prevOwnerPointLineByDomain[domain];

            QSet<vtkIdType>& mySet = uuid2set[uuid];
            const auto keys = mySet.values(); // copy
            for (vtkIdType k : keys)
            {
                mySet.remove(k);
                if (owners.value(k) == uuid)
                    owners.remove(k);

                const QString oldUid = prevOwners.take(k);
                if (!oldUid.isEmpty())
                {
                    owners[k] = oldUid;
                    uuid2set[oldUid].insert(k);
                }
            }
            return;
        }

        if (mode == PickMode::Edge)
        {
            auto& owners = (kind == GridKind::Solid) ? m_ownerEdgeSolidByDomain[domain]
                                                     : m_ownerEdgeLineByDomain[domain];
            auto& uuid2set = (kind == GridKind::Solid) ? m_edgesSolidByDomainUuid[domain]
                                                       : m_edgesLineByDomainUuid[domain];
            auto& prevOwners = (kind == GridKind::Solid) ? m_prevOwnerEdgeSolidByDomain[domain]
                                                         : m_prevOwnerEdgeLineByDomain[domain];

            QSet<vtkIdType>& mySet = uuid2set[uuid];
            const auto keys = mySet.values();
            for (vtkIdType k : keys)
            {
                mySet.remove(k);
                if (owners.value(k) == uuid)
                    owners.remove(k);

                const QString oldUid = prevOwners.take(k);
                if (!oldUid.isEmpty())
                {
                    owners[k] = oldUid;
                    uuid2set[oldUid].insert(k);
                }
            }
            return;
        }

        if (mode == PickMode::Face)
        {
            auto& owners = (kind == GridKind::Solid) ? m_ownerFaceSolidByDomain[domain]
                                                     : m_ownerFaceLineByDomain[domain];
            auto& uuid2set = (kind == GridKind::Solid) ? m_facesSolidByDomainUuid[domain]
                                                       : m_facesLineByDomainUuid[domain];
            auto& prevOwners = (kind == GridKind::Solid) ? m_prevOwnerFaceSolidByDomain[domain]
                                                         : m_prevOwnerFaceLineByDomain[domain];

            QSet<vtkIdType>& mySet = uuid2set[uuid];
            const auto keys = mySet.values();
            for (vtkIdType k : keys)
            {
                mySet.remove(k);
                if (owners.value(k) == uuid)
                    owners.remove(k);

                const QString oldUid = prevOwners.take(k);
                if (!oldUid.isEmpty())
                {
                    owners[k] = oldUid;
                    uuid2set[oldUid].insert(k);
                }
            }
            return;
        }
    };

    clearOneKind(GridKind::Solid);
    clearOneKind(GridKind::Line);
    emit selectionChanged(domain, uuid, mode, GridKind::Solid);
    emit selectionChanged(domain, uuid, mode, GridKind::Line);

    if (domain == m_currentDomain && uuid == m_currentUUid && mode == m_pickMode)
    {
        if (mode == PickMode::Node)
            markDirty(DirtyNode);
        if (mode == PickMode::Edge)
            markDirty(DirtyEdge);
        if (mode == PickMode::Face)
            markDirty(DirtyFace);
    }
}

void PickManager::setSelectedPointIds(const QString& domain, const QString& uuid, GridKind kind,
                                      const QVector<vtkIdType>& pointIds, bool replace)
{
    if (replace)
        clearNodeSelection_NoRefresh(domain, uuid, kind);

    auto& uuid2set = (kind == GridKind::Solid) ? m_pointsSolidByDomainUuid[domain]
                                               : m_pointsLineByDomainUuid[domain];
    QSet<vtkIdType>& mySet = uuid2set[uuid];

    if (nodeSelectionAllowsOverlap(domain))
    {
        for (vtkIdType pid : pointIds)
            mySet.insert(pid);
    }
    else
    {
        auto& owners = (kind == GridKind::Solid) ? m_ownerPointSolidByDomain[domain]
                                                 : m_ownerPointLineByDomain[domain];
        auto& prevOwners = (kind == GridKind::Solid) ? m_prevOwnerPointSolidByDomain[domain]
                                                     : m_prevOwnerPointLineByDomain[domain];

        for (vtkIdType pid : pointIds)
        {
            if (mySet.contains(pid))
                continue;
            const QString oldUid = owners.value(pid);
            if (!oldUid.isEmpty() && oldUid != uuid)
            {
                prevOwners[pid] = oldUid;
                uuid2set[oldUid].remove(pid);
            }
            owners[pid] = uuid;
            mySet.insert(pid);
        }
    }

    emit selectionChanged(domain, uuid, PickMode::Node, kind);

    if (domain == m_currentDomain && uuid == m_currentUUid && m_pickMode == PickMode::Node)
        markDirty(DirtyNode);
}

void PickManager::setSelectedEdgeKeys(const QString& domain, const QString& uuid, GridKind kind,
                                      const QVector<vtkIdType>& edgeKeys, bool replace)
{
    auto& owners =
        (kind == GridKind::Solid) ? m_ownerEdgeSolidByDomain[domain] : m_ownerEdgeLineByDomain[domain];
    auto& uuid2set =
        (kind == GridKind::Solid) ? m_edgesSolidByDomainUuid[domain] : m_edgesLineByDomainUuid[domain];
    auto& prevOwners = (kind == GridKind::Solid) ? m_prevOwnerEdgeSolidByDomain[domain]
                                                 : m_prevOwnerEdgeLineByDomain[domain];

    QSet<vtkIdType>& mySet = uuid2set[uuid];
    if (replace)
    {
        const auto oldKeys = mySet.values();
        for (vtkIdType k : oldKeys)
        {
            mySet.remove(k);
            if (owners.value(k) == uuid)
                owners.remove(k);
            const QString oldUid = prevOwners.take(k);
            if (!oldUid.isEmpty())
            {
                owners[k] = oldUid;
                uuid2set[oldUid].insert(k);
            }
        }
    }

    for (vtkIdType edgeKey : edgeKeys)
    {
        edgeKey = canonicalizeEdgeKey(kind, edgeKey);
        if (mySet.contains(edgeKey))
            continue;
        const QString oldUid = owners.value(edgeKey);
        if (!oldUid.isEmpty() && oldUid != uuid)
        {
            prevOwners[edgeKey] = oldUid;
            uuid2set[oldUid].remove(edgeKey);
        }
        owners[edgeKey] = uuid;
        mySet.insert(edgeKey);
    }

    emit selectionChanged(domain, uuid, PickMode::Edge, kind);

    if (domain == m_currentDomain && uuid == m_currentUUid && m_pickMode == PickMode::Edge)
        markDirty(DirtyEdge);
}

void PickManager::setSelectedFaceKeys(const QString& domain, const QString& uuid, GridKind kind,
                                      const QVector<vtkIdType>& faceKeys, bool replace)
{
    auto& owners =
        (kind == GridKind::Solid) ? m_ownerFaceSolidByDomain[domain] : m_ownerFaceLineByDomain[domain];
    auto& uuid2set =
        (kind == GridKind::Solid) ? m_facesSolidByDomainUuid[domain] : m_facesLineByDomainUuid[domain];
    auto& prevOwners = (kind == GridKind::Solid) ? m_prevOwnerFaceSolidByDomain[domain]
                                                 : m_prevOwnerFaceLineByDomain[domain];

    QSet<vtkIdType>& mySet = uuid2set[uuid];
    if (replace)
    {
        const auto oldKeys = mySet.values();
        for (vtkIdType k : oldKeys)
        {
            mySet.remove(k);
            if (owners.value(k) == uuid)
                owners.remove(k);
            const QString oldUid = prevOwners.take(k);
            if (!oldUid.isEmpty())
            {
                owners[k] = oldUid;
                uuid2set[oldUid].insert(k);
            }
        }
    }

    for (vtkIdType faceKey : faceKeys)
    {
        if (mySet.contains(faceKey))
            continue;
        const QString oldUid = owners.value(faceKey);
        if (!oldUid.isEmpty() && oldUid != uuid)
        {
            prevOwners[faceKey] = oldUid;
            uuid2set[oldUid].remove(faceKey);
        }
        owners[faceKey] = uuid;
        mySet.insert(faceKey);
    }

    emit selectionChanged(domain, uuid, PickMode::Face, kind);

    if (domain == m_currentDomain && uuid == m_currentUUid && m_pickMode == PickMode::Face)
        markDirty(DirtyFace);
}

void PickManager::setPreviewPointIds(const QString& domain, const QString& uuid, GridKind kind,
                                     const QVector<vtkIdType>& pointIds)
{
    auto& mp = (kind == GridKind::Solid) ? m_previewPointsSolidByDomainUuid : m_previewPointsLineByDomainUuid;
    QSet<vtkIdType> s;
    for (auto id : pointIds)
        s.insert(id);
    mp[domain][uuid] = s;

    if (domain != m_currentDomain || uuid != m_currentUUid || m_pickMode != PickMode::Node)
        return;
    m_previewSelPts->Reset();
    const auto setS = m_previewPointsSolidByDomainUuid.value(domain).value(uuid);
    const auto setL = m_previewPointsLineByDomainUuid.value(domain).value(uuid);
    for (auto pid : setS)
    {
        if (!m_gridSolid)
            break;
        double p[3];
        m_gridSolid->GetPoint(pid, p);
        m_previewSelPts->InsertNextPoint(p);
    }
    for (auto pid : setL)
    {
        if (!m_gridLine)
            break;
        double p[3];
        m_gridLine->GetPoint(pid, p);
        m_previewSelPts->InsertNextPoint(p);
    }
    m_previewSelPts->Modified();
    m_previewSelPoly->Modified();
    updateSelectionContextOpacity();
    if (m_visual)
        m_visual->render();
}

void PickManager::setPreviewEdgeKeys(const QString& domain, const QString& uuid, GridKind kind,
                                     const QVector<vtkIdType>& edgeKeys)
{
    auto& mp = (kind == GridKind::Solid) ? m_previewEdgesSolidByDomainUuid : m_previewEdgesLineByDomainUuid;
    QSet<vtkIdType> s;
    for (auto id : edgeKeys)
    {
        id = canonicalizeEdgeKey(kind, id);
        s.insert(id);
    }
    mp[domain][uuid] = s;
    if (domain != m_currentDomain || uuid != m_currentUUid || m_pickMode != PickMode::Edge)
        return;

    m_previewEdgePts->Reset();
    m_previewEdgeLines->Reset();
    auto buildOne = [&](vtkUnstructuredGrid* grid, const QSet<vtkIdType>& keys)
    {
        if (!grid)
            return;
        for (vtkIdType key : keys)
        {
            vtkIdType cid = unpackEdgeCellId(key);
            int ei = unpackEdgeLocalId(key);
            if (cid < 0 || cid >= grid->GetNumberOfCells())
                continue;
            auto* cell = grid->GetCell(cid);
            if (!cell)
                continue;
            QVector<vtkIdType> epids;

            if (cell->GetCellDimension() == 1 || ei == 15)
            {
                auto* ids = cell->GetPointIds();
                if (!ids || ids->GetNumberOfIds() < 2)
                    continue;
                for (vtkIdType i = 0; i < ids->GetNumberOfIds(); ++i)
                    epids.push_back(ids->GetId(i));
            }
            else
            {
                if (ei < 0 || ei >= cell->GetNumberOfEdges())
                    continue;
                vtkCell* e = cell->GetEdge(ei);
                if (!e)
                    continue;
                auto* ids = e->GetPointIds();
                if (!ids || ids->GetNumberOfIds() < 2)
                    continue;
                for (vtkIdType i = 0; i < ids->GetNumberOfIds(); ++i)
                    epids.push_back(ids->GetId(i));
            }
            const vtkIdType n = epids.size();
            m_previewEdgeLines->InsertNextCell(n);
            for (vtkIdType k = 0; k < n; ++k)
            {
                double p[3];
                grid->GetPoint(epids[int(k)], p);
                vtkIdType lpid = m_previewEdgePts->InsertNextPoint(p);
                m_previewEdgeLines->InsertCellPoint(lpid);
            }
        }
    };
    buildOne(m_gridSolid, m_previewEdgesSolidByDomainUuid.value(domain).value(uuid));
    buildOne(m_gridLine, m_previewEdgesLineByDomainUuid.value(domain).value(uuid));
    m_previewEdgePts->Modified();
    m_previewEdgeLines->Modified();
    m_previewEdgePoly->Modified();
    updateSelectionContextOpacity();
    if (m_visual)
        m_visual->render();
}

void PickManager::setPreviewFaceKeys(const QString& domain, const QString& uuid, GridKind kind,
                                     const QVector<vtkIdType>& faceKeys)
{
    auto& mp = (kind == GridKind::Solid) ? m_previewFacesSolidByDomainUuid : m_previewFacesLineByDomainUuid;
    QSet<vtkIdType> s;
    for (auto id : faceKeys)
        s.insert(id);
    mp[domain][uuid] = s;

    if (domain == m_currentDomain && uuid == m_currentUUid && m_pickMode == PickMode::Face &&
        kind == GridKind::Solid)
    {
        rebuildFaceColorForActive();
    }
}

void PickManager::clearPreviewSelection(const QString& domain, const QString& uuid, PickMode mode)
{
    if (mode == PickMode::Node)
    {
        m_previewPointsSolidByDomainUuid[domain][uuid].clear();
        m_previewPointsLineByDomainUuid[domain][uuid].clear();
        m_previewSelPts->Reset();
        m_previewSelPts->Modified();
        m_previewSelPoly->Modified();
    }
    else if (mode == PickMode::Edge)
    {
        m_previewEdgesSolidByDomainUuid[domain][uuid].clear();
        m_previewEdgesLineByDomainUuid[domain][uuid].clear();
        m_previewEdgePts->Reset();
        m_previewEdgeLines->Reset();
        m_previewEdgePts->Modified();
        m_previewEdgeLines->Modified();
        m_previewEdgePoly->Modified();
    }
    else
    {
        m_previewFacesSolidByDomainUuid[domain][uuid].clear();
        m_previewFacesLineByDomainUuid[domain][uuid].clear();
        if (domain == m_currentDomain && uuid == m_currentUUid && m_pickMode == PickMode::Face)
            rebuildFaceColorForActive();
    }
    if (domain == m_currentDomain && uuid == m_currentUUid)
        updateSelectionContextOpacity();
    if (m_visual)
        m_visual->render();
}

void PickManager::setBoxSelectEnabled(const QString& domain, const QString& uuid, bool enabled)
{
    m_boxSelectEnabledByDomainUuid[domain][uuid] = enabled;
    if (domain == m_currentDomain && uuid == m_currentUUid && !enabled)
        updateDragRect(0, 0, 0, 0, false);
}

void PickManager::setPreferredDomainCategory(const QString& domain, const QString& uuid,
                                             const QString& category)
{
    m_preferredDomainCategoryByDomainUuid[domain][uuid] = category.trimmed();
}

void PickManager::setClickPickEnabled(const QString& domain, const QString& uuid, bool enabled)
{
    m_clickPickEnabledByDomainUuid[domain][uuid] = enabled;

    // 页面可能在网格重新导入后仍处于激活状态，但交互观察器已经被其他页面拆除。
    // 用户显式开启点选时，确保当前节点拾取链路重新安装。
    if (enabled && domain == m_currentDomain && uuid == m_currentUUid &&
        (!m_leftPressTag || !m_leftReleaseTag || !m_mouseMoveTag))
    {
        setupPicking();
    }
}

bool PickManager::isBoxSelectEnabledForActive() const
{
    if (m_currentDomain.isEmpty() || m_currentUUid.isEmpty())
        return false;
    return m_boxSelectEnabledByDomainUuid.value(m_currentDomain).value(m_currentUUid, true);
}

bool PickManager::isClickPickEnabledForActive() const
{
    if (m_currentDomain.isEmpty() || m_currentUUid.isEmpty())
        return true;
    return m_clickPickEnabledByDomainUuid.value(m_currentDomain).value(m_currentUUid, true);
}

void PickManager::updateDragRect(int x0, int y0, int x1, int y1, bool visible)
{
    if (!m_dragRectActor || !m_visual || !m_visual->renderer())
        return;

    if (!visible)
    {
        m_dragRectActor->SetVisibility(false);
        if (m_visual)
            m_visual->render();
        return;
    }

    auto* ren = m_visual->renderer();
    auto* rw = ren->GetRenderWindow();
    if (!rw)
        return;
    const int* sz = rw->GetSize();
    if (!sz || sz[0] <= 0 || sz[1] <= 0)
        return;

    x0 = std::max(0, std::min(x0, sz[0] - 1));
    x1 = std::max(0, std::min(x1, sz[0] - 1));
    y0 = std::max(0, std::min(y0, sz[1] - 1));
    y1 = std::max(0, std::min(y1, sz[1] - 1));

    double p0[3] = {double(x0), double(y0), 0.0};
    double p1[3] = {double(x1), double(y0), 0.0};
    double p2[3] = {double(x1), double(y1), 0.0};
    double p3[3] = {double(x0), double(y1), 0.0};

    m_dragRectPts->Reset();
    vtkIdType id0 = m_dragRectPts->InsertNextPoint(p0);
    vtkIdType id1 = m_dragRectPts->InsertNextPoint(p1);
    vtkIdType id2 = m_dragRectPts->InsertNextPoint(p2);
    vtkIdType id3 = m_dragRectPts->InsertNextPoint(p3);

    m_dragRectLines->Reset();
    auto addSeg = [&](vtkIdType a, vtkIdType b)
    {
        vtkIdType ids[2] = {a, b};
        m_dragRectLines->InsertNextCell(2, ids);
    };
    addSeg(id0, id1);
    addSeg(id1, id2);
    addSeg(id2, id3);
    addSeg(id3, id0);

    m_dragRectPts->Modified();
    m_dragRectLines->Modified();
    m_dragRectPoly->Modified();
    m_dragRectActor->SetVisibility(true);
    m_visual->render();
}

bool PickManager::hardwareBoxSelect(int x0, int y0, int x1, int y1, bool deselect)
{
    if (!m_visual || !m_visual->renderer() || !m_hwSelector)
        return false;

    auto* ren = m_visual->renderer();
    const int xmin = std::min(x0, x1);
    const int xmax = std::max(x0, x1);
    const int ymin = std::min(y0, y1);
    const int ymax = std::max(y0, y1);
    if (xmax - xmin < 2 || ymax - ymin < 2)
        return false;

    QVector<QPair<vtkActor*, int>> actorVisBackup;
    auto hideActorForSelect = [&](vtkActor* actor)
    {
        if (!actor)
            return;
        actorVisBackup.append({actor, actor->GetVisibility()});
        actor->SetVisibility(false);
    };
    hideActorForSelect(m_selActor);
    hideActorForSelect(m_previewSelActor);
    hideActorForSelect(m_edgeActor);
    hideActorForSelect(m_previewEdgeActor);

    QVector<QPair<vtkActor2D*, int>> actor2DVisBackup;
    auto hideActor2DForSelect = [&](vtkActor2D* actor)
    {
        if (!actor)
            return;
        actor2DVisBackup.append({actor, actor->GetVisibility()});
        actor->SetVisibility(false);
    };
    hideActor2DForSelect(m_dragRectActor);

    // Node 框选不能直接在当前显示 surface 上做 POINT hardware selection。
    // 当前显示 surface 同时包含 MATYPE/LAYER 内部分界面；POINT pass 会把这些内部界面顶点也编码。
    // 选择前临时把同一个 solid actor 的 mapper 输入替换成“纯外壳 + 紧凑点表”，
    // 这样保持相机、actor、深度测试都不变，同时恢复旧版 vtkDataSetSurfaceFilter 的选择语义。
    vtkSmartPointer<vtkPolyData> nodePickSurface;
    vtkSmartPointer<vtkPolyData> savedSolidSurface;
    vtkPolyDataMapper* solidPolyMapper = nullptr;
    int savedSolidScalarVisibility = 0;

    if (m_pickMode == PickMode::Node && m_solidProp)
    {
        auto* solidActor = vtkActor::SafeDownCast(m_solidProp);
        solidPolyMapper = solidActor ? vtkPolyDataMapper::SafeDownCast(solidActor->GetMapper()) : nullptr;
        vtkDataSet* displayedSolid = dataSetFromProp(m_solidProp);
        if (solidPolyMapper && displayedSolid)
        {
            savedSolidSurface = vtkPolyData::SafeDownCast(solidPolyMapper->GetInput());
            nodePickSurface = buildNodeBoxPickSurface(displayedSolid);
            if (savedSolidSurface && nodePickSurface && nodePickSurface->GetNumberOfCells() > 0)
            {
                savedSolidScalarVisibility = solidPolyMapper->GetScalarVisibility();
                solidPolyMapper->ScalarVisibilityOff();
                solidPolyMapper->SetInputData(nodePickSurface);
            }
            else
            {
                nodePickSurface = nullptr;
                savedSolidSurface = nullptr;
            }
        }
    }

    // Node 框选不再依赖 POINT pass 是否真的给每个顶点分配到屏幕像素。
    // 先正常渲染“纯外壳”，保存框选区域的深度缓冲；后面直接把所有外表面节点投影到屏幕，
    // 用 ZBuffer 判断当前视角是否真正可见。这样即使模型缩得很小、多个节点落在同一像素，
    // 仍然可以按节点的真实屏幕坐标完整框选。透视/正交都走 renderer 的同一套投影矩阵。
    int depthXMin = xmin;
    int depthXMax = xmax;
    int depthYMin = ymin;
    int depthYMax = ymax;
    int depthWidth = 0;
    int depthHeight = 0;
    QVector<float> depthBuffer;
    bool depthBufferValid = false;

    if (auto* rw = ren->GetRenderWindow())
    {
        rw->Render();
        if (m_pickMode == PickMode::Node)
        {
            const int* size = rw->GetSize();
            if (size && size[0] > 0 && size[1] > 0)
            {
                // 多留 1 像素，只用于深度梯度容差；框选范围本身仍严格使用用户画的矩形。
                depthXMin = std::max(0, xmin - 1);
                depthXMax = std::min(size[0] - 1, xmax + 1);
                depthYMin = std::max(0, ymin - 1);
                depthYMax = std::min(size[1] - 1, ymax + 1);
                depthWidth = depthXMax - depthXMin + 1;
                depthHeight = depthYMax - depthYMin + 1;
                if (depthWidth > 0 && depthHeight > 0)
                {
                    depthBuffer.resize(depthWidth * depthHeight);
                    depthBufferValid =
                        rw->GetZbufferData(depthXMin, depthYMin, depthXMax, depthYMax,
                                           depthBuffer.data()) != 0;
                }
            }
        }
    }

    m_hwSelector->SetRenderer(ren);
    // Node 模式也只用 CELL pass：它不负责返回全部节点，只负责识别框内主要表面朝向。
    // 节点完整性由下面的屏幕投影 + ZBuffer 保证。
    m_hwSelector->SetFieldAssociation(vtkDataObject::FIELD_ASSOCIATION_CELLS);
    m_hwSelector->SetArea(xmin, ymin, xmax, ymax);

    vtkSmartPointer<vtkSelection> sel = m_hwSelector->Select();

    // HardwareSelector 已经返回 ID，可以立刻恢复正常显示 mapper；nodePickSurface 由 smart pointer
    // 保持到下面 ID 映射完成，因此不会出现 selection ID 对错数据集的问题。
    if (solidPolyMapper && savedSolidSurface)
    {
        solidPolyMapper->SetInputData(savedSolidSurface);
        solidPolyMapper->SetScalarVisibility(savedSolidScalarVisibility);
    }

    for (auto& it : actorVisBackup)
        it.first->SetVisibility(it.second);
    for (auto& it : actor2DVisBackup)
        it.first->SetVisibility(it.second);

    // Face / Edge 仍完全依赖 HardwareSelector；Node 即便没有返回 cell，
    // 也可以继续依靠投影 + ZBuffer 判断，所以不能在这里提前退出。
    if (m_pickMode != PickMode::Node && (!sel || sel->GetNumberOfNodes() <= 0))
        return false;

    bool changed = false;
    int dirtyBits = DirtyNone;
    bool solidSelectionTouched = false;
    bool lineSelectionTouched = false;
    auto noteSelectionTouched = [&](GridKind kind)
    {
        if (kind == GridKind::Solid)
            solidSelectionTouched = true;
        else
            lineSelectionTouched = true;
    };
    auto notifySelectionChanged = [&]()
    {
        if (!changed)
            return;
        if (solidSelectionTouched)
            emit selectionChanged(m_currentDomain, m_currentUUid, m_pickMode, GridKind::Solid);
        if (lineSelectionTouched)
            emit selectionChanged(m_currentDomain, m_currentUUid, m_pickMode, GridKind::Line);
    };

    auto worldPointInRect = [&](const double p[3]) -> bool
    {
        vtkNew<vtkCoordinate> coord;
        coord->SetCoordinateSystemToWorld();
        coord->SetValue(p);
        double* dp = coord->GetComputedDoubleDisplayValue(ren);
        if (!dp)
            return false;
        const int sx = int(std::lround(dp[0]));
        const int sy = int(std::lround(dp[1]));
        return sx >= xmin && sx <= xmax && sy >= ymin && sy <= ymax;
    };

    struct VisibleCell
    {
        GridKind kind = GridKind::Solid;
        vtkDataSet* dataSet = nullptr;
        vtkIdType cellId = -1;
        double normal[3] = {0.0, 0.0, 0.0};
        double centerDisplayDistance2 = std::numeric_limits<double>::max();
        bool hasNormal = false;
    };
    QVector<VisibleCell> visibleCells;
    const double rectCenterX = 0.5 * double(xmin + xmax);
    const double rectCenterY = 0.5 * double(ymin + ymax);

    auto appendVisibleCell = [&](GridKind kind, vtkDataSet* pickedDs, vtkIdType cellId)
    {
        if (!pickedDs || cellId < 0 || cellId >= pickedDs->GetNumberOfCells())
            return;
        vtkCell* cell = pickedDs->GetCell(cellId);
        vtkIdList* ids = cell ? cell->GetPointIds() : nullptr;
        if (!ids || ids->GetNumberOfIds() <= 0)
            return;

        VisibleCell candidate;
        candidate.kind = kind;
        candidate.dataSet = pickedDs;
        candidate.cellId = cellId;

        double center[3] = {0.0, 0.0, 0.0};
        for (vtkIdType k = 0; k < ids->GetNumberOfIds(); ++k)
        {
            double p[3];
            pickedDs->GetPoint(ids->GetId(k), p);
            center[0] += p[0];
            center[1] += p[1];
            center[2] += p[2];
        }
        const double scale = 1.0 / double(ids->GetNumberOfIds());
        center[0] *= scale;
        center[1] *= scale;
        center[2] *= scale;

        vtkNew<vtkCoordinate> centerCoord;
        centerCoord->SetCoordinateSystemToWorld();
        centerCoord->SetValue(center);
        if (double* display = centerCoord->GetComputedDoubleDisplayValue(ren))
        {
            const double dx = display[0] - rectCenterX;
            const double dy = display[1] - rectCenterY;
            candidate.centerDisplayDistance2 = dx * dx + dy * dy;
        }

        if (kind == GridKind::Solid && cell->GetCellDimension() == 2 &&
            ids->GetNumberOfIds() >= 3)
        {
            double p0[3], p1[3], p2[3], a[3], b[3];
            pickedDs->GetPoint(ids->GetId(0), p0);
            bool foundNormal = false;
            for (vtkIdType k = 1; k + 1 < ids->GetNumberOfIds() && !foundNormal; ++k)
            {
                pickedDs->GetPoint(ids->GetId(k), p1);
                pickedDs->GetPoint(ids->GetId(k + 1), p2);
                vtkMath::Subtract(p1, p0, a);
                vtkMath::Subtract(p2, p0, b);
                vtkMath::Cross(a, b, candidate.normal);
                foundNormal = vtkMath::Normalize(candidate.normal) > 1.0e-12;
            }
            candidate.hasNormal = foundNormal;
        }
        visibleCells.push_back(candidate);
    };

    // 先收集硬件确认可见的单元。约束节点和网格面随后共用同一套视角过滤，
    // 可避免框靠近轮廓时把几乎侧向的相邻面一起选入。
    for (unsigned int i = 0; sel && i < sel->GetNumberOfNodes(); ++i)
    {
        auto* node = sel->GetNode(i);
        if (!node)
            continue;
        auto* prop = vtkProp::SafeDownCast(node->GetProperties()->Get(vtkSelectionNode::PROP()));
        vtkDataArray* selIds = vtkDataArray::SafeDownCast(node->GetSelectionList());
        if (!prop || !selIds)
            continue;

        GridKind kind;
        if (prop == m_solidProp)
            kind = GridKind::Solid;
        else if (prop == m_lineProp)
            kind = GridKind::Line;
        else
            continue;

        // Node 模式下 Solid 的 cell id 来自临时 nodePickSurface；mapper 已恢复，
        // 所以这里必须继续按临时外壳解释 selection id。
        vtkDataSet* pickedDs =
            (m_pickMode == PickMode::Node && kind == GridKind::Solid && nodePickSurface)
                ? static_cast<vtkDataSet*>(nodePickSurface.GetPointer())
                : dataSetFromProp(prop);
        for (vtkIdType j = 0; j < selIds->GetNumberOfTuples(); ++j)
            appendVisibleCell(kind, pickedDs, vtkIdType(selIds->GetComponent(j, 0)));
    }

    double referenceNormal[3] = {0.0, 0.0, 0.0};
    double nearestCenter = std::numeric_limits<double>::max();
    bool hasReferenceNormal = false;
    for (const VisibleCell& candidate : std::as_const(visibleCells))
    {
        if (!candidate.hasNormal || candidate.centerDisplayDistance2 >= nearestCenter)
            continue;
        nearestCenter = candidate.centerDisplayDistance2;
        std::copy_n(candidate.normal, 3, referenceNormal);
        hasReferenceNormal = true;
    }
    auto followsViewedSurface = [&](const VisibleCell& candidate)
    {
        if (!hasReferenceNormal || candidate.kind != GridKind::Solid || !candidate.hasNormal)
            return true;
        return std::abs(vtkMath::Dot(referenceNormal, candidate.normal)) >= 0.5;
    };

    if (m_pickMode == PickMode::Node)
    {
        // 只有当框中的可见单元明显属于同一个平面/同一朝向时，才启用“主平面锁定”。
        // 这样框一个平面时不会把轮廓旁边窄窄的一条侧面一起带进来；如果用户本来就跨多个
        // 斜面/曲面框选，朝向分散，会自动关闭该限制，不再发生大范围斜坡漏选。
        int orientedCellCount = 0;
        int referenceAlignedCount = 0;
        constexpr double kPlanarDot = 0.985; // 约 10°
        for (const VisibleCell& candidate : std::as_const(visibleCells))
        {
            if (candidate.kind != GridKind::Solid || !candidate.hasNormal)
                continue;
            ++orientedCellCount;
            if (hasReferenceNormal &&
                std::abs(vtkMath::Dot(referenceNormal, candidate.normal)) >= kPlanarDot)
                ++referenceAlignedCount;
        }
        const bool lockToReferenceSurface =
            hasReferenceNormal && orientedCellCount > 0 &&
            referenceAlignedCount * 5 >= orientedCellCount * 4; // >= 80%

        auto projectToDisplay = [&](const double p[3], double display[3]) -> bool
        {
            ren->SetWorldPoint(p[0], p[1], p[2], 1.0);
            ren->WorldToDisplay();
            ren->GetDisplayPoint(display);
            return std::isfinite(display[0]) && std::isfinite(display[1]) &&
                   std::isfinite(display[2]);
        };

        auto depthAt = [&](int sx, int sy, float& z) -> bool
        {
            if (!depthBufferValid || sx < depthXMin || sx > depthXMax ||
                sy < depthYMin || sy > depthYMax)
                return false;
            const int bx = sx - depthXMin;
            const int by = sy - depthYMin;
            const int index = by * depthWidth + bx;
            if (index < 0 || index >= depthBuffer.size())
                return false;
            z = depthBuffer[index];
            return std::isfinite(z) && z < 0.999999f;
        };

        auto displayPointIsFrontVisible = [&](const double display[3]) -> bool
        {
            if (!depthBufferValid || display[2] < 0.0 || display[2] > 1.0)
                return false;

            const int sx = int(std::lround(display[0]));
            const int sy = int(std::lround(display[1]));
            float centerDepth = 1.0f;
            if (!depthAt(sx, sy, centerDepth))
            {
                // 轮廓顶点可能恰好落在像素边缘；中心像素为空时只查紧邻 1 像素。
                bool found = false;
                double bestDelta = std::numeric_limits<double>::max();
                float bestDepth = 1.0f;
                for (int oy = -1; oy <= 1; ++oy)
                {
                    for (int ox = -1; ox <= 1; ++ox)
                    {
                        float z = 1.0f;
                        if (!depthAt(sx + ox, sy + oy, z))
                            continue;
                        const double delta = std::abs(double(z) - display[2]);
                        if (delta < bestDelta)
                        {
                            bestDelta = delta;
                            bestDepth = z;
                            found = true;
                        }
                    }
                }
                if (!found)
                    return false;
                centerDepth = bestDepth;
            }

            // 根据局部深度梯度给亚像素容差：平面上接近 0，斜面缩小时自动稍微增大。
            double localGradient = 0.0;
            for (int oy = -1; oy <= 1; ++oy)
            {
                for (int ox = -1; ox <= 1; ++ox)
                {
                    float z = 1.0f;
                    if (!depthAt(sx + ox, sy + oy, z))
                        continue;
                    const double dz = std::abs(double(z) - double(centerDepth));
                    // 深度突变通常来自轮廓或另一表面，不能用它放大容差。
                    if (dz < 0.01)
                        localGradient = std::max(localGradient, dz);
                }
            }
            const double depthTolerance =
                std::min(0.002, std::max(2.0e-5, localGradient * 0.85 + 2.0e-5));

            // 节点不能位于当前像素最前表面之后；略靠前允许通过以吸收像素边缘误差。
            return display[2] <= double(centerDepth) + depthTolerance;
        };

        auto cellMatchesReference = [&](vtkDataSet* ds, vtkIdType cellId) -> bool
        {
            if (!lockToReferenceSurface)
                return true;
            if (!ds || cellId < 0 || cellId >= ds->GetNumberOfCells())
                return false;

            vtkCell* cell = ds->GetCell(cellId);
            vtkIdList* ids = cell ? cell->GetPointIds() : nullptr;
            if (!cell || cell->GetCellDimension() != 2 || !ids || ids->GetNumberOfIds() < 3)
                return false;

            double p0[3], p1[3], p2[3], a[3], b[3], normal[3];
            ds->GetPoint(ids->GetId(0), p0);
            for (vtkIdType k = 1; k + 1 < ids->GetNumberOfIds(); ++k)
            {
                ds->GetPoint(ids->GetId(k), p1);
                ds->GetPoint(ids->GetId(k + 1), p2);
                vtkMath::Subtract(p1, p0, a);
                vtkMath::Subtract(p2, p0, b);
                vtkMath::Cross(a, b, normal);
                if (vtkMath::Normalize(normal) > 1.0e-12)
                    return std::abs(vtkMath::Dot(referenceNormal, normal)) >= kPlanarDot;
            }
            return false;
        };

        // ZBuffer 读取失败时保守回退：仅采用 HardwareSelector 已确认可见 cell 的节点。
        QSet<vtkIdType> fallbackSolidLocalPoints;
        QSet<vtkIdType> fallbackLineLocalPoints;
        if (!depthBufferValid)
        {
            for (const VisibleCell& candidate : std::as_const(visibleCells))
            {
                vtkCell* cell = candidate.dataSet ? candidate.dataSet->GetCell(candidate.cellId) : nullptr;
                vtkIdList* ids = cell ? cell->GetPointIds() : nullptr;
                if (!ids)
                    continue;
                QSet<vtkIdType>& target =
                    candidate.kind == GridKind::Solid ? fallbackSolidLocalPoints
                                                      : fallbackLineLocalPoints;
                for (vtkIdType k = 0; k < ids->GetNumberOfIds(); ++k)
                    target.insert(ids->GetId(k));
            }
        }

        QSet<vtkIdType> solidPointIds;
        QSet<vtkIdType> linePointIds;

        if (nodePickSurface && nodePickSurface->GetNumberOfPoints() > 0)
        {
            if (lockToReferenceSurface)
                nodePickSurface->BuildLinks();

            vtkDataArray* originalPoints =
                findArray(nodePickSurface->GetPointData(), "vtkOriginalPointIds", "orig_point_id");
            vtkNew<vtkIdList> incidentCells;

            for (vtkIdType localPid = 0; localPid < nodePickSurface->GetNumberOfPoints(); ++localPid)
            {
                double p[3], display[3];
                nodePickSurface->GetPoint(localPid, p);
                if (!projectToDisplay(p, display))
                    continue;
                if (display[0] < double(xmin) || display[0] > double(xmax) ||
                    display[1] < double(ymin) || display[1] > double(ymax))
                    continue;

                if (depthBufferValid)
                {
                    if (!displayPointIsFrontVisible(display))
                        continue;
                }
                else if (!fallbackSolidLocalPoints.contains(localPid))
                {
                    continue;
                }

                if (lockToReferenceSurface)
                {
                    incidentCells->Reset();
                    nodePickSurface->GetPointCells(localPid, incidentCells);
                    bool onReferenceSurface = false;
                    for (vtkIdType ci = 0; ci < incidentCells->GetNumberOfIds(); ++ci)
                    {
                        if (cellMatchesReference(nodePickSurface, incidentCells->GetId(ci)))
                        {
                            onReferenceSurface = true;
                            break;
                        }
                    }
                    if (!onReferenceSurface)
                        continue;
                }

                vtkIdType originalPid = localPid;
                if (originalPoints && localPid < originalPoints->GetNumberOfTuples())
                    originalPid = vtkIdType(originalPoints->GetTuple1(localPid));
                if (originalPid >= 0)
                    solidPointIds.insert(originalPid);
            }
        }

        // 线单元不做主平面限制，但也用屏幕投影 + ZBuffer，避免缩小时漏点。
        if (m_lineProp)
        {
            auto* lineActor = vtkActor::SafeDownCast(m_lineProp);
            vtkDataSet* lineDs = dataSetFromProp(m_lineProp);
            if ((!lineActor || lineActor->GetVisibility()) && lineDs)
            {
                vtkDataArray* originalPoints =
                    findArray(lineDs->GetPointData(), "vtkOriginalPointIds", "orig_point_id");
                for (vtkIdType localPid = 0; localPid < lineDs->GetNumberOfPoints(); ++localPid)
                {
                    double p[3], display[3];
                    lineDs->GetPoint(localPid, p);
                    if (!projectToDisplay(p, display))
                        continue;
                    if (display[0] < double(xmin) || display[0] > double(xmax) ||
                        display[1] < double(ymin) || display[1] > double(ymax))
                        continue;

                    if (depthBufferValid)
                    {
                        if (!displayPointIsFrontVisible(display))
                            continue;
                    }
                    else if (!fallbackLineLocalPoints.contains(localPid))
                    {
                        continue;
                    }

                    vtkIdType originalPid = localPid;
                    if (originalPoints && localPid < originalPoints->GetNumberOfTuples())
                        originalPid = vtkIdType(originalPoints->GetTuple1(localPid));
                    if (originalPid >= 0)
                        linePointIds.insert(originalPid);
                }
            }
        }

        for (vtkIdType pointId : std::as_const(solidPointIds))
            setNodeSelected_NoRefresh(GridKind::Solid, pointId, !deselect);
        for (vtkIdType pointId : std::as_const(linePointIds))
            setNodeSelected_NoRefresh(GridKind::Line, pointId, !deselect);

        changed = !solidPointIds.isEmpty() || !linePointIds.isEmpty();
        if (!solidPointIds.isEmpty())
            noteSelectionTouched(GridKind::Solid);
        if (!linePointIds.isEmpty())
            noteSelectionTouched(GridKind::Line);
        if (changed)
            markDirty(DirtyNode);
        notifySelectionChanged();
        return changed;
    }

    if (m_pickMode == PickMode::Face)
    {
        for (const VisibleCell& candidate : std::as_const(visibleCells))
        {
            if (candidate.kind != GridKind::Solid || !followsViewedSurface(candidate))
                continue;

            vtkIdType originalCellId = -1;
            int originalFaceLocalId = 15;
            if (computePickedFaceFromBoundary(candidate.dataSet, candidate.cellId,
                                              originalCellId, originalFaceLocalId))
            {
                setFaceSelected_NoRefresh(GridKind::Solid,
                                          packFaceKey(originalCellId, originalFaceLocalId),
                                          !deselect);
                noteSelectionTouched(GridKind::Solid);
                changed = true;
                continue;
            }

            if (candidate.dataSet != m_gridSolid)
                continue;
            vtkCell* solidCell = m_gridSolid->GetCell(candidate.cellId);
            if (!solidCell)
                continue;
            if (solidCell->GetCellDimension() == 2)
            {
                setFaceSelected_NoRefresh(GridKind::Solid,
                                          packFaceKey(candidate.cellId, 15), !deselect);
                noteSelectionTouched(GridKind::Solid);
                changed = true;
                continue;
            }
            for (int faceId = 0; faceId < solidCell->GetNumberOfFaces(); ++faceId)
            {
                setFaceSelected_NoRefresh(GridKind::Solid,
                                          packFaceKey(candidate.cellId, faceId), !deselect);
                noteSelectionTouched(GridKind::Solid);
                changed = true;
            }
        }
        if (changed)
            markDirty(DirtyFace);
        notifySelectionChanged();
        return changed;
    }

    for (unsigned int i = 0; i < sel->GetNumberOfNodes(); ++i)
    {
        auto* node = sel->GetNode(i);
        if (!node)
            continue;
        auto* prop = vtkProp::SafeDownCast(node->GetProperties()->Get(vtkSelectionNode::PROP()));
        if (!prop)
            continue;

        GridKind kind;
        vtkDataSet* pickedDs = dataSetFromProp(prop);
        const bool solidProp = (prop == m_solidProp);
        const bool lineProp = (prop == m_lineProp);

        if (solidProp)
            kind = GridKind::Solid;
        else if (lineProp)
            kind = GridKind::Line;
        else
            continue;

        vtkDataArray* selIds = vtkDataArray::SafeDownCast(node->GetSelectionList());
        if (!selIds)
            continue;

        if (m_pickMode == PickMode::Edge)
        {
            if (!pickedDs)
                continue;

            auto edgeInRect = [&](const QVector<vtkIdType>& pids) -> bool
            {
                if (pids.size() < 2)
                    return false;

                for (vtkIdType pid : pids)
                {
                    double p[3];
                    pickedDs->GetPoint(pid, p);
                    if (worldPointInRect(p))
                        return true;
                }

                for (int si = 0; si + 1 < pids.size(); ++si)
                {
                    double p0[3], p1[3], pm[3];
                    pickedDs->GetPoint(pids[si], p0);
                    pickedDs->GetPoint(pids[si + 1], p1);
                    pm[0] = 0.5 * (p0[0] + p1[0]);
                    pm[1] = 0.5 * (p0[1] + p1[1]);
                    pm[2] = 0.5 * (p0[2] + p1[2]);
                    if (worldPointInRect(pm))
                        return true;
                }
                return false;
            };

            for (vtkIdType j = 0; j < selIds->GetNumberOfTuples(); ++j)
            {
                const vtkIdType pickedCellId = vtkIdType(selIds->GetComponent(j, 0));
                vtkCell* cell = pickedDs->GetCell(pickedCellId);
                if (!cell)
                    continue;

                       // Solid surface pick dataset（来自 boundary filter）：需要映射回原始体单元 edgeLocalId。
                if (kind == GridKind::Solid && pickedDs != m_gridSolid)
                {
                    auto* origCellArr = findArray(pickedDs->GetCellData(), "vtkOriginalCellIds", "orig_cell_id");
                    auto* origPointArr =
                        findArray(pickedDs->GetPointData(), "vtkOriginalPointIds", "orig_point_id");
                    if (!origCellArr || !origPointArr)
                        continue;

                    const vtkIdType origCellId = vtkIdType(origCellArr->GetTuple1(pickedCellId));
                    vtkCell* origCell = m_gridSolid ? m_gridSolid->GetCell(origCellId) : nullptr;
                    if (!origCell)
                        continue;

                    vtkIdList* ids = cell->GetPointIds();
                    if (!ids || ids->GetNumberOfIds() < 2)
                        continue;
                    const vtkIdType nIds = ids->GetNumberOfIds();
                    const bool closedLoop = (cell->GetCellDimension() > 1);
                    const vtkIdType nSegs = closedLoop ? nIds : (nIds - 1);
                    for (vtkIdType si = 0; si < nSegs; ++si)
                    {
                        const vtkIdType pa = ids->GetId(si);
                        const vtkIdType pb = ids->GetId((si + 1) % nIds);

                        QVector<vtkIdType> segPids;
                        segPids << pa << pb;
                        if (!edgeInRect(segPids))
                            continue;

                        const vtkIdType a = vtkIdType(origPointArr->GetTuple1(pa));
                        const vtkIdType b = vtkIdType(origPointArr->GetTuple1(pb));
                        if (a < 0 || b < 0)
                            continue;

                        bool matchedByTagSet = false;
                        if (auto* meshSvc = ServiceRegistry::instance().getService<MeshModuleControllerService>())
                        {
                            const QVector<MeshTagSet> sets = meshSvc->boundaryTagSets(1);
                            for (const MeshTagSet& set : sets)
                            {
                                if (matchedByTagSet)
                                    break;
                                for (MeshIdType rawKey : set.edgeKeys)
                                {
                                    const vtkIdType edgeKey = static_cast<vtkIdType>(rawKey);
                                    const vtkIdType cid = unpackEdgeCellId(edgeKey);
                                    const int ei = unpackEdgeLocalId(edgeKey);
                                    if (cid != origCellId)
                                        continue;

                                    vtkIdList* eids = nullptr;
                                    if (origCell->GetCellDimension() == 1 || ei == 15)
                                    {
                                        eids = origCell->GetPointIds();
                                    }
                                    else
                                    {
                                        if (ei < 0 || ei >= origCell->GetNumberOfEdges())
                                            continue;
                                        vtkCell* e = origCell->GetEdge(ei);
                                        if (!e)
                                            continue;
                                        eids = e->GetPointIds();
                                    }
                                    if (!eids || eids->GetNumberOfIds() < 2)
                                        continue;

                                    bool hasA = false;
                                    bool hasB = false;
                                    for (vtkIdType ek = 0; ek < eids->GetNumberOfIds(); ++ek)
                                    {
                                        const vtkIdType epid = eids->GetId(ek);
                                        hasA = hasA || (epid == a);
                                        hasB = hasB || (epid == b);
                                    }
                                    if (hasA && hasB)
                                    {
                                        setEdgeSelected_NoRefresh(kind, edgeKey, !deselect);
                                        noteSelectionTouched(kind);
                                        changed = true;
                                        matchedByTagSet = true;
                                        break;
                                    }
                                }
                            }
                        }
                        if (matchedByTagSet)
                            continue;

                        const int nEdges = origCell->GetNumberOfEdges();
                        for (int ei = 0; ei < nEdges; ++ei)
                        {
                            vtkCell* e = origCell->GetEdge(ei);
                            if (!e)
                                continue;
                            vtkIdList* eids = e->GetPointIds();
                            if (!eids || eids->GetNumberOfIds() < 2)
                                continue;
                            bool hasA = false;
                            bool hasB = false;
                            for (vtkIdType ek = 0; ek < eids->GetNumberOfIds(); ++ek)
                            {
                                const vtkIdType epid = eids->GetId(ek);
                                if (epid == a)
                                    hasA = true;
                                if (epid == b)
                                    hasB = true;
                            }
                            if (hasA && hasB)
                            {
                                setEdgeSelected_NoRefresh(kind, packEdgeKey(origCellId, ei),
                                                          !deselect);
                                noteSelectionTouched(kind);
                                changed = true;
                                break;
                            }
                        }
                    }
                    continue;
                }

                if (cell->GetCellDimension() == 1)
                {
                    QVector<vtkIdType> pids;
                    vtkIdList* ids = cell->GetPointIds();
                    if (!ids || ids->GetNumberOfIds() < 2)
                        continue;
                    for (vtkIdType k = 0; k < ids->GetNumberOfIds(); ++k)
                        pids.push_back(ids->GetId(k));
                    if (!edgeInRect(pids))
                        continue;
                    setEdgeSelected_NoRefresh(kind, packEdgeKey(pickedCellId, 15), !deselect);
                    noteSelectionTouched(kind);
                    changed = true;
                    continue;
                }

                const int nEdges = cell->GetNumberOfEdges();
                for (int ei = 0; ei < nEdges; ++ei)
                {
                    vtkCell* e = cell->GetEdge(ei);
                    if (!e)
                        continue;
                    vtkIdList* eids = e->GetPointIds();
                    if (!eids || eids->GetNumberOfIds() < 2)
                        continue;
                    QVector<vtkIdType> pids;
                    for (vtkIdType k = 0; k < eids->GetNumberOfIds(); ++k)
                        pids.push_back(eids->GetId(k));
                    if (!edgeInRect(pids))
                        continue;
                    setEdgeSelected_NoRefresh(kind, packEdgeKey(pickedCellId, ei), !deselect);
                    noteSelectionTouched(kind);
                    changed = true;
                }
            }
            dirtyBits |= DirtyEdge;
            continue;
        }

               // PickMode::Face：仅支持 Solid（显示来自 surface filter），排除 lineGrid
        for (vtkIdType j = 0; j < selIds->GetNumberOfTuples(); ++j)
        {
            const vtkIdType pickedCellId = vtkIdType(selIds->GetComponent(j, 0));
            if (kind != GridKind::Solid || !pickedDs)
                continue;

            vtkIdType origCellId = -1;
            int origFaceLocalId = 15;
            if (computePickedFaceFromBoundary(pickedDs, pickedCellId, origCellId, origFaceLocalId))
            {
                setFaceSelected_NoRefresh(kind, packFaceKey(origCellId, origFaceLocalId),
                                          !deselect);
                changed = true;

            }
            else if (pickedDs == m_gridSolid)
            {
                vtkCell* solidCell = m_gridSolid->GetCell(pickedCellId);
                if (!solidCell)
                    continue;
                if (solidCell->GetCellDimension() == 2)
                {
                    setFaceSelected_NoRefresh(kind, packFaceKey(pickedCellId, 15), !deselect);
                    changed = true;
                    continue;
                }

                const int nFaces = solidCell->GetNumberOfFaces();
                for (int fi = 0; fi < nFaces; ++fi)
                {
                    setFaceSelected_NoRefresh(kind, packFaceKey(pickedCellId, fi), !deselect);
                    changed = true;
                }
            }
        }
        dirtyBits |= DirtyFace;
    }

    if (changed && dirtyBits != DirtyNone)
        markDirty(dirtyBits);
    notifySelectionChanged();
    return changed;
}

// ===================== box select (batch) =====================
void PickManager::setNodeSelected_NoRefresh(GridKind kind, vtkIdType pid, bool selected)
{
    if (m_currentDomain.isEmpty() || m_currentUUid.isEmpty())
        return;

    const QString dom = m_currentDomain;
    const QString uid = m_currentUUid;

    auto& uuid2set =
        (kind == GridKind::Solid) ? m_pointsSolidByDomainUuid[dom] : m_pointsLineByDomainUuid[dom];
    QSet<vtkIdType>& mySet = uuid2set[uid];

    if (nodeSelectionAllowsOverlap(dom))
    {
        if (selected)
            mySet.insert(pid);
        else
            mySet.remove(pid);
        return;
    }

    auto& owners =
        (kind == GridKind::Solid) ? m_ownerPointSolidByDomain[dom] : m_ownerPointLineByDomain[dom];
    auto& prevOwners = (kind == GridKind::Solid) ? m_prevOwnerPointSolidByDomain[dom]
                                                 : m_prevOwnerPointLineByDomain[dom];

    if (selected)
    {
        if (mySet.contains(pid))
            return;
        const QString oldUid = owners.value(pid);
        if (!oldUid.isEmpty() && oldUid != uid)
        {
            prevOwners[pid] = oldUid;
            uuid2set[oldUid].remove(pid);
        }
        owners[pid] = uid;
        mySet.insert(pid);
    }
    else
    {
        if (!mySet.contains(pid))
            return;
        mySet.remove(pid);
        if (owners.value(pid) == uid)
            owners.remove(pid);

        const QString oldUid = prevOwners.take(pid);
        if (!oldUid.isEmpty())
        {
            owners[pid] = oldUid;
            uuid2set[oldUid].insert(pid);
        }
    }
}

void PickManager::setEdgeSelected_NoRefresh(GridKind kind, vtkIdType edgeKey, bool selected)
{
    if (m_currentDomain.isEmpty() || m_currentUUid.isEmpty())
        return;

    const QString dom = m_currentDomain;
    const QString uid = m_currentUUid;

    edgeKey = canonicalizeEdgeKey(kind, edgeKey);
    auto& owners =
        (kind == GridKind::Solid) ? m_ownerEdgeSolidByDomain[dom] : m_ownerEdgeLineByDomain[dom];
    auto& uuid2set =
        (kind == GridKind::Solid) ? m_edgesSolidByDomainUuid[dom] : m_edgesLineByDomainUuid[dom];
    auto& prevOwners = (kind == GridKind::Solid) ? m_prevOwnerEdgeSolidByDomain[dom]
                                                 : m_prevOwnerEdgeLineByDomain[dom];

    QSet<vtkIdType>& mySet = uuid2set[uid];

    if (selected)
    {
        if (mySet.contains(edgeKey))
            return;
        const QString oldUid = owners.value(edgeKey);
        if (!oldUid.isEmpty() && oldUid != uid)
        {
            prevOwners[edgeKey] = oldUid;
            uuid2set[oldUid].remove(edgeKey);
        }
        owners[edgeKey] = uid;
        mySet.insert(edgeKey);
    }
    else
    {
        if (!mySet.contains(edgeKey))
            return;
        mySet.remove(edgeKey);
        if (owners.value(edgeKey) == uid)
            owners.remove(edgeKey);

        const QString oldUid = prevOwners.take(edgeKey);
        if (!oldUid.isEmpty())
        {
            owners[edgeKey] = oldUid;
            uuid2set[oldUid].insert(edgeKey);
        }
    }
}

void PickManager::setFaceSelected_NoRefresh(GridKind kind, vtkIdType faceKey, bool selected)
{
    if (m_currentDomain.isEmpty() || m_currentUUid.isEmpty())
        return;

    const QString dom = m_currentDomain;
    const QString uid = m_currentUUid;

    auto& owners =
        (kind == GridKind::Solid) ? m_ownerFaceSolidByDomain[dom] : m_ownerFaceLineByDomain[dom];
    auto& uuid2set =
        (kind == GridKind::Solid) ? m_facesSolidByDomainUuid[dom] : m_facesLineByDomainUuid[dom];
    auto& prevOwners = (kind == GridKind::Solid) ? m_prevOwnerFaceSolidByDomain[dom]
                                                 : m_prevOwnerFaceLineByDomain[dom];

    QSet<vtkIdType>& mySet = uuid2set[uid];

    if (selected)
    {
        if (mySet.contains(faceKey))
            return;
        const QString oldUid = owners.value(faceKey);
        if (!oldUid.isEmpty() && oldUid != uid)
        {
            prevOwners[faceKey] = oldUid;
            uuid2set[oldUid].remove(faceKey);
        }
        owners[faceKey] = uid;
        mySet.insert(faceKey);
    }
    else
    {
        if (!mySet.contains(faceKey))
            return;
        mySet.remove(faceKey);
        if (owners.value(faceKey) == uid)
            owners.remove(faceKey);

        const QString oldUid = prevOwners.take(faceKey);
        if (!oldUid.isEmpty())
        {
            owners[faceKey] = oldUid;
            uuid2set[oldUid].insert(faceKey);
        }
    }
}

// ===================== line node overlay =====================
void PickManager::rebuildLineNodeOverlayAll()
{
    if (!m_lineNodeActor)
        return;

    if (!m_showLineNodes || !m_gridLine || m_gridLine->GetNumberOfPoints() <= 0)
    {
        m_lineNodeActor->SetVisibility(false);
        return;
    }

           // 直接引用 points（不复制）
    m_lineNodePoly->SetPoints(m_gridLine->GetPoints());
    m_lineNodePoly->Modified();

    const bool hasActivePickContext = !m_currentDomain.isEmpty() && !m_currentUUid.isEmpty();
    m_lineNodeActor->SetVisibility(hasActivePickContext && (m_pickMode == PickMode::Node));
}

// ===================== commit exclusive =====================
void PickManager::commitNodeExclusive(const QString& domain, const QString& uuid)
{
    if (nodeSelectionAllowsOverlap(domain))
        return;

    {
        auto itPrev = m_prevOwnerPointSolidByDomain.find(domain);
        if (itPrev != m_prevOwnerPointSolidByDomain.end())
        {
            const QSet<vtkIdType> setS = m_pointsSolidByDomainUuid.value(domain).value(uuid);
            for (vtkIdType pid : setS)
                itPrev.value().remove(pid);
        }
    }
    {
        auto itPrev = m_prevOwnerPointLineByDomain.find(domain);
        if (itPrev != m_prevOwnerPointLineByDomain.end())
        {
            const QSet<vtkIdType> setL = m_pointsLineByDomainUuid.value(domain).value(uuid);
            for (vtkIdType pid : setL)
                itPrev.value().remove(pid);
        }
    }
}

void PickManager::commitEdgeExclusive(const QString& domain, const QString& uuid)
{
    {
        auto itPrev = m_prevOwnerEdgeSolidByDomain.find(domain);
        if (itPrev != m_prevOwnerEdgeSolidByDomain.end())
        {
            const QSet<vtkIdType> setS = m_edgesSolidByDomainUuid.value(domain).value(uuid);
            for (vtkIdType k : setS)
                itPrev.value().remove(k);
        }
    }
    {
        auto itPrev = m_prevOwnerEdgeLineByDomain.find(domain);
        if (itPrev != m_prevOwnerEdgeLineByDomain.end())
        {
            const QSet<vtkIdType> setL = m_edgesLineByDomainUuid.value(domain).value(uuid);
            for (vtkIdType k : setL)
                itPrev.value().remove(k);
        }
    }
}

void PickManager::commitFaceExclusive(const QString& domain, const QString& uuid)
{
    {
        auto itPrev = m_prevOwnerFaceSolidByDomain.find(domain);
        if (itPrev != m_prevOwnerFaceSolidByDomain.end())
        {
            const QSet<vtkIdType> setS = m_facesSolidByDomainUuid.value(domain).value(uuid);
            for (vtkIdType k : setS)
                itPrev.value().remove(k);
        }
    }
    {
        auto itPrev = m_prevOwnerFaceLineByDomain.find(domain);
        if (itPrev != m_prevOwnerFaceLineByDomain.end())
        {
            const QSet<vtkIdType> setL = m_facesLineByDomainUuid.value(domain).value(uuid);
            for (vtkIdType k : setL)
                itPrev.value().remove(k);
        }
    }
}

QVector<vtkIdType> PickManager::getSelectedPointIds(const QString& domain, const QString& uuid,
                                                    GridKind kind) const
{
    const QSet<vtkIdType> set = (kind == GridKind::Solid)
    ? m_pointsSolidByDomainUuid.value(domain).value(uuid)
    : m_pointsLineByDomainUuid.value(domain).value(uuid);

    QVector<vtkIdType> out;
    out.reserve(set.size());
    for (vtkIdType pid : set)
        out.push_back(pid);
    std::sort(out.begin(), out.end());
    return out;
}


void PickManager::setNodeSelectionAllowsOverlap(const QString& domain, bool allow)
{
    if (domain.isEmpty())
        return;
    if (allow)
        m_overlapNodeSelectionDomains.insert(domain);
    else
        m_overlapNodeSelectionDomains.remove(domain);
}

bool PickManager::nodeSelectionAllowsOverlap(const QString& domain) const
{
    // 位移约束在工程恢复/IIID 导入时可能先恢复节点、后进入页面，
    // 因此不能只依赖 beforeLoad() 临时打开共享模式。
    return domain == QStringLiteral("DisplacementConstraintWidget") ||
           m_overlapNodeSelectionDomains.contains(domain);
}

int PickManager::nodeIdForPoint(GridKind kind, vtkIdType pointId) const
{
    vtkUnstructuredGrid* grid = (kind == GridKind::Solid) ? m_gridSolid : m_gridLine;
    if (!grid || pointId < 0 || pointId >= grid->GetNumberOfPoints())
        return -1;

    vtkIntArray* nodeIdArr = (kind == GridKind::Solid) ? m_nodeIdArrSolid : m_nodeIdArrLine;
    if (!nodeIdArr && grid->GetPointData())
    {
        nodeIdArr = vtkIntArray::SafeDownCast(grid->GetPointData()->GetArray("node_id"));
        if (!nodeIdArr)
            nodeIdArr = vtkIntArray::SafeDownCast(grid->GetPointData()->GetArray("NodeId"));
    }
    if (!nodeIdArr || pointId >= nodeIdArr->GetNumberOfTuples())
        return -1;
    return nodeIdArr->GetValue(int(pointId));
}

QVector<int> PickManager::selectedNodeIds(const QString& domain, const QString& uuid) const
{
    QSet<int> unique;
    auto appendKind = [&](GridKind kind, const QSet<vtkIdType>& set)
    {
        for (vtkIdType pid : set)
        {
            const int nodeId = nodeIdForPoint(kind, pid);
            if (nodeId >= 0)
                unique.insert(nodeId);
        }
    };

    appendKind(GridKind::Solid, m_pointsSolidByDomainUuid.value(domain).value(uuid));
    appendKind(GridKind::Line, m_pointsLineByDomainUuid.value(domain).value(uuid));

    QVector<int> out;
    out.reserve(unique.size());
    for (int nodeId : unique)
        out.push_back(nodeId);
    std::sort(out.begin(), out.end());
    return out;
}

QStringList PickManager::selectedNodeUuids(const QString& domain, int nodeId) const
{
    QSet<QString> sources;
    auto scanKind = [&](GridKind kind, const QHash<QString, QSet<vtkIdType>>& uuid2set)
    {
        for (auto it = uuid2set.constBegin(); it != uuid2set.constEnd(); ++it)
        {
            for (vtkIdType pid : it.value())
            {
                if (nodeIdForPoint(kind, pid) == nodeId)
                {
                    sources.insert(it.key());
                    break;
                }
            }
        }
    };

    scanKind(GridKind::Solid, m_pointsSolidByDomainUuid.value(domain));
    scanKind(GridKind::Line, m_pointsLineByDomainUuid.value(domain));

    QStringList out = sources.values();
    std::sort(out.begin(), out.end());
    return out;
}

QSet<int> PickManager::conflictingNodeIds(const QString& domain) const
{
    QHash<int, QSet<QString>> sourcesByNodeId;
    auto collectKind = [&](GridKind kind, const QHash<QString, QSet<vtkIdType>>& uuid2set)
    {
        for (auto it = uuid2set.constBegin(); it != uuid2set.constEnd(); ++it)
        {
            const QString& sourceUuid = it.key();
            for (vtkIdType pid : it.value())
            {
                const int nodeId = nodeIdForPoint(kind, pid);
                if (nodeId >= 0)
                    sourcesByNodeId[nodeId].insert(sourceUuid);
            }
        }
    };
    collectKind(GridKind::Solid, m_pointsSolidByDomainUuid.value(domain));
    collectKind(GridKind::Line, m_pointsLineByDomainUuid.value(domain));

    QSet<int> conflicts;
    for (auto itNode = sourcesByNodeId.constBegin(); itNode != sourcesByNodeId.constEnd(); ++itNode)
    {
        QVector<int> result{1, 1, 1};
        bool conflict = false;
        for (const QString& sourceUuid : itNode.value())
        {
            const QVector<int> incoming = nodeConstraintFlags(domain, sourceUuid);
            for (int axis = 0; axis < 3; ++axis)
            {
                const int value = incoming.value(axis, 1);
                if (value == 1)
                    continue;
                if (result[axis] == 1)
                {
                    result[axis] = value;
                    continue;
                }
                if (result[axis] != value)
                    conflict = true;
            }
        }
        if (conflict)
            conflicts.insert(itNode.key());
    }
    return conflicts;
}

QVector<int> PickManager::sharedNodeIds(const QString& domain, const QString& uuid) const
{
    QHash<int, QSet<QString>> sourcesByNodeId;
    auto collectKind = [&](GridKind kind, const QHash<QString, QSet<vtkIdType>>& uuid2set)
    {
        for (auto it = uuid2set.constBegin(); it != uuid2set.constEnd(); ++it)
        {
            const QString& sourceUuid = it.key();
            for (vtkIdType pid : it.value())
            {
                const int nodeId = nodeIdForPoint(kind, pid);
                if (nodeId >= 0)
                    sourcesByNodeId[nodeId].insert(sourceUuid);
            }
        }
    };
    collectKind(GridKind::Solid, m_pointsSolidByDomainUuid.value(domain));
    collectKind(GridKind::Line, m_pointsLineByDomainUuid.value(domain));

    const QVector<int> mine = selectedNodeIds(domain, uuid);
    QVector<int> out;
    out.reserve(mine.size());
    for (int nodeId : mine)
    {
        if (sourcesByNodeId.value(nodeId).size() > 1)
            out.push_back(nodeId);
    }
    return out;
}

QSet<int> PickManager::conflictingSharedNodeIds(const QString& domain, const QString& uuid) const
{
    const QVector<int> shared = sharedNodeIds(domain, uuid);
    QSet<int> target;
    target.reserve(shared.size());
    for (int nodeId : shared)
        target.insert(nodeId);
    if (target.isEmpty())
        return {};

    // 一次遍历全部约束选区，建立“共享 node_id -> 来源 uuid”，避免逐节点反复扫描。
    QHash<int, QSet<QString>> sourcesByNodeId;
    auto collectKind = [&](GridKind kind, const QHash<QString, QSet<vtkIdType>>& uuid2set)
    {
        for (auto it = uuid2set.constBegin(); it != uuid2set.constEnd(); ++it)
        {
            const QString& sourceUuid = it.key();
            for (vtkIdType pid : it.value())
            {
                const int nodeId = nodeIdForPoint(kind, pid);
                if (target.contains(nodeId))
                    sourcesByNodeId[nodeId].insert(sourceUuid);
            }
        }
    };
    collectKind(GridKind::Solid, m_pointsSolidByDomainUuid.value(domain));
    collectKind(GridKind::Line, m_pointsLineByDomainUuid.value(domain));

    QSet<int> conflicts;
    for (int nodeId : shared)
    {
        QVector<int> effective{1, 1, 1};
        bool conflict = false;
        const QSet<QString> sources = sourcesByNodeId.value(nodeId);
        for (const QString& sourceUuid : sources)
        {
            const QVector<int> incoming = nodeConstraintFlags(domain, sourceUuid);
            for (int axis = 0; axis < 3; ++axis)
            {
                const int value = incoming.value(axis, 1);
                if (value == 1)
                    continue;
                if (effective[axis] == 1)
                {
                    effective[axis] = value;
                    continue;
                }
                if (effective[axis] != value)
                    conflict = true;
            }
        }
        if (conflict)
            conflicts.insert(nodeId);
    }
    return conflicts;
}

QVector<vtkIdType> PickManager::sharedSelectedPointIds(const QString& domain, const QString& uuid,
                                                       GridKind kind) const
{
    const QVector<int> sharedIds = sharedNodeIds(domain, uuid);
    QSet<int> sharedSet;
    sharedSet.reserve(sharedIds.size());
    for (int nodeId : sharedIds)
        sharedSet.insert(nodeId);

    const QSet<vtkIdType> set = (kind == GridKind::Solid)
        ? m_pointsSolidByDomainUuid.value(domain).value(uuid)
        : m_pointsLineByDomainUuid.value(domain).value(uuid);

    QVector<vtkIdType> out;
    out.reserve(set.size());
    for (vtkIdType pid : set)
    {
        const int nodeId = nodeIdForPoint(kind, pid);
        if (sharedSet.contains(nodeId))
            out.push_back(pid);
    }
    std::sort(out.begin(), out.end());
    return out;
}

void PickManager::setNodeConstraintFlags(const QString& domain, const QString& uuid,
                                         int ux, int uy, int uz)
{
    if (domain.isEmpty() || uuid.isEmpty())
        return;
    m_nodeConstraintFlagsByDomainUuid[domain][uuid] = QVector<int>{ux, uy, uz};
}

void PickManager::clearNodeConstraintFlags(const QString& domain, const QString& uuid)
{
    auto itDomain = m_nodeConstraintFlagsByDomainUuid.find(domain);
    if (itDomain == m_nodeConstraintFlagsByDomainUuid.end())
        return;
    itDomain.value().remove(uuid);
    if (itDomain.value().isEmpty())
        m_nodeConstraintFlagsByDomainUuid.erase(itDomain);
}

QVector<int> PickManager::nodeConstraintFlags(const QString& domain, const QString& uuid) const
{
    return m_nodeConstraintFlagsByDomainUuid.value(domain).value(uuid, QVector<int>{1, 1, 1});
}

QVector<int> PickManager::effectiveNodeConstraintFlags(const QString& domain, int nodeId,
                                                       bool* hasConflict) const
{
    if (hasConflict)
        *hasConflict = false;

    QVector<int> result{1, 1, 1};
    const QStringList sources = selectedNodeUuids(domain, nodeId);
    for (const QString& uuid : sources)
    {
        const QVector<int> incoming = nodeConstraintFlags(domain, uuid);
        for (int axis = 0; axis < 3; ++axis)
        {
            const int value = incoming.value(axis, 1);
            if (value == 1)
                continue; // “自由”只表示本约束不贡献该方向，不会释放别的约束。
            if (result[axis] == 1)
            {
                result[axis] = value;
                continue;
            }
            if (result[axis] == value)
                continue;

            // 当前实现中的普通固定值是 0；-10000 是“悬空杆件节点”特殊状态。
            // 两个不同的非自由值不能静默合并。
            if (hasConflict)
                *hasConflict = true;
        }
    }
    return result;
}

// ===================== getIdList =====================
QVector<vtkIdType> PickManager::getIdList(const QString& domain, const QString& uuid,
                                          PickMode mode) const
{
    return getIdList(domain, uuid, mode, GridKind::Solid);
}

QVector<vtkIdType> PickManager::getIdList(const QString& domain, const QString& uuid, PickMode mode,
                                          GridKind kind) const
{
    QVector<vtkIdType> out;

    if (mode == PickMode::Node)
    {
        const QSet<vtkIdType> set = (kind == GridKind::Solid)
        ? m_pointsSolidByDomainUuid.value(domain).value(uuid)
        : m_pointsLineByDomainUuid.value(domain).value(uuid);

        out.reserve(set.size());

        vtkUnstructuredGrid* grid = (kind == GridKind::Solid) ? m_gridSolid : m_gridLine;
        vtkIntArray* nodeIdArr = (kind == GridKind::Solid) ? m_nodeIdArrSolid : m_nodeIdArrLine;
        if (!nodeIdArr && grid)
            nodeIdArr = vtkIntArray::SafeDownCast(grid->GetPointData()->GetArray("node_id"));

        if (!grid || !nodeIdArr)
            return out;

        const vtkIdType nPts = grid->GetNumberOfPoints();
        for (vtkIdType pid : set)
        {
            if (pid < 0 || pid >= nPts)
                continue;
            out.push_back(vtkIdType(nodeIdArr->GetValue(int(pid))));
        }
        return out;
    }

    if (mode == PickMode::Edge)
    {
        const QSet<vtkIdType> set = (kind == GridKind::Solid)
        ? m_edgesSolidByDomainUuid.value(domain).value(uuid)
        : m_edgesLineByDomainUuid.value(domain).value(uuid);

        out.reserve(set.size());
        for (vtkIdType k : set)
            out.push_back(k); // edgeKey
        return out;
    }

    if (mode == PickMode::Face)
    {
        const QSet<vtkIdType> set = (kind == GridKind::Solid)
        ? m_facesSolidByDomainUuid.value(domain).value(uuid)
        : m_facesLineByDomainUuid.value(domain).value(uuid);

        out.reserve(set.size());
        for (vtkIdType k : set)
            out.push_back(k); // faceKey
        return out;
    }

    return out;
}

// ===================== getEdgeNodesByKe / getFaceNodesByKe
// =====================
QHash<int, QVector<int>> PickManager::getEdgeNodesByKe(const QString& domain, const QString& uuid,
                                                       GridKind kind) const
{
    QHash<int, QVector<int>> nodesByKe;
    QHash<int, QSet<int>> seenByKe;

    vtkUnstructuredGrid* grid = (kind == GridKind::Solid) ? m_gridSolid : m_gridLine;
    vtkDataArray* nodeIdArr = (kind == GridKind::Solid)
                                  ? static_cast<vtkDataArray*>(m_nodeIdArrSolid)
                                  : static_cast<vtkDataArray*>(m_nodeIdArrLine);
    vtkDataArray* elemIdArr = (kind == GridKind::Solid)
                                  ? static_cast<vtkDataArray*>(m_elemIdArrSolid)
                                  : static_cast<vtkDataArray*>(m_elemIdArrLine);

    if (!nodeIdArr && grid)
        nodeIdArr = vtkDataArray::SafeDownCast(grid->GetPointData()->GetArray("node_id"));
    if (!elemIdArr && grid)
        elemIdArr = vtkDataArray::SafeDownCast(grid->GetCellData()->GetArray("elem_id"));

    if (!grid || !nodeIdArr)
        return nodesByKe;

    const QSet<vtkIdType> edgeKeys = (kind == GridKind::Solid)
                                         ? m_edgesSolidByDomainUuid.value(domain).value(uuid)
                                         : m_edgesLineByDomainUuid.value(domain).value(uuid);

    QVector<vtkIdType> keys = edgeKeys.values().toVector();
    std::sort(keys.begin(), keys.end(),
              [&](vtkIdType a, vtkIdType b)
              {
                  const vtkIdType ca = unpackEdgeCellId(a), cb = unpackEdgeCellId(b);
                  if (ca != cb)
                      return ca < cb;
                  return unpackEdgeLocalId(a) < unpackEdgeLocalId(b);
              });

    const vtkIdType nCells = grid->GetNumberOfCells();
    const vtkIdType nPts = grid->GetNumberOfPoints();

    for (vtkIdType edgeKey : keys)
    {
        const vtkIdType cellId = unpackEdgeCellId(edgeKey);
        const int edgeLocalId = unpackEdgeLocalId(edgeKey);
        if (cellId < 0 || cellId >= nCells)
            continue;

        const int ke = elemIdArr ? int(elemIdArr->GetTuple1(cellId)) : 0;

        vtkCell* cell = grid->GetCell(cellId);
        if (!cell)
            continue;

        QVector<vtkIdType> epids;

        if (cell->GetCellDimension() == 1 || edgeLocalId == 15)
        {
            vtkIdList* ids = cell->GetPointIds();
            if (!ids || ids->GetNumberOfIds() < 2)
                continue;
            for (vtkIdType i = 0; i < ids->GetNumberOfIds(); ++i)
                epids.push_back(ids->GetId(i));
        }
        else
        {
            if (edgeLocalId < 0 || edgeLocalId >= cell->GetNumberOfEdges())
                continue;
            vtkCell* e = cell->GetEdge(edgeLocalId);
            if (!e)
                continue;
            vtkIdList* ids = e->GetPointIds();
            if (!ids || ids->GetNumberOfIds() < 2)
                continue;
            for (vtkIdType i = 0; i < ids->GetNumberOfIds(); ++i)
                epids.push_back(ids->GetId(i));
        }

        QVector<int>& vec = nodesByKe[ke];
        QSet<int>& seen = seenByKe[ke];

        for (vtkIdType pid : epids)
        {
            if (pid < 0 || pid >= nPts)
                continue;
            const int nodeId = int(nodeIdArr->GetTuple1(pid));
            if (seen.contains(nodeId))
                continue;
            seen.insert(nodeId);
            vec.push_back(nodeId);
        }
    }

    return nodesByKe;
}

QHash<int, QVector<int>> PickManager::getFaceNodesByKe(const QString& domain, const QString& uuid,
                                                       GridKind kind) const
{
    QHash<int, QVector<int>> nodesByKe;
    QHash<int, QSet<int>> seenByKe;

    vtkUnstructuredGrid* grid = (kind == GridKind::Solid) ? m_gridSolid : m_gridLine;
    vtkDataArray* nodeIdArr = (kind == GridKind::Solid)
                                  ? static_cast<vtkDataArray*>(m_nodeIdArrSolid)
                                  : static_cast<vtkDataArray*>(m_nodeIdArrLine);
    vtkDataArray* elemIdArr = (kind == GridKind::Solid)
                                  ? static_cast<vtkDataArray*>(m_elemIdArrSolid)
                                  : static_cast<vtkDataArray*>(m_elemIdArrLine);

    if (!nodeIdArr && grid)
        nodeIdArr = vtkDataArray::SafeDownCast(grid->GetPointData()->GetArray("node_id"));
    if (!elemIdArr && grid)
        elemIdArr = vtkDataArray::SafeDownCast(grid->GetCellData()->GetArray("elem_id"));

    if (!grid || !nodeIdArr)
        return nodesByKe;

    const QSet<vtkIdType> faceKeys = (kind == GridKind::Solid)
                                         ? m_facesSolidByDomainUuid.value(domain).value(uuid)
                                         : m_facesLineByDomainUuid.value(domain).value(uuid);

    QVector<vtkIdType> keys = faceKeys.values().toVector();
    std::sort(keys.begin(), keys.end(),
              [&](vtkIdType a, vtkIdType b)
              {
                  const vtkIdType ca = unpackFaceCellId(a), cb = unpackFaceCellId(b);
                  if (ca != cb)
                      return ca < cb;
                  return unpackFaceLocalId(a) < unpackFaceLocalId(b);
              });

    const vtkIdType nCells = grid->GetNumberOfCells();
    const vtkIdType nPts = grid->GetNumberOfPoints();

    for (vtkIdType faceKey : keys)
    {
        const vtkIdType cellId = unpackFaceCellId(faceKey);
        const int faceLocalId = unpackFaceLocalId(faceKey);
        if (cellId < 0 || cellId >= nCells)
            continue;

        const int ke = elemIdArr ? int(elemIdArr->GetTuple1(cellId)) : 0;

        vtkCell* cell = grid->GetCell(cellId);
        if (!cell)
            continue;

        QVector<vtkIdType> fpids;

        if (cell->GetCellDimension() == 2 || faceLocalId == 15)
        {
            vtkIdList* ids = cell->GetPointIds();
            if (!ids || ids->GetNumberOfIds() < 3)
                continue;
            for (vtkIdType i = 0; i < ids->GetNumberOfIds(); ++i)
                fpids.push_back(ids->GetId(i));
        }
        else
        {
            if (faceLocalId < 0 || faceLocalId >= cell->GetNumberOfFaces())
                continue;
            vtkCell* f = cell->GetFace(faceLocalId);
            if (!f)
                continue;
            vtkIdList* ids = f->GetPointIds();
            if (!ids || ids->GetNumberOfIds() < 3)
                continue;
            for (vtkIdType i = 0; i < ids->GetNumberOfIds(); ++i)
                fpids.push_back(ids->GetId(i));
        }

        QVector<int>& vec = nodesByKe[ke];
        QSet<int>& seen = seenByKe[ke];

        for (vtkIdType pid : fpids)
        {
            if (pid < 0 || pid >= nPts)
                continue;
            const int nodeId = int(nodeIdArr->GetTuple1(pid));
            if (seen.contains(nodeId))
                continue;
            seen.insert(nodeId);
            vec.push_back(nodeId);
        }
    }

    return nodesByKe;
}
